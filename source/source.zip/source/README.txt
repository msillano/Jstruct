Build:
    Download src, lib, classes dirs
    I used JCreator and JDK1.8.0_66

