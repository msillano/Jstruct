//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: E:\winPenPack\Documents\javaStruct\source\src\JStruct.java
//@JStruct: 1.02 (see AbstractElement)
//
   import javax.swing.UIManager;
   import javax.swing.JOptionPane;
   import javax.swing.JDialog;
   import javax.tools.JavaCompiler;
   import javax.tools.JavaCompiler.CompilationTask;
   import javax.tools.ToolProvider;

   import lu.fisch.structorizer.gui.Mainform;
   import lu.fisch.structorizer.parsers.JavaParser;
   /**
    *
    * Source build by JStruct.<BR>
    *
    * @version 1.02.00  build 65  (2015.03.27-19:17:22) update to java 1.8
    * @version 1.01.01  build 19  (2012.03.25-18:14:49) JStruct-aware version
    * @version 1.01.00  build 135  (2012.02.07-19:17:22)  base version
    * @author Marco Sillano <marco.sillano@gmail.com>
    */
   public class JStruct {

     private static boolean testParser(){
      	JavaCompiler compiler = null;
      	try{
             compiler = ToolProvider.getSystemJavaCompiler();
      	} catch (Error e){
      		 e.printStackTrace( System.out);
      	}
		if ( compiler == null) {
             return false;
        	}
      return true;
      }
      /**
       * entry point
       * @param args
       */
      public static void main(String[] args) {
         try {
// TODO error?   this error is likely due to the swt-swing integration and can not be resolved http://dev.nepomuk.semanticdesktop.org/ticket/667
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
         }
         catch (Exception e) {
            System.err.println("Warning - setting native LAF: " + e);
         }

        try {
// TODO error?   this error is likely due to the swt-swing integration and can not be resolved http://dev.nepomuk.semanticdesktop.org/ticket/667
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
         }

         catch (Exception e) {
            System.err.println("Warning - setting native LAF: " + e);
         }

         String s = "";
// load the mainform
         final   Mainform mainform = new Mainform();
         // added 18/03/2015, test jsdk

         boolean okParser = testParser();
         if (!okParser){
         	mainform.diagram.setParseCapability(false);
         	// forces updates
         	mainform.doButtons();
//            mainform.setLangLocal(null);
         }
        if (args.length > 0){
         try {
            StringBuffer buf = new StringBuffer();
            for(int i = 0; i < args.length; ++ i) {
               buf.append(args[i]);
            }
            s = buf.toString();
            if(s.toLowerCase().endsWith(".java") && okParser) {
               mainform.diagram.fileImportJAVA(s);
// added 18/03/2015, to set title
               mainform.doButtons();
            }
            if(s.toLowerCase().endsWith(".nsd")) {
               mainform.diagram.doOpenNSD(s);
 // added 18/03/2015, to set title
              mainform.doButtons();
            }
         }
         catch (Exception e) {
            System.err.println("Error reading " + s + "\n" + e);
         }


         }
         else {
         		// new
	     mainform.diagram.doNewNSD();
         }
 // added 18/03/2015

        if (!okParser){
             JDialog dialog = mainform.getParsePane().createDialog(null, "ERROR: JDK not found");
             dialog.setVisible(true);
             }
      }

   }
