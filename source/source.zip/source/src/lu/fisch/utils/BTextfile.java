/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.utils;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    Class to manage a textfile.
 *						Aims to work like working with a textfile in Delphi.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2003.05.10      First Issue
 *		Bob Fisch		2007.12.10		Moved to another package for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************/

import java.io.*;

/**
 *
 */
public class BTextfile
{


	/** The outputwrites */
	private OutputStreamWriter myfile_out;
	/** The inputwrites */
	private InputStreamReader myfile_in;
	/** The filename */
	private String filename =null;
	/** The file-end-check */
	private boolean fileend = false;
	/** The line-end-check */
	private boolean lineend = false;
	/** A temporary variable to the last read byte */
	private String lastbyte = null;

	/**
	 * Returns TRUE if end-of-file reached
	 *@return TRUE if end-of-file reached
	 */
	public boolean eof()
	{
		return this.fileend;
	}

	/**
	 * Returns TRUE if end-of-line reached
	 *@return TRUE if end-of-line reached
	 */
	public boolean eol()
	{
		return this.lineend;
	}

	/**
	 * Contructor of the BTextfile object
	 *@param filename The file to be assigned to
	 */
	public BTextfile(String filename)
	{
		this.filename=filename;
		this.fileend=false;
	}

	/**
	 * Opens the file for writing and overwrites any existing file with the same name
	 * @param _code 
	 * @throws IOException 
	 */
	public void rewrite(String _code) throws IOException
	{
		this.myfile_out=new OutputStreamWriter(new FileOutputStream(this.filename), _code);
		this.fileend=false;
	}

	/**
	 * Opens the file for writing and overwrites any existing file with the same name
	 * @throws IOException 
	 */
	public void rewrite() throws IOException
	{
		this.myfile_out=new OutputStreamWriter(new FileOutputStream(this.filename), "ISO-8859-1");
//		myfile_out=new OutputStreamWriter(new FileOutputStream(filename), "UTF-8");
		this.fileend=false;
	}

	/**
	 * Opens the file for reading
	 * @throws IOException 
	 */
	public void reset() throws IOException
	{
		this.myfile_in=new InputStreamReader(new FileInputStream(this.filename));
		this.fileend=false;
		read();
	}

	/**
	 * Opens the file for writing and appends code to any existing file with the same name
	 * @throws IOException 
	 */
	public void append() throws IOException
	{
		this.myfile_out=new OutputStreamWriter(new FileOutputStream(this.filename,true));
	}

	/**
	 * Closes and saves the file
	 * @throws IOException 
	 */
	public void close() throws IOException
	{
		if (this.myfile_out != null) {this.myfile_out.close();}
		if (this.myfile_in  != null) {this.myfile_in.close();}
		this.fileend=true;
	}

	/**
	 * Writes to the file
	 *@param mystring String to be written to the file
	 * @throws IOException 
	 */
	public void write(String mystring) throws IOException
	{
		this.myfile_out.write(mystring,0,mystring.length());
	}

	/**
	 * Writes to the file and adds end-of-line symbol
	 *@param mystring String to be written to the file
	 * @throws IOException 
	 */
	public void writeln(String mystring) throws IOException
	{
		this.myfile_out.write(mystring+"\r\n",0,mystring.length()+2);
	}

	/**
	 * Reads one caracter (byte) from the file
	 *@return mystring The string that has been read
	 * @throws IOException 
	 */
	public String read() throws IOException
	{
		if (eof()==false)
		{
			final Integer ibuf = Integer.valueOf(this.myfile_in.read());
			final byte[] bbuf = new byte[1];
			bbuf[0] = ibuf.byteValue();

			if (bbuf[0]==10||bbuf[0]==13) {this.lineend=true;this.myfile_in.read();}
			else {this.lineend=false;}
			if (bbuf[0]==-1) {this.fileend=true;}
			else {this.fileend=false;}

			final String sbuf = this.lastbyte;
			this.lastbyte = new String(bbuf);

			return sbuf;
		}
			return "";
	}

	/**
	 * Reads a singel line from the file but cuts blanks at the beginning and the end
	 *@return mystring The string that has been read
	 * @throws IOException 
	 */
	public String readlnDataonly() throws IOException
	{
		final String str = readln();
		return BString.cutOut(str);
	}

	/**
	 * Reads from the file a single line
	 *@return mystring The string that has been read
	 * @throws IOException 
	 */
	public String readln() throws IOException
	{
//		String sbuf = "";
		StringBuffer sbuf = new StringBuffer();

		if (eof()==false)
		{
			do
			{
				String cbuf = read();
				if (!cbuf.equals("\n") && !cbuf.equals("\r"))
				{
					sbuf.append(cbuf);
				}
			}
			while (eof()==false && eol()==false);

		}
		return sbuf.toString();
	}
}
