/**
 *
 */
package lu.fisch.utils;

import javax.swing.JLabel;

/**
 * @author pc2
 * Duplicated in Menu.java for lang update
 */
public class ErrorMessages {
	// Error messages for analyser
//	public static JLabel error01_1 = new JLabel(
//	"WARNING: No loop variable detected ...");
//	public static JLabel error01_2 = new JLabel(
//	"WARNING: More than one loop variable detected ...");
//	public static JLabel error01_3 = new JLabel(
//	"You are not allowed to modify the loop variable «%» inside the loop!");
//	public static JLabel error02 = new JLabel(
//	"No change of the variables in the condition detected. Possible endless loop ...");
//	public static JLabel error03_1 = new JLabel(
//	"The variable «%» has not yet been initialized!");
//	public static JLabel error03_2 = new JLabel(
//	"The variable «%» may not have been initialized!");
    /** error message */
     public static JLabel error03 = new JLabel(
    "Warning: Catch empty");
	/** error message */
	 public static JLabel error04 = new JLabel(
	"You are not allowed to use an IF-statement with an empty TRUE-block!");
		/** error message */
	public static JLabel error05 = new JLabel(
	"The variable «%» must be written starting in lowercase!");
	/** error message */
	public static JLabel error06_1 = new JLabel(
	"The Class «%» must start in uppercase!");
	/** error message */
	public static JLabel error06_2 = new JLabel(
	"The Method name «%» is duplicated!");
	/** error message */
	public static JLabel error06_3 = new JLabel(
	"The name «%» is not allowed in Java!");
	/** error message */
	public static JLabel error06_4 = new JLabel(
	"The name «%» is alredy used");
	/** error message */
	public static JLabel error07_1 = new JLabel(
	"«%» is not a valid name for Java");
	/** error message */
	public static JLabel error07_2 = new JLabel(
	"«%» is not a valid name for a parameter!");
	/** error message */
	public static JLabel error07_3 = new JLabel(
	"«%» is not a valid name for a variable!");
	/** error message */
	public static JLabel error08 = new JLabel(
	"Warning - An assignment inside a condition.");
//	public static JLabel error09 = new JLabel(
//	"Your program («%») cannot have the same name as a variable or parameter!");
	/** error message */
	public static JLabel error10_1 = new JLabel(
	"Warning - maybe missed a ';' in sequence code?");
//	public static JLabel error10_2 = new JLabel(
//	"A single instruction element should not contain input and output instructions!");
//	public static JLabel error10_3 = new JLabel(
//	"A single instruction element should not contain input instructions and assignments!");
//	public static JLabel error10_4 = new JLabel(
//	"A single instruction element should not contain ouput instructions and assignments!");
	/** error message */
	public static JLabel error11 = new JLabel(
	"The called «%» method not found!");
	/** error message */
	public static JLabel error12 = new JLabel(
	"The public Class «%» must have same name of the Java file!");
	/** error message */
	public static JLabel error13_1 = new JLabel(
	"Your function does not return any result!");
	/** error message */
	public static JLabel error13_2 = new JLabel(
	"Your function may not return a result!");
	/** error message */
	public static JLabel error13_3 = new JLabel(
	"Your function may not return a result!");

}
