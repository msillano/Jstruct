//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
package lu.fisch.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;

import lu.fisch.structorizer.io.Ini;

/**
 * Utility class to process Java code fragments, as single line or multiline.
 * The main goal is to centralize the Java code management, using an advanced string
 * and comments parser. <br />
 * The code is stored in a StringBuilder.
 * A second StringBuilder (map) can store char flags to identify code, comments, String constants, characters.
 * All standard (String like) and java oriented manipulation methods keeps the map synchronization.
 * The Java3Code status can be:<ul>
 *		<li>VOID: no code inside.
 *      <li>USER: code present, but not processed.
 *      <li>MAPPED: the code is parsed, the map is updated.<br />
 *           In this status see more flags:<ol>
 *            <li>DECOMM: comments are stripped from code.
 *            <li>DESTRING: Strings and chars are stripped from code.
 *            <li>TOKENIZED: the code is normalized using one and only one space as
 *                  separator. ("." and "[""]" are not processed).</ol>
 *</ul>
 * Special code processing: <br />
 * onlyCode(): only clean code, like killStrings + killComments and deletes also array index ("[..]"). <br />
 * codeReduce(): produces a String (only code,
 *    generics "<..>" and array "[..]" also trimmed)
 *         where all operators are replaced by: <ul>
 *            <li>"=" for all assignments.
 *            <li>"+" for all operations.
 *            <li>">" for all compare.
 *            <li>",.;()" are not replaced. </ul>
 *
 * cleanupMultiline(String indent): processes a (multiline) user code fragment as from Instruction and block elements.<br />
 * Merges all lines and adds a new line after "@xxx", "{", "}", ";" using the correct indentation.
 *
 *
 * Source build by JStruct.<br />
 * @version 1.02.01  build 53  (2015.03.12-18:09:41) bug, java 1.8
 * @version <br />1.01.01  build 18  (2012.03.12-20:59:31) JStruct-aware version
 * @version <br />1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */

public class Java3Code implements Iterable<String> {
	private enum codeStatus {
		VOID, USER, MAPPED
	}

	/** blocks Strings */
	public static String preAlt = "if";
	/** blocks Strings */
	public static String postAlt = "?";
	/** blocks Strings */
	public static String preCase = "switch";
	/** blocks Strings */
	public static String postCase = "";
	/** blocks Strings */
	public static String preFor = "for";
	/** blocks Strings */
	public static String postFor = "";
	/** blocks Strings */
	public static String preWhile = "while";
	/** blocks Strings */
	public static String postWhile = "";
	/** blocks Strings */
	public static String preRepeat = "do";
	/** blocks Strings */
	public static String postRepeat = "while";
	/** blocks Strings */
	public static String input = "read";

	/** blocks Strings */
	public static String output = "write";
	/** date format */
	public static String dateFormat = "yyyy.MM.dd-HH:mm:ss";

	/** java keywords  */
	public static final String[] javaAllKeywords = { "abstract", "assert", "default",
			"if", "private", "this", "do", "implements", "protected", "throw",
			"break", "import", "public", "throws", "else", "instanceof",
			"return", "transient", "case", "extends", "try", "catch", "final",
			"interface", "static", "finally", "strictfp", "volatile", "class",
			"native", "super", "while", "const", "for", "new", "switch",
			"strictfp", "continue", "goto", "package", "synchronized", "assert" };
	/** java types */
	public static final String[] javaTypes = { "void", "boolean", "double",
			"float", "byte", "int", "short", "char", "long", "enum", "String",
			"Object" };
	/** Strings */
	public static StringList evidenceSigns = null;
	/** Strings */
	public static StringList keywordsJava = null;
	/** Strings */
	public static StringList all1Signs = null;
	/** Strings */
	public static StringList all2Signs = null;

	/** Strings */
	public static StringList all3Signs = null;
	/** Strings */
	public static StringList all4Signs = null;

	// data
	private StringBuilder code = null;
	private StringBuilder map = null;
	// status
	private boolean TOKENIZED = false;
	private boolean DECOMM = false;
	private boolean DESTRING = false;
	private codeStatus status = codeStatus.VOID;
	/** map constant */
	public final static char MFCODE = 'c';
	/** map constant */
	public final static char MFSTRING = 's';
	/** map constant */
	public final static char MFCOMM = 'k';
	/** map constant */
	public final static char MFCBLOCK = 'b';
	/** map constant */
	public final static char MFCHAR = 'h';
	/** map constant */
	public final static char EVGLOBAL = 'g';
	/** map constant */
	public final static char EVVAR = 'v';
	/** map constant */
	public final static char EVJAVA = 'j';
	/** map constant */
	public final static char EVOP = 'o';

	/**
	 * Constructor
	 */
	public Java3Code() {
		super();
		this.status = codeStatus.VOID;
	}

	/**
	 * Constructor from String
	 * @param text
	 */
	public Java3Code(String text) {
		super();
		this.code = new StringBuilder(text);
		this.status = codeStatus.USER;
	}

	/**
	 * Constructor from StringList
	 * @param jtext
	 */
	public Java3Code(StringList jtext) {
		super();
		this.code = jtext.getSBuilder();
		this.status = codeStatus.USER;
	}

// deep copy constructor
	@Override
	public Java3Code clone() {
		Java3Code x = new Java3Code();
		x.status = this.status;
		if (x.status == codeStatus.VOID)
			return x;
		x.code = new StringBuilder(this.code);
		if (x.status == codeStatus.USER)
			return x;
		x.map = new StringBuilder(this.getMap());
		x.TOKENIZED = this.TOKENIZED;
		x.DECOMM = this.DECOMM;
		x.DESTRING = this.DESTRING;
		return x;
	}

	/**
	 * Merges 2 Java3Code, appends the code in ncode to this.
	 * @param ncode
	 * @return Java3Code
	 */
	public Java3Code add(Java3Code ncode) {
		this.code.append(ncode.code);
		if ((this.status == codeStatus.MAPPED)
				&& (ncode.getStatus() == codeStatus.MAPPED)) {
			this.getMap().append(ncode.getMap());
		} else {
			this.createMap();
		}
		if (this.DECOMM) {
			this.DECOMM = false;
			this.killComments();
		}
		if (this.DESTRING) {
			this.DESTRING = false;
			this.killStrings();
		}
		return this;
	}

	/**
	* codeReduce(): produces a String (only code, generics "<..>"  trimmed)
	*         where all operators are replaced by: <ul>
	*            <li>"=" for all assignments.
	*            <li>"+" for all operations.
	*            <li>">" for all compares.
	*            <li>",.;()" are not replaced. </ul>
	* All tokens are single space separated.
	 * @param skipIndex for array index "[..]" trim control
	 * @return String
	 */
	public String codeReduce(boolean skipIndex) {
		killStrings();
		killComments();
		String scode = getCode().toString();
		// eliminates constant array ???
		scode = scode.replaceAll("\\{[^\\}]*\\}", "");
		// eliminates generics types
		scode = scode.replaceAll("<\\w*?>", "");
		if (skipIndex) {
			scode = scode.replaceAll("\\[[^\\]]*\\]", "");
		}

//debug System.out.println("Tokenize-in:" + s);
		scode = " " + scode + " ";
		scode = scode.replace("<<<=", "=");
		scode = scode.replace(">>>=", "=");
		scode = scode.replace(">>=", "=");
		scode = scode.replace("<<=", "=");

		scode = scode.replace("<<<", "+");
		scode = scode.replace(">>>", "+");
		scode = scode.replace(">>", "+");
		scode = scode.replace("<<", "+");

		// 2 chars
		scode = scode.replaceAll("[><!=]=", ">"); // compare is ">"
		scode = scode.replaceAll("[+/%&^|[-][*]]=", "="); // assign is "="
		// more operators
// added 13/3/2015
        scode = scode.replace("->", "=");  // lamda as assign
        scode = scode.replace("::", "=");  // method reference as assign

        scode = scode.replace("&&", "+");
		scode = scode.replace("||", "+");
		scode = scode.replace("++", "+");
		scode = scode.replace("--", "+");
		// 1 char
		scode = scode.replaceAll("[><]", " > "); // compare is ">"
		// all separators
		scode = scode.replaceAll("[\\[\\]]", " ");
		// special processing for ":"
		if (scode.contains("?") && scode.contains(":")) {
			scode = scode.replaceAll(":", "+"); // case cond?iftrue:iffalse
		} else {
			scode = scode.replaceAll(":", "="); // case for(type var: itarable)
		}
		scode = scode.replaceAll("([\\(\\);,=])", " $1 ");
		// all operators becomes "+"
		scode = scode.replaceAll("[!~?+/%&^|[-][*]]", " + ");
		// eliminates all numbers
		scode = scode.replaceAll(" [0-9]+ ", " ");
		// done replacements // operator
		// spaces normalize (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 spaces -> 1
		scode = scode.replaceAll("   ", " ");
		scode = scode.replaceAll("  ", " ");
		scode = scode.replaceAll("  ", " ");
		// reduced: now all token are single space separated, and symbols
		// are only: [=,.;()+>]
//debug 		System.out.println("Reduced :" + scode);
		return scode;
	}

	/**
	 * Processes a (multiline) user code from Instruction and block elements.<br />
	 * Merges all lines and adds a smart new line after "@xxx", "{", "}", ";" using an incremental indentation.
	 * @param indent
	 * @return Java3Code
	 */
	public Java3Code cleanupMultiline(String indent) {
       trim();
       this.createMap();
// rewrited w status 23/03/2015 m.s.
// debug
//      System.out.println("  in-multi : >"+ this.code.toString()+"<")    ;
//      System.out.println("  in-multi : >"+ this.map.toString()+"<") ;

        String deep = "";
        int x = -1;
        int ppos = 0;
        replace("\n\n", "/*/");
        replace("\n", " ");
        replace("/*/", "\n");
        // empty
        if (getCode().length() < 2){
            return this;
        }
 // debug
 //     System.out.println("  in-multi : >"+ this.code.toString()+"<")    ;
 //     System.out.println("  in-multi : >"+ this.map.toString()+"<") ;
       int lastLine = 0;
        char status = getMap().charAt(0);
        while (++x < this.code.length()) {
         switch (status){
           case   Java3Code.MFCBLOCK:
                if ( getMap().charAt(x) == Java3Code.MFCOMM ){
                     x = addNewLine("", x - 1);
                     status = Java3Code.MFCOMM;
                     break;
                }
                if ( getMap().charAt(x) == Java3Code.MFCODE ){
                     x = addNewLine(deep, x - 1);
                     lastLine = x;
                     trim(x);
                     status = Java3Code.MFCODE;
                     break;
                }
                break;
           case   Java3Code.MFCOMM:
                if ( getMap().charAt(x) == Java3Code.MFCBLOCK ){
                     x = addNewLine("", x - 1);
                     status = Java3Code.MFCBLOCK;
                     break;
                }
                if ( getMap().charAt(x) == Java3Code.MFCODE ){
                     x = addNewLine(deep, x-1);
                     trim(x);
                     lastLine = x;
                     status = Java3Code.MFCODE;
                     break;
                }
                break;
           case   Java3Code.MFCODE:
              if ( getMap().charAt(x) == Java3Code.MFCBLOCK ){
                     x = addNewLine("", x-1);
                     status = Java3Code.MFCBLOCK;
                     break;
                }
                if ( getMap().charAt(x) == Java3Code.MFCOMM ){
                     x = addNewLine(deep, x-1);
                     trim(x);
                     lastLine = x;
                     status = Java3Code.MFCOMM;
                     break;
                }
 // special code processing
              if ( getMap().charAt(x) == Java3Code.MFCODE )
                switch (this.code.charAt(x)) {
                case '@':
                        // special for @
                        int sp = this.code.indexOf(" ", x);
                        int opar = this.code.indexOf("(", x);
                        int cpar = this.code.indexOf(")", x);
                        if ((opar > 0) && (cpar > 0)
                                && ((sp < 0) || (opar < sp + 2))
                                && (cpar < opar + 2)) {
                             x = addNewLine(deep, cpar );
                             lastLine = x;
                        } else if (sp > 0) {
                             x = addNewLine(deep, sp );
                             lastLine = x;
                        } else {
                            this.code.append('\n');
                            this.map.append('c');
                            return this;
                        }
                      break;
                case '{':
                     ppos = this.code.indexOf("[", lastLine);
 // a capo se non array
                    if ( !(ppos > 0 && ppos < x)) {
                        deep = deep + indent.charAt(0);
                        x = addNewLine(deep, x);
                        lastLine = x;
                        trim(x);
                    }
                    break;
               case '}':
// a capo dopo '};' (anonimous classes, array)
                    if ((x < this.code.length()-1) && (this.code.charAt(x + 1) == ';'))
                         break;

// a capo dopo '});' (anonimous classes, array)
                    if ((x < this.code.length()-2) && (this.code.charAt(x + 1) == ')'))
                         break;
                    trim(x);
                    ppos = this.code.indexOf("[", lastLine);
// a capo se non array
                    if ( !(ppos > 0 && ppos < x)) {
                        deep = deep.substring(1);
                        x = addNewLine(deep, x);
                        lastLine = x;
                        trim(x);
                        }
                    break;
               case ';':
                     trim(x);
// finale: skip
                    if (x >=this.code.length()-3 )
                        break;
// prima di un commento: skip
                     if ((x < this.code.length()-3 )&&
                        ( getMap().charAt(x+2) == Java3Code.MFCOMM || getMap().charAt(x+2) == Java3Code.MFCBLOCK))
                        break;
// inside a FOR condition: skip
                     int afor = this.code.indexOf(" for", lastLine);
                     if (afor < x){
                        int apar = this.code.indexOf("(", x);
                        int epar = this.code.indexOf(")", x);
                        if ((epar >0)&& (apar <0 || epar < apar))
                            break;
                    }
// code multiline: indent
                    if ((x > 2) && ((this.code.charAt(x - 1) == '}') || (this.code.charAt(x - 2) == '}')))
                         deep = deep.substring(1);
                    x = addNewLine(deep, x);
                    lastLine = x;
                }
          }
        }
   /*
        if (getCode().length() < 2){
            return this;
        }
        if (getMap().charAt(0) == Java3Code.MFCBLOCK) {
            while ((x < this.code.length())&& (getMap().charAt(x) == Java3Code.MFCBLOCK))
                x++;

            if (x < this.getCode().length()) {
                getCode().insert(x, '\n');
                getMap().insert(x, getMap().charAt(x));
            }
        }
        while (x < this.code.length()) {
            if (x > 1 && getMap().charAt(x - 1) == Java3Code.MFCOMM
                    && this.map.charAt(x) != Java3Code.MFCOMM) {
                this.code.insert(x, '\n');
                this.map.insert(x, this.map.charAt(x));
            }
       switch (this.code.charAt(x)) {
// notations
            case '@':
                if (this.map.charAt(x) == Java3Code.MFCODE) {
                    // special for @
                    int sp = this.code.indexOf(" ", x);
                    int opar = this.code.indexOf("(", x);
                    int cpar = this.code.indexOf(")", x);
                    if ((opar > 0) && (cpar > 0)
                            && ((sp < 0) || (opar < sp + 2))
                            && (cpar < opar + 2)) {
                        this.code.insert(cpar + 1, '\n');
                        this.map.insert(cpar + 1, 'c');
                        x = cpar;
                    } else if (sp > 0) {
                        this.code.insert(sp, '\n');
                        this.map.insert(sp, 'c');
                        x = sp;

                    } else {
                        this.code.append('\n');
                        this.map.append('c');
                        return this;
                    }
                }
                break;
            case '{':
                if (this.map.charAt(x) == Java3Code.MFCODE
                        && !(this.code.indexOf("[") > 0 && this.code
                                .indexOf("[") < x)) {
                    deep = deep + indent.charAt(0);
                    x = addNewLine(deep, x);
                    trim(x);
                }
                break;
            case '}':
                if (this.map.charAt(x) == Java3Code.MFCODE) {
// added 15/03/2015
                    if ((x < this.code.length()-1) && (this.code.charAt(x + 1) == ';')) break;
                    if (!(this.code.indexOf("[") > 0 && this.code.indexOf("[") < x)) {
                        deep = deep.substring(0, deep.length() - 1);
                        x = addNewLine(deep, x);
                        trim(x);
                    }
                }
                break;
            case ';':
             /*
// added 15/03/2015
                if (this.code.charAt(x - 1) == '}') {
                    if (!(this.code.indexOf("[") > 0 && this.code.indexOf("[") < x)) {
                        deep = deep.substring(0, deep.length() - 1);
                        x = addNewLine(deep, x);
                        break;
                    }
                }
                if (this.map.charAt(x) == Java3Code.MFCODE)
                    if (!(x < (this.code.length() - 2) && (this.map
                            .charAt(x + 2) == Java3Code.MFCOMM))) {
                        x = addNewLine(deep, x);
                    }
                    */
/*
                if (this.map.charAt(x) == Java3Code.MFCODE)
                    if ((x < (this.code.length() - 4) && (this.map
                            .charAt(x + 2) != Java3Code.MFCOMM))) {
                        x = addNewLine(deep, x);
                        trim(x);
                    }


                break;
            }
            x++;
        }
// block comments
        x = 0;
        if (this.code.length() > 5)
            while ((x = this.code.indexOf("\n", x)) > 0) {
                x++;
                while (x < this.code.length() - 2 && this.code.charAt(x) == ' ')
                    x++;
                if (x < this.code.length()
                        && this.map.charAt(x) == Java3Code.MFCBLOCK) {
                    while (x < this.code.length()
                            && this.map.charAt(x) == Java3Code.MFCBLOCK)
                        x++;
                    if (x < this.code.length() - 1
                            && !(this.code.charAt(x + 1) == '\n')) {
                        this.code.insert(x, '\n');
                        this.map.insert(x, this.map.charAt(x));
                    }
                }
            }
*/
        createMap();


// debug
//      System.out.println("exit multi : >"+ this.code.toString()+"<")	;
//      System.out.println("exit multi : >"+ this.map.toString()+"<") ;

		return this;
	}

	private int addNewLine(String deep, int x) {
		int y = x;
		this.code.insert(++y, '\n' + deep);
		for (int i = -1; i < deep.length(); i++)
			this.map.insert(y++, 'c');
		return y;
	}

	/**
	 * Test for String
	 * @param text
	 * @return boolean
	 */
	public boolean contains(String text) {
		if (this.status == codeStatus.VOID)
			return false;
		return this.code.indexOf(text) >= 0;
	}

	private String getComment(char type) {
		if (this.status == codeStatus.VOID)
			return "";
		if (this.status == codeStatus.USER) {
			createMap();
		}
		final StringBuilder x = new StringBuilder();
		for (int i = 0; i < getCode().length(); i++) {
			if (this.getMap().charAt(i) == type) {
				x.append(getCode().charAt(i));
			} else {
				if (this.code.charAt(i) == '\n') {
					x.append('\n');
				}
			}
		}
		return x.toString();
	}

	/**
	 * Returns Block Comment, or only "\n" for every code line.
	 * @return String
	 */
	public String getBlockComment() {
		return getComment(Java3Code.MFCBLOCK);
	}

	/**
	 * Returns Line Comment, or only "\n" for every code line.
	 * @return String
	 */
	public String getLineComment() {
		return getComment(Java3Code.MFCOMM);
	}

	/**
	 * getter for code StringBuilder
	 * @return the code
	 */
	public StringBuilder getCode() {
		return this.code;
	}

	/**
	 * @return the map
	 */
	public StringBuilder getMap() {
		return this.map;
	}

	/**
	 * getter for status
	 * @return the status
	 */
	public codeStatus getStatus() {
		return this.status;
	}

	/**
	 * @return StringList
	 */
	public StringList getStringList() {
		if (this.status == codeStatus.VOID)
			return null;
		return StringList.explode(getCode().toString(), "\n");
	}

	private boolean isCommented(char type) {
		if (this.status == codeStatus.VOID)
			return false;
		if (this.status == codeStatus.USER) {
			createMap();
		}
		return this.getMap().indexOf("" + type) >= 0;
	}

	/**
	 * Test if this.code contains Block comments.
	 * @return boolean
	 */
	public boolean isBlockCommented() {
		return isCommented(Java3Code.MFCBLOCK);
	}

	/**
	 * Test if this.code contains Line comments.
	 * @return boolean
	 */
	public boolean isLineCommented() {
		return isCommented(Java3Code.MFCOMM);
	}

	/*
	 * for Iterable interface
	 * @see java.lang.Iterable#iterator()
	 */

        public Iterator<String> iterator() {
        // TODO Auto-generated method stub
        return new Iterator<String>() {
            int index = 0;
            int start = 0;

            @Override
            public boolean hasNext() {
                if (Java3Code.this.getStatus() == codeStatus.VOID)
                    return false;
                return this.index < Java3Code.this.getCode().length();
            }

            @Override
            public String next() {
                this.start = this.index;
                while (this.index < Java3Code.this.getCode().length()
                        && Java3Code.this.getCode().charAt(this.index) != '\n') {
                    this.index++;
                }
                if (this.index < Java3Code.this.getCode().length()) {
                    this.index++;
                    return Java3Code.this.getCode().substring(this.start,
                            this.index - 1);
                }
                return Java3Code.this.getCode().substring(this.start,
                        this.index);
            }

            @Override
            public void remove() {
                Java3Code.this.getCode().delete(this.start, this.index);
                this.index = this.start;
            }

        };
    }



	/*
	 * Clean code from comments of type
	 */
	private Java3Code killBlock(char type) {
		if (!isCommented(type)) {
			return this;
		}
		int i = 0;
		while (i < getCode().length()) {
			if (this.getMap().charAt(i) == type) {
				getCode().deleteCharAt(i);
				this.getMap().deleteCharAt(i);
			} else {
				i++;
			}
		}
		return this;
	}

    public void putFirstComment(){
     int from, to = 0;

    }


	/**
	 * Clean the code killing both block and line comments.
	 * @return Java3Code
	 *
	 */
	public Java3Code killComments() {
		if (this.DECOMM) {
			return this;
		}
		killBlock(Java3Code.MFCBLOCK);
		killBlock(Java3Code.MFCOMM);
		this.DECOMM = true;
		return this;
	}

	/**
	 * Clean the code killing constant Strings.
	 * @return Java3Code
	 *
	 */
	public Java3Code killStrings() {
		if (this.DESTRING) {
			return this;
		}
		killBlock(Java3Code.MFSTRING);
		this.DESTRING = true;
		return this;
	}

	/**
	 * Only clean code, like killStrings + killComments and deletes also array index ("[..]").
	 * @return Java3Code
	 *
	 */
	public Java3Code onlyCode() {
		killStrings();
		killComments();
// kill [index]
		int start;
		int end;
		while (((start = getCode().indexOf("[")) >= 0)
				&& ((end = getCode().indexOf("]", start)) > start)) {
			getCode().delete(start, end + 1);
			this.getMap().delete(start, end + 1);
		}
		return this;
	}

	/**
	 * TODO  test not used
	 * @return String
	 */
	public String reduceToId() {
		final StringBuilder out = new StringBuilder();
		String scode = codeReduce(true);
		scode = scode.replaceAll(" [\\.=\\,;\\(\\)+>] ", " ");
		final String[] parts = scode.split(" ");
		for (String x : parts) {
			if (x.trim().equals("")) {
				continue;
			}
			// kills Class/object methods names
			if (x.indexOf('.') >= 0) {
				x = x.substring(0, x.indexOf('.'));
			}
			if (x.equals("")) {
				continue;
			}
			if (keywordsJava.contains(x)) {
				continue;
			}
			out.append(x + " ");
		}
//debug System.out.println("reduceToId :" + out);
		return out.toString();
	}

	/**
	 * Replaces all instances of from  with to
	 * @param from
	 * @param to
	 * @return int numero scambi
	 */
	public int replace(String from, String to) {
		if (this.status == codeStatus.VOID)
			return 0;
		int changes = 0;
		int start;
		while ((start = this.code.indexOf(from)) >= 0) {
			this.code.delete(start, start + from.length());
			this.code.insert(start, to);
			if (this.status == codeStatus.MAPPED) {
				this.map.delete(start, start + from.length());
				for (int i = 0; i < to.length(); i++)
					this.map.insert(start, this.map.charAt(start - 1));
			}
			changes++;
		}
//		if (changes > 0) {
//			resetUSERstatus();
//		}
		return changes;
	}

	/**
	 * Get an array with tokens (from spaceTokenize()).
	 * The newline are trimmed out.
	 * @return String[]
	 */
	public String[] getTokens() {
		String xcode = spaceTokenize(false).toString().trim();
		xcode.replace(" \n", "");
		return xcode.split(" ");
	}

	/**
	 * cut spaces at start and end
	 * @return Java3Code
	 */
	public Java3Code trim() {

		while ((this.code.length() > 0)
				&& ((this.code.charAt(0) == ' ')
						|| (this.code.charAt(0) == '\n') || (this.code
						.charAt(0) == '\t'))) {
			this.code.deleteCharAt(0);
			if (this.status == codeStatus.MAPPED) {
				this.map.deleteCharAt(0);
			}
		}
		while ((this.code.length() > 0)
				&& ((this.code.charAt(this.code.length() - 1) == ' ')
						|| (this.code.charAt(this.code.length() - 1) == '\n') || (this.code
						.charAt(this.code.length() - 1) == '\t'))) {
			this.code.deleteCharAt(this.code.length() - 1);
			if (this.status == codeStatus.MAPPED) {
				this.map.deleteCharAt(this.code.length() - 1);
			}
		}
		return this;
	}


    public Java3Code trim(int pos) {
                 while ( pos < this.code.length() &&
                    (this.getMap().charAt(pos) == Java3Code.MFCODE) &&
                    ((this.code.charAt(pos) == ' ') || (this.code.charAt(pos) == '\t'))){
                        this.getCode().deleteCharAt(pos);
                        this.getMap().deleteCharAt(pos);
                    }
        return this;
        }


	private boolean testJavaKeyword(String test, StringList javaKey, int pos,
			int size) {
		for (int j = 0; j < javaKey.count(); j++) {
			if (test.equals(javaKey.get(j))) {
//debug			System.out.println("found 4:" + test4);
				getCode().delete(pos, pos + size);
				this.getMap().delete(pos, pos + size);
				getCode().insert(pos, " " + test + " ");
				switch (size) {
				case 4:
					this.getMap().insert(pos, "cccccc");
					break;
				case 3:
					this.getMap().insert(pos, "ccccc");
					break;
				case 2:
					this.getMap().insert(pos, "cccc");
					break;
				default:
					this.getMap().insert(pos, "ccc");
				}
				return true;
			}
		}

		return false;
	}

	private boolean isGlobal(String token, StringList globalVars) {
		for (int i = 0; i < globalVars.count(); i++) {
			if (globalVars.get(i).equals(token)) {
				return true;
			}
			if (globalVars.get(i).startsWith(token + "_")) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Set Extended map for color evidence for this.
	 * The code is not changed/tokenized, only map is updated.
	 * @param variables StringList
	 * @param globalVars StringList
	 * @return this
	 */
	public Java3Code colorMap(StringList variables, StringList globalVars) {
		createMap();
		final Java3Code tmp = this.clone();
		tmp.spaceTokenize(true);
		final String[] parts = tmp.getTokens();
		int pos = 0;
		for (int i = 0; i < parts.length; i++) {
			if (parts[i] == " ") {
				continue;
			}
			if (parts[i] == "") {
				continue;
			}
			pos = this.getCode().indexOf(parts[i], pos);
			char mapCode = getMap().charAt(pos);
// code update
			if (mapCode == Java3Code.MFSTRING || mapCode == Java3Code.MFCBLOCK
					|| mapCode == Java3Code.MFCOMM) {
				continue;
			}
			boolean extend = false;
			if (isGlobal(parts[i], globalVars)) {
				mapCode = Java3Code.EVGLOBAL;
				extend = true;
			} else if (parts[i].equals("?") && this.contains(":")) {
// special processing for "?" as java conditional operator
				mapCode = Java3Code.EVOP;
				extend = true;
			} else if (Java3Code.keywordsJava.contains(parts[i])) {
// processing "?" as java keyword in conditionals
				mapCode = Java3Code.EVJAVA;
				extend = true;
			} else if (variables.contains(parts[i])) {
				mapCode = Java3Code.EVVAR;
				extend = true;
			} else if (Java3Code.evidenceSigns.contains(parts[i])) {
				mapCode = Java3Code.EVOP;
				extend = true;
			}
			if (extend) {
				for (int j = pos; j < pos + parts[i].length(); j++) {
					this.map.setCharAt(j, mapCode);
				}
			}
			pos += parts[i].length();
		}
		return this;
	}

	/**
	 * formats a code line using exactly 1 space as separator.
	 * Strings and comments (if any) are not modified.
	 * Operators are single token (1,2,3 o 4 char long).
	 * This method don't parses: dot '.' and (optional) square parenthesis '[]'
	 * @param alsoSquare if true processes as tokens also square parenthesis '[]'
	 * @return Java3Code
	 */
	public Java3Code spaceTokenize(boolean alsoSquare) {
		if (this.TOKENIZED) {
			return this;
		}
		if (this.status == codeStatus.USER) {
			createMap();
		}
		if (getCode().length() < 1) {
			return this;
		}
// start space
		this.code.insert(0, ' ');
		this.map.insert(0, this.map.charAt(0));
// end space
		this.code.append(' ');
		this.map.append(this.map.charAt(this.map.length() - 1));
// debug  System.out.println("S spaceTokenize "+this.code.toString());
// debug  System.out.println("M spaceTokenize "+this.map.toString());

		int i = 0;
		while (i < this.code.length()) {
			switch (this.code.charAt(i)) {
			 case '\r':
                if (this.getMap().charAt(i) == Java3Code.MFCODE){
                   getCode().deleteCharAt(i);
                   this.getMap().deleteCharAt(i);
                   i--;
                   continue;
                }
             case '\t':
                if (this.getMap().charAt(i) == Java3Code.MFCODE){
                   getCode().deleteCharAt(i);
                   this.getMap().deleteCharAt(i);
                   i--;
                   continue;
                }

            case '"':
				if ((this.getMap().charAt(i - 1) == Java3Code.MFCODE)
						&& (this.getMap().charAt(i) == Java3Code.MFSTRING)) {
					getCode().insert(i, " ");
					this.getMap().insert(i, Java3Code.MFCODE);
				}
				if ((this.getMap().charAt(i - 1) == Java3Code.MFSTRING)
						&& (this.getMap().charAt(i + 1) == Java3Code.MFCODE)) {
					getCode().insert(i + 1, " ");
					this.getMap().insert(i + 1, Java3Code.MFCODE);
				}
				i = i + 2;
				continue;
			case '\n':
				getCode().insert(i + 1, " ");
				this.getMap().insert(i + 1, this.getMap().charAt(i));
			}
			if (!(this.getMap().charAt(i) == Java3Code.MFCODE)) {
				i++;
				continue;
			}
			if (Character.isLetterOrDigit(getCode().charAt(i))) {
				i++;
				continue;
			}
			if (i + 4 <= getCode().length()) {
				final String test4 = getCode().substring(i, i + 4);
				if (testJavaKeyword(test4, all4Signs, i, 4)) {
					i = i + 6;
					continue;
				}
			}
			if (i + 3 <= getCode().length()) {
				final String test3 = getCode().substring(i, i + 3);
				if (testJavaKeyword(test3, all3Signs, i, 3)) {
					i = i + 5;
					continue;
				}
			}

			if (i + 2 <= getCode().length()) {
				final String test2 = getCode().substring(i, i + 2);
				if (testJavaKeyword(test2, all2Signs, i, 2)) {
					i = i + 4;
					continue;
				}
			}

			final String test1 = getCode().substring(i, i + 1);
// skips
			if (test1.equals(" ") || test1.equals(".")) {
				i++;
				continue;
			}
			if (alsoSquare) {
				if (testJavaKeyword(test1, all1Signs, i, 1)) {
					i = i + 3;
					continue;
				}
			} else {
				if (!(test1.equals("[") || test1.equals("]"))) {
					if (testJavaKeyword(test1, all1Signs, i, 1)) {
						i = i + 3;
						continue;
					}
				}
			}
			i++;
		}
// clean double spaces
		for (int sp = 0; (sp = getCode().indexOf("  ", sp)) >= 0;) {
			if (this.getMap().charAt(sp) == 'c') {
				getCode().deleteCharAt(sp);
				this.getMap().deleteCharAt(sp);
			} else
				sp++;
		}
//debug		System.out.println("Tokenyze >" + this.code.toString());
//debug		System.out.println("and map  >" + this.getMap().toString());
		this.TOKENIZED = true;
		return this;
	}

	/**
	 * @param c
	 * @return boolean
	 */
	public boolean startsWith(String c) {
		return this.code.indexOf(c) == 0;
	}

	@Override
	public String toString() {
		return getCode().toString();
	}
 // 12/3/2015 added - block multiline
static boolean inBlockMultiline = false;
	/*
	 * Analyzes code and sets Map.
	 * Marks single chars as: CODE, CHAR, STRING, BLOCK COMMENT, LINE COMMENT
	 * Don't modifies code data.
	 */
	private void createMap() {
		if (this.status == codeStatus.MAPPED) {
			return;
		}
		this.map = new StringBuilder(getCode());
		char actual = Java3Code.MFCODE;
// 12/3/2015 added - block
        if (inBlockMultiline)
            actual = Java3Code.MFCBLOCK;
        int countSlash = 0;
		for (int i = 0; i < getCode().length(); i++) {
			final char c = getCode().charAt(i);
// end of state
            if (actual == Java3Code.MFCBLOCK && i > 0
                    && getCode().charAt(i) == '/'
                    && getCode().charAt(i - 1) == '*') {
                inBlockMultiline  = false;
            }
 // 12/3/2015 modified - block
			if (actual == Java3Code.MFCBLOCK && i > 1
					&& getCode().charAt(i - 1) == '/'
					&& getCode().charAt(i - 2) == '*') {
				actual = Java3Code.MFCODE;
			}
			if (actual == Java3Code.MFSTRING && i > 1
					&& this.getMap().charAt(i - 2) == Java3Code.MFSTRING
					&& getCode().charAt(i - 1) == '"'){
                    if( countSlash % 2 == 0) {
                         actual = Java3Code.MFCODE;
                         }
 // 12/3/2015 modified - bug in countSlash
                    countSlash = 0;
 			}
			if (actual == Java3Code.MFCHAR && i > 1
					&& this.getMap().charAt(i - 2) == Java3Code.MFCHAR
					&& getCode().charAt(i - 1) == '\'') {
				actual = Java3Code.MFCODE;
            }
			switch (c) {
			case '/':
				countSlash = 0;
				if (actual == Java3Code.MFCODE && getCode().length() > i + 1) {
					if (getCode().charAt(i + 1) == '*') {
						actual = Java3Code.MFCBLOCK;
                        inBlockMultiline = true;
					}
					if (getCode().charAt(i + 1) == '/') {
						actual = Java3Code.MFCOMM;
					}
				}
				break;
			case '\\':
				if (actual == Java3Code.MFSTRING) {
					countSlash++;
				}
				break;
			case '"':
                if (actual == Java3Code.MFCODE) {
					actual = Java3Code.MFSTRING;
                    countSlash = 0;
               }
  				break;
			case '\n':
				if (actual == Java3Code.MFCOMM) {
					actual = Java3Code.MFCODE;
				}
				countSlash = 0;
				break;
			case '\'':
				if (actual == Java3Code.MFCODE) {
					actual = Java3Code.MFCHAR;
				}
				countSlash = 0;
				break;

			default:
				countSlash = 0;
			}
			this.getMap().setCharAt(i, actual);
		}
		this.status = codeStatus.MAPPED;
//debug		System.out.println("code: >" + getCode().toString().replace('\n', '|') + "<");
//debug		System.out.println("map : >" + this.getMap().toString() + "<");
	}

	/*
	// TODO never used
		private void resetUSERstatus() {
			this.status = codeStatus.USER;
			this.TOKENIZED = false;
			this.DECOMM = false;
			this.DESTRING = false;

		}
	*/
	/**
	 *
	 * @return StringList
	 */
	public StringList parseVarNames() {
		StringList vars = new StringList();
		this.onlyCode().spaceTokenize(false);
		for (String s : this) {
			if (s.trim().equals("")) {
				continue;
			}
			final String[] parts = s.trim().split(" ");
			lineParts2Vars(parts, vars, false);
		}
		return vars;
	}

	/**
	 * Extracts Method name from a declaration or a Call code
	 * @return the Method name
	 */
	public String getMethodName() {
		this.spaceTokenize(false);
		final String[] parts = getTokens();
		for (int i = 1; i < parts.length; i++) {
			if (parts[i].equals("(") && !parts[i - 1].startsWith("@")) {
				return parts[i - 1];
			}
		}
		if (this.contains(" main "))
			return "main";
		return null;
	}

	/**
	 * Extracts the type from a method declaration
	 * @return String
	 */
	public String getMethodType() {
//debug		System.out.println("decl >" +decl);
		String type = "";
		final String mName = getMethodName();
		if (mName == null)
			return "";
		final String[] parts = getTokens();
		int i = 0;
		while (i < parts.length && parts[i].startsWith("@")) {
			while (i < parts.length && !parts[i].equals(")")) {
				i++;
			}
			i++;
		}
		while (i < parts.length && inArray(javaAllKeywords, parts[i])
				&& !inArray(javaTypes, parts[i])) {
			i++;
		}
		final int start = i;
		while (i < parts.length && !parts[i].equals(mName)) {
			if (parts[i].equals("<") || parts[i].equals(">") || i == start
					|| parts[i - 1].equals("<") || parts[i - 1].equals(">")) {
				type += parts[i++];
			} else {
				type += " " + parts[i++];
			}
		}
//debug		System.out.println("== type <" +type);
		return type;
	}

	private int skipNotations(String[] parts) {
		int i = 0;
		while (i < parts.length && parts[i].startsWith("@")) {
			while (i < parts.length && !parts[i].equals(")")) {
				i++;
			}
			i++;
		}
		return i;
	}

	/**
	 * extracts parameter names from method declaration, in order
	 * @return StringList parameters
	 */
	public StringList getParamNames() {
		final StringList n = new StringList();
		final String[] parts = getTokens();
		int i = skipNotations(parts);
		for (; i < parts.length; i++) {
//debug				System.out.println("parts["+i+"]="+parts[i]);
			if (parts[i].equals(",") && parts[i - 1].length() > 0) {
				n.add(parts[i - 1]);
			}
			if (parts[i].equals(")") && !parts[i - 1].equals("(")) {
				n.add(parts[i - 1]);
			}
		}
//debug		System.out.println("param >" + n.count() + n.getCommaText());
		return n;
	}

	private int addParamType(String[] parts, StringList n, int pos) {
		int i = pos;
		if (parts[i + 1].equals("final")) {
			i++;
		}
		if (parts[i + 2].equals("<")) {
			n.add(parts[i + 1] + parts[i + 2] + parts[i + 3] + parts[i + 4]);
		} else if (parts[i + 2].equals("[")) {
			n.add(parts[i + 1] + parts[i + 2] + parts[i + 3]);
		} else {
			n.add(parts[i + 1]);
		}
		return i;
	}

	/**
	 * extracts parameter types from method declaration, in order
	 * @return StringList parameters
	 */
	public StringList getParamTypes() {
		final StringList n = new StringList();
		final String[] parts = getTokens();
		int i = skipNotations(parts);
		for (; i < parts.length; i++) {
//				System.out.println("parts["+i+"]="+parts[i]);
			if (parts[i].equals(",") && parts[i + 1].length() > 0) {
				i = addParamType(parts, n, i);
			}
			if (parts[i].equals("(") && !parts[i + 1].equals(")")) {
				i = addParamType(parts, n, i);
			}

		}
//debug		System.out.println("param >" + n.count() + n.getCommaText());
		return n;
	}

	/**
	 * extract potential var names from a code line, split in parts[].
	 * Low level utility,
	 * @param parts a line split in parts[]
	 * @param vars StringList for found variables
	 * @param alsoDefs if true, special process for declarations, else standard source code
	 */
	static public void lineParts2Vars(String[] parts, StringList vars,
			boolean alsoDefs) {
		for (int k = 0; k < parts.length; k++) {
			if (alsoDefs) {
				// varlist
				if (k > 0 && parts[k].equals(",")) {
					addKpart(parts, vars, k - 1);
					continue;
				}
				// object x;
				// for definitions only, last part (definition without assign)
				if (k == parts.length - 1) {
					addKpart(parts, vars, k);
					break;
				}
			}
			// x = 3;
			// left element in assign
			if (k > 0 && parts[k].equals("=")) {
				addKpart(parts, vars, k - 1);
				break;
			}

			// read x
			if (k > 0 && parts[k - 1].equals(input.trim())) {
				addKpart(parts, vars, k);
				break;
			}

			// write x
			if (k > 0 && parts[k - 1].equals(output.trim())) {
				addKpart(parts, vars, k);
				break;
			}
			/*
						// int x,y; vars without assign (simple types)
						if (k > 0 && parts[k].length() > 0
								&& Character.isJavaIdentifierStart(parts[k].charAt(0))) {
							for (final String aType : javaTypes) {
								if (parts[0].equals(aType)) {
									vars.addIfNew(parts[k]);
									break;
								}
							}
						}
			*/
		}
	}

	private static void addKpart(String[] parts, StringList vars, int k) {
		if (parts[k].length() > 0
				&& Character.isJavaIdentifierStart(parts[k].charAt(0))) {
			vars.addIfNew(parts[k]);
		}
	}

	/**
	 * test an identifier name against java naming rules.
	 * @param str the identifier.
	 * @return true: java compatible (try it using '#' char)
	 */
	public static boolean testIdentifier(String str) {
		String _str = str.trim();
		if (_str.equals("")) {
			return false;
		}
		if (_str.contains(".")) {
			_str = _str.substring(_str.lastIndexOf(".") + 1);
		}
		if (!Character.isJavaIdentifierStart(_str.charAt(0))) {
			return false;
		}
		for (int i = 1; i < _str.length(); i++) {
			if (!Character.isJavaIdentifierPart(_str.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Increments the field "build" in "@version" javadoc tag.
	 * If "@version" is not present does nothing.
	 * Processes only  first "@version" tag.
	 * @param comment from an RootElement
	 * @return comment updated, or original.
	 */
	public static StringList updateBuild(StringList comment) {
		int pos = 0;
		for (int i = 0; i < comment.count(); i++) {
//debug			System.out.println("comment[" + i + "]:" + comment.get(i));
			if (comment.get(i).trim().startsWith("@version")) {
				pos = i;
				break;
			}
		}
		if (pos == 0) {
			return comment;
		}
		final String ver = comment.get(pos).trim();
		final String[] parts = ver.split(" ");
		int x = 0;
		final StringBuffer newVer = new StringBuffer();
		int build = 0;
		if (ver.contains(" build ")) {
			while (!parts[x].equals("build") && x < parts.length - 2) {
				newVer.append(" " + parts[x++]);
			}
			build = Integer.parseInt(parts[++x]);
		} else {
			if (parts.length > 1) {
				newVer.append(" " + parts[0] + " " + parts[1]);
			} else {
				newVer.append(" " + parts[0] + " 1.0.0");
			}
			x = -1;
		}
		final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		newVer.append(" build " + (build + 1) + "  ("
				+ sdf.format(Calendar.getInstance().getTime()) + ")");
		for (int i = x + 3; i < parts.length; i++) {
			newVer.append(" " + parts[i]);
		}
		comment.set(pos, newVer.toString());
		return comment;
	}

// test for value in array
	private static boolean inArray(String[] array, String value) {
		for (final String s : array) {
			if (s.equals(value)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Utility, tests String (e.g. condition) for parenthesis
	 * @param code a code fragment (trimmed) to be parenthesized
	 * @return true if code needs parenthesis
	 */
	public static boolean needsPar(String code) {
// no comments in conditions !
		final String txt = new Java3Code(code).killStrings().toString();
		if (txt.length() == 0)
			return true;
		int zeroPoints = 0;
		int deep = 0;
		for (int i = 0; i < txt.length(); i++) {
			switch (txt.charAt(i)) {
			case '(':
				deep++;
				break;
			case ')':
				deep--;
				if (deep <= 0) {
					zeroPoints++;
				}
				break;
			case ' ':
				break;
			default:
				if (deep <= 0) {
					return true;
				}
			}
		}
		if (zeroPoints > 1) {
			return true;
		}
		return false;
	}

	/**
	 * Utility: trims "(" and ")" from a string (smart)
	 * @param text code fragment
	 * @return same, but terminals "(" and ")" removed if allowed
	 */
	public static String deParenthesizeIt(String text) {
		if (text == null) {
			return null;
		}
		final String s = text.trim();
		if (s.length() < 2) {
			return s;
		}
		if (needsPar(s)) {
			return s;
		}
		return s.substring(1, s.length() - 1);
	}

	/**
	 * Utility: adds smart "(" and ")" to a string (e.g. a condition)
	 * @param text code fragment
	 * @return same, but "(" and ")" added if necessary
	 */
	public static String parenthesizeIt(String text) {
		/*
		 */
		if (text == null) {
			return null;
		}
		final String s = text.trim();
		if (needsPar(s)) {
			return "(" + s + ")";
		}
		return s;
	}

	/**
	 * cuts  final semicolon, if any
	 * @param code a code line
	 * @return  same, but final ";" timmed
	 */
	public static String lineTrimSColon(String code) {
		final String tCode = code.trim();
//debug		System.out.println("lineTrim: "+ tCode);
		if (tCode.endsWith(";")) {
			return tCode.substring(0, tCode.length() - 1).trim();
		}
		return tCode;
	}

	/**
	 * Smart add final semicolon
	 * @param code a final formatted code line.
	 * @return same, but added ";" if necessary
	 */
	public static String lineAddSColon(String code) {
// debug  System.out.println( "line AddSClon in: "+ code);
// 25/03/2015: trim cuts also starting \t for indentation
//	   String tCode = code.trim();
//     debug   System.out.println ("in lineAddSColon.trim() : >" + code.replace("\r","R").replace("\n","N").replace("\t","T").replace(" ","-")+"<") ;
      if (code.equals("")) {
            return "";
        }
        String indent = "";
        int i = 0;
        while (code.charAt(i++) == '\t')
                 indent +="\t";
        String tCode = code.trim();
// debug       System.out.println ("in lineAddSColon.trim() : >" + tCode.replace("\r","R").replace("\n","N").replace("\t","T").replace(" ","-")+"<") ;
// no adding ";" cases
		if (tCode.equals("")) {
            return  "";
		}
		if (tCode.endsWith(";")) {
            return indent + tCode;
		}
// added 13/3/2015 for labels
        if (tCode.endsWith(":")) {
            return  indent + tCode;
        }

		if (tCode.endsWith("{")) {
            return  indent + tCode;
		}
		if (tCode.endsWith("*/")) {
            return tCode;
		}
		if (tCode.startsWith("//")) {
			return tCode;
		}
// added 20/02/2012
		if (tCode.startsWith("@")) {
            return  indent + tCode;
		}
// modified 24/03/2015
		// for multiline block ends vs one line array decl.
		int startLLine = tCode.lastIndexOf("\n");
        if( startLLine < 0)
            startLLine = 0;
        if (tCode.endsWith("}") && !(tCode.indexOf("{",startLLine) >0 )&& !(tCode.indexOf("[",startLLine) >0 )) {
			// is block end, no ';'
            return  indent + tCode;
		}
        return  indent + tCode + ";";
	}

	/**
	 * Cosmetic cleanup for java code lines
	 * note: Strings constants are not modified.
	 * @param text a code string using a single space separator (like from spaceTokens)
	 * @return same, but having space deleted before/after special characters
	 */
	public static String lineCosmetic(String text) {
//debug System.out.println("cosm-in:>" + text.replace("\t","T").replace(" ","-").replace("\n","N").replace("\r","R")+"<");
		String out = "";
//		if (text == null || text.trim().equals("")) {
//			return null;
//		}
// 22/03/2015 to accept empty lines
      if (text == null || text.trim().equals("")) {
            return text;
      }

		int countSlash = 0;
		char pre = '=';
		boolean insideComment = false;
		boolean insideString = false;
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			switch (c) {
// pre/post increment/decrement
			case '+':
			case '-':
				if (!insideComment && !insideString) {
					// pre
					if (pre == c && i + 2 < text.length()
							&& text.charAt(i + 1) == ' '
							&& Character.isLetter(text.charAt(i + 2))) {
						out += c;
						c = ' ';
						break;
					}
					// post
					if (pre == c && out.charAt(out.length() - 2) == ' '
							&& Character.isLetter(out.charAt(out.length() - 3))) {
						out = out.substring(0, out.length() - 2) + c;
					}
				}
				out += c;
				break;
			case '/':
				if (i + 1 < text.length() && text.charAt(i + 1) == '*') {
					insideComment = true;
					out += c;
					break;
				}
				if (i > 0 && text.charAt(i - 1) == '*') {
					insideComment = false;
					out += c;
					break;
				}
				out += c;
				break;
			case '\\':
				countSlash++;
				out += c;
				break;
			case ' ':
				if (!insideComment && !insideString) {
					// cutting spaces after this:
                    //  26/03/2015 added @
                    if (pre != '(' && pre != '!' && pre != '@') {
						out += c;
					}

				} else {
					out += c;
				}
				countSlash = 0;
				break;

			case '"':
				if (pre != '\\' || countSlash % 2 == 0) {
					insideString = !insideString;
				}
				countSlash = 0;
				out += c;
				break;
// 22/03/2015 added
            case '.':
            case '[':
// cutting space before this:
            case ',':
			case ';':
			case ')':

// in some cases (enum def.)  more than one space are between tokens ( see generateCode(JClass) )
				if (!insideComment && !insideString)
				    while( out.endsWith(" ")) {
				     	out = out.substring(0, out.length() - 1);
				    }
				countSlash = 0;
				out += c;
				break;
// conditional cutting space before this:
			case '(':
				if (!insideComment && !insideString && out.endsWith(" ")) {
					if (Character
							.isJavaIdentifierPart(out.charAt(out.length() - 2))) {
						out = out.substring(0, out.length() - 1);
					}
				}
				countSlash = 0;
				out += c;
				break;
// added 22/03/2015   cutting spaces in <type>
            case '>':
                if (!insideComment && !insideString) {
                     int spos = out.lastIndexOf("<");
                     if ((spos >0)&&(spos<out.length() - 4)){
                        boolean  cut = (out.charAt(spos+1)==' ');
                        cut &= Character.isJavaIdentifierStart(out.charAt(spos+2));
                        for (int k = spos+3; k < (out.length()-1); k++){
                              cut &= Character.isJavaIdentifierPart(out.charAt(k));
                        }
                        if (cut){
//debug System.out.println("prima :"+out+":")  ;
                            out = out.substring(0,spos+1)+ out.substring(spos+1,out.length()-1).trim() + ">";
//debug System.out.println("dopo  :"+out+":")  ;
                            countSlash = 0;
                            break;
                        }
                    }
                }
                out += c;
                countSlash = 0;
                break;
// for imports
			case '*':
				if (!insideComment && !insideString && out.endsWith(". ")) {
					out = out.substring(0, out.length() - 1);
				}
				countSlash = 0;
				out += c;
				break;
// skip chars
			case '\n':
				break;

			default:
				countSlash = 0;
				out += c;
			}
			pre = c;
		}
		while (out.endsWith(" ")) {
			out = out.substring(0, out.length() - 1);
		}

//debug System.out.println("cosm-out:>" + out.replace("\t","T").replace(" ","-").replace("\n","N").replace("\r","R")+"<");

		return out;
	}

	private static void init() {
//debug		System.out.println("IN Java3Code.INIT()");
		evidenceSigns = new StringList();
		keywordsJava = new StringList();
		all1Signs = new StringList();
		all2Signs = new StringList();
		all3Signs = new StringList();
		all4Signs = new StringList();

		evidenceSigns.add("!");
		evidenceSigns.add("~");
		evidenceSigns.add("&");
		evidenceSigns.add("|");
		evidenceSigns.add("^");
		evidenceSigns.add("+");
		evidenceSigns.add("-");
		evidenceSigns.add("*");
		evidenceSigns.add("/");
		evidenceSigns.add("%");
		evidenceSigns.add("<");
		evidenceSigns.add(">");
		evidenceSigns.add("=");
		evidenceSigns.add("?");
		evidenceSigns.add(":");
		evidenceSigns.add("'");
		evidenceSigns.add("\"");

		all1Signs.add(evidenceSigns);
		all1Signs.add("{");
		all1Signs.add("}");
		all1Signs.add("[");
		all1Signs.add("]");
		all1Signs.add("(");
		all1Signs.add(")");
		all1Signs.add(".");
		all1Signs.add(",");
		all1Signs.add(";");
		all1Signs.add("\\");
//		all1Signs.add("@");

		all2Signs.add("/*");
		all2Signs.add("*/");
		all2Signs.add("//");
		all2Signs.add("++");
		all2Signs.add("--");
		all2Signs.add("||");
		all2Signs.add("&&");
		all2Signs.add("<=");
		all2Signs.add(">=");
		all2Signs.add("==");
		all2Signs.add("!=");
		all2Signs.add(">>");
		all2Signs.add("<<");
		all2Signs.add("&=");
		all2Signs.add("|=");
		all2Signs.add("^=");
		all2Signs.add("+=");
		all2Signs.add("-=");
		all2Signs.add("*=");
		all2Signs.add("/=");
		all2Signs.add("%=");
// added 13/3/2015
        all2Signs.add("->");  // lamda
        all2Signs.add("::");  // reference


		evidenceSigns.add(all2Signs);

		all3Signs.add(">>>");
		all3Signs.add("<<<");
		all3Signs.add(">>=");
		all3Signs.add("<<=");
		all3Signs.add("/**");
		evidenceSigns.add(all3Signs);

		all4Signs.add(">>>=");
		all4Signs.add("<<<=");
		evidenceSigns.add(all4Signs);

		// all local keywords
		keywordsJava.add(input);
		keywordsJava.add(output);

		keywordsJava.add(preAlt);
		keywordsJava.add(preCase);
		keywordsJava.add(preFor);
		keywordsJava.add(preRepeat);
		keywordsJava.add(preWhile);

		keywordsJava.add(postAlt);
		keywordsJava.add(postCase);
		keywordsJava.add(postFor);
		keywordsJava.add(postRepeat);
		keywordsJava.add(postWhile);

		// expanded to all java language keywords
		for (final String kw : javaAllKeywords) {
			keywordsJava.add(kw);
		}
	}

	/**
	 *
	 */
	public static void loadFromINI() {
		try {
			final Ini ini = Ini.getInstance();
			ini.load();
			// elements
			preAlt = ini.getProperty("ParserPreAlt", preAlt);
			postAlt = ini.getProperty("ParserPostAlt", postAlt);
			preCase = ini.getProperty("ParserPreCase", preCase);
			postCase = ini.getProperty("ParserPostCase", postCase);
			preFor = ini.getProperty("ParserPreFor", preFor);
			postFor = ini.getProperty("ParserPostFor", postFor);
			preWhile = ini.getProperty("ParserPreWhile", preWhile);
			postWhile = ini.getProperty("ParserPostWhile", postWhile);
			preRepeat = ini.getProperty("ParserPreRepeat", preRepeat);
			postRepeat = ini.getProperty("ParserPostRepeat", postRepeat);
			input = ini.getProperty("ParserInput", input);
			output = ini.getProperty("ParserOutput", output);
			dateFormat = ini.getProperty("dateFormat", dateFormat);
		} catch (final Exception e) {
			System.err.println(e);
		}
		init();
	}

	/**
	 *
	 */
	public static void saveToINI() {
		try {
			final Ini ini = Ini.getInstance();
			ini.load(); // elements
			ini.setProperty("ParserPreAlt", preAlt);
			ini.setProperty("ParserPostAlt", postAlt);
			ini.setProperty("ParserPreCase", preCase);
			ini.setProperty("ParserPostCase", postCase);
			ini.setProperty("ParserPreFor", preFor);
			ini.setProperty("ParserPostFor", postFor);
			ini.setProperty("ParserPreWhile", preWhile);
			ini.setProperty("ParserPostWhile", postWhile);
			ini.setProperty("ParserPreRepeat", preRepeat);
			ini.setProperty("ParserPostRepeat", postRepeat);
			ini.setProperty("ParserInput", input);
			ini.setProperty("ParserOutput", output);
			ini.setProperty("dateFormat", dateFormat);

			ini.save();
		} catch (final Exception e) {
			System.err.println(e);
		}
	}

}
