/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.utils;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    A dynamic list of strings.
 *						Copies the behaviour of a "TStringList" in Delphi.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.09      First Issue
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Vector;

/**
 *
 */
public class StringList {

	private final Vector<String> strings = new Vector<String>();

	/**
	 *
	 */
	public void clear() {
		this.strings.clear();
	}

	/**
	 * @param _string
	 * @return String
	 */
	public static StringList getNew(String _string) {
		final StringList sl = new StringList();
		sl.add(_string);
		return sl;
	}

	/**
	 * @param lines
	 * @return StringList
	 */
	public static StringList getNew(ArrayList<String> lines) {
		final StringList sl = new StringList();
		for (String string : lines) {
			sl.add(string);
		}
		return sl;
	}

	/**
	 * @param _source
	 * @param _by
	 * @return StringList
	 */
	public static StringList explode(String _source, String _by) {
		final String[] multi = _source.split(_by);
		final StringList sl = new StringList();

		for (final String element : multi) {
			sl.add(element);
		}
		return sl;
	}

	/**
	 * 02/03/2011 m.s. added
	 * @param head
	 * @param _new
	 */
	public void addReplace(String head, String _new) {
		int pos = getHeadPosition(head);
		if (pos >=0)
			this.strings.set(pos, _new);
		else
			add(_new);
	}

	/**
	 * 02/03/2011 m.s. added
	 * replaces only full words
	 * @param _old
	 * @param _new
	 * @return int
	 */
	public int codeReplace(String _old, String _new) {
//debug		System.out.println("replace: " +  _old +" ==> "+ _new );
		int n = 0;
		for (int s = 0; s < this.strings.size(); s++) {
			boolean found = false;
			String line = this.strings.get(s);
			int x = 0;
			int y = -1;
			do {
				y = line.indexOf(_old, x);
				if (y >= 0) {
					final String pre = line.substring(0, y);
					final String post = line.substring(y + _old.length());
//debug		System.out.println("pre:" + pre + " post:" + post);
					if (pre.length() < 1
							|| !Character.isJavaIdentifierPart(pre
									.charAt(y - 1))) {
						if (post.length() < 1
								|| !Character.isJavaIdentifierPart(post
										.charAt(0))) {
//debug		System.out.println("replace:" + pre + _new + post);
							line = pre + _new + post;
							found = true;
							n++;

						}
					}
					x = y + _new.length();
				}

			} while (y >= 0);
			if (found) {
				this.strings.set(s, line);
			}
		}

		return n;
	}

	/**
	 * @param _source
	 * @param _by
	 * @return StringList
	 */
	public static StringList explodeWithDelimiter(String _source, String _by) {
		final String[] multi = _source.split(_by);
		final StringList sl = new StringList();

		for (int i = 0; i < multi.length; i++) {
			if (i != 0) {
				sl.add(_by);
			}
			sl.add(multi[i]);
		}

		return sl;
	}

	/**
	 * @param _source
	 * @param _by
	 * @return StringList
	 */
	public static StringList explodeWithDelimiter(StringList _source, String _by) {
		final StringList sl = new StringList();

		for (int s = 0; s < _source.count(); s++) {
			final StringList multi = BString.explodeWithDelimiter(
					_source.get(s), _by);
			sl.add(multi);
		}

		return sl;
	}

	/**
	 * @return StringList
	 */
	public StringList copy() {
		final StringList sl = new StringList();
		//sl.add("TEXT");
		sl.setCommaText(getCommaText() + "");
		return sl;
	}

	/**
	 * @param _string
	 */
	public void add(String _string) {
		this.strings.add(_string);
	}

	/**
     * 02/03/2011 m.s. added
	 * @param _string
	 */
	public void addLines(String _string) {
		final String[] multi = _string.split("\n");
		for (final String s : multi)
			this.strings.add(s);
	}

	/**
	 * @param _string
	 */
	public void addOrdered(String _string) {
		if (count() == 0) {
			add(_string);
		} else {
			boolean inserted = false;
			for (int i = 0; i < this.strings.size(); i++) {
				if (this.strings.get(i).compareTo(_string) > 0) {
					this.strings.insertElementAt(_string, i);
					inserted = true;
					break;
				}
			}

			if (inserted == false) {
				add(_string);
			}
		}
	}

	/**
	 * @param _string
	 */
	public void addByLength(String _string) {
		if (count() == 0) {
			add(_string);
		} else {
			boolean inserted = false;
			for (int i = 0; i < this.strings.size(); i++) {
				if (this.strings.get(i).length() < _string.length()) {
					this.strings.insertElementAt(_string, i);
					inserted = true;
					break;
				}
			}

			if (inserted == false) {
				add(_string);
			}
		}
	}

	/**
	 * @param _string
	 */
	public void addIfNew(String _string) {
		if (!this.strings.contains(_string)) {
			add(_string);
		}
// modified m.s.
		/*
		boolean found = false;
		for(int i=0;i<strings.size();i++)
		{
			if(((String) strings.get(i)).equals(_string))
			{
				found=true;
			}
		}
		if(found==false)
		{
			add(_string);
		}
		 */
	}

	/**
     * added m.s.
	 * @param head
	 * @param _string
	 */
	public void addIfNew(String head, String _string) {
		if (count() == 0) {
			add(_string);
		} else {
			boolean found = false;
			for (int i = 0; i < this.strings.size(); i++) {
				if (this.strings.get(i).trim().startsWith(head)) {
					found = true;
					break;
				}
			}

			if (found == false) {
				add(_string);
			}
		}
	}

	/**
	 * @param _string
	 */
	public void addOrderedIfNew(String _string) {
		if (!this.strings.contains(_string)) {
			addOrdered(_string);
		}
	}

	/**
	 * @param _string
	 */
	public void addByLengthIfNew(String _string) {
		if (!this.strings.contains(_string)) {
			addByLength(_string);
		}
	}

	/**
	 * @param _stringList
	 */
	public void add(StringList _stringList) {
		for (int i = 0; i < _stringList.count(); i++) {
			this.strings.add(_stringList.get(i));
		}
	}

	/**
	 * @param _stringList
	 */
	public void addIfNew(StringList _stringList) {
		for (int i = 0; i < _stringList.count(); i++) {
			if (!this.strings.contains(_stringList.get(i))) {
				this.strings.add(_stringList.get(i));
			}
		}
	}

	/**
	 * @param _string
	 * @return boolean
	 */
	public boolean contains(String _string) {
		 return this.strings.contains(_string);
	}

	/**
	 * @param _head
	 * @return int
	 */
	public int getHeadPosition(String _head) {
		for (int i = 0; i < this.strings.size(); i++) {
			if (this.strings.get(i).trim().startsWith(_head)) {
				return i;
			}
		}
		return -1;
	}

/**
 * added 2011.03.01 m.s.
 * @param _string
 * @return  int
 */
	public int getCount(String _string) {
		int found = 0;
		for (int i = 0; i < this.strings.size(); i++) {
			if (this.strings.get(i).equals(_string)) {
				found++;
			}
		}
		return found;
	}

	/**
	 * @param _string
	 * @param matchCase
	 * @return boolean
	 */
	public boolean contains(String _string, boolean matchCase) {
		boolean found = false;
		for (int i = 0; i < this.strings.size(); i++) {
			if (matchCase == false) {
				if (this.strings.get(i).toLowerCase()
						.equals(_string.toLowerCase())) {
					found = true;
				}
			} else {
				if (this.strings.get(i).equals(_string)) {
					found = true;
				}
			}
		}
		return found;
	}

	/**
	 * @return StringList
	 */
	public StringList reverse() {
		final StringList sl = new StringList();

		for (int i = 0; i < this.strings.size(); i++) {
			sl.add(get(count() - i - 1));
		}

		return sl;
	}

	/**
	 * @param _index
	 * @param _s
	 */
	public void set(int _index, String _s) {
		if (_index < this.strings.size() && _index >= 0) {
			this.strings.remove(_index);
			this.strings.insertElementAt(_s, _index);
		}
	}

	/**
	 * @param _index
	 * @return String
	 */
	public String get(int _index) {
		if (_index < this.strings.size() && _index >= 0) {
			return this.strings.get(_index);
		}
		return "";

	}

	/**
	 * @param _index
	 */
	public void delete(int _index) {
		this.strings.removeElementAt(_index);
	}


    /**
     * added 2011.03.01 m.s.
     * @param _string
     * @return true if deleted
     */
    public boolean delete(String head) {
        int pos = getHeadPosition(head);
        if (pos >=0){
            this.strings.removeElementAt(pos);
            return true;
        }
        else
            return false;
       }

	/**
	 * @param _string
	 * @param _index
	 */
	public void insert(String _string, int _index) {
		this.strings.insertElementAt(_string, _index);
	}

	/**
	 * @param _text
	 */
	public void setText(String _text) {
		final String[] words = _text.split("\n");
		this.strings.clear();
		for (final String word : words) {
			this.strings.add(word);
		}
	}

	/**
	 * @return String
	 */
	public String getText() {
		return getSBuilder().toString();
	}

	/**
	 * @return String
	 */
	public StringBuilder getSBuilder() {
		StringBuilder text = new StringBuilder();
		for (int i = 0; i < this.strings.size(); i++) {
			if (i == 0) {
				text.append(this.strings.get(i));
			} else {
				text.append("\n" + this.strings.get(i));
			}
		}

		return text;
	}



	/**
	 * @return String
	 */
	public String getLongString() {
//		String code = "";
		StringBuffer text = new StringBuffer();
		for (int i = 0; i < this.strings.size(); i++) {
			if (i != 0)
				text.append(" ");
			final String t = this.strings.get(i).trim();
			// 2011.03.01 ms. modified to process comments inline
			if (t.contains("//") && !t.endsWith(";"))
				text.append(this.strings.get(i) + ";");
			else
				text.append(this.strings.get(i));
		}
		return text.toString();
	}

	/**
	 * @return int
	 */
	public int count() {
		return this.strings.size();
	}

	/**
	 * @param _input
	 */
	public void setCommaText(String _input) {
		String input = _input + "";

		// if not CSV, make it CSV
		if (input.length() > 0) {
			String first = Character.toString(input.charAt(0));
			if (!first.equals("\"")) {
				input = "\"" + input;
			}
			first = Character.toString(input.charAt(input.length() - 1));
			if (!first.equals("\"")) {
				input = input + "\"";
			}
		}

		this.strings.clear();

		String tmp = "";
		boolean open = false;

		for (int i = 0; i < input.length(); i++) {
			final String chr = Character.toString(input.charAt(i));
			if (chr.equals("\"")) {
				if (i + 1 < input.length()) {
					if (open == false) {
						open = true;
					} else {
						final String next = Character.toString(input
								.charAt(i + 1));
						if (next.equals("\"")) {
							tmp += "\"";
							i++;
						} else {
							if (!(this.strings.size() == 0 && tmp.trim()
									.equals(""))) {
								this.strings.add(tmp);
							}
							tmp = "";
							open = false;
						}
					}
				} else {
					if (!(this.strings.size() == 0 && tmp.trim().equals(""))) {
						this.strings.add(tmp);
					}
					tmp = "";
					open = false;
				}
			} else {
				if (open == true) {
					tmp += chr;
				}
			}
		}
		if (!tmp.trim().equals("")) {
			this.strings.add(tmp);
		}
	}

	/**
	 * @return String
	 */
	public String getCommaText() {
//		String res = new String();
		StringBuffer res = new StringBuffer();
//		  String s = buf.toString();

		for (int i = 0; i < this.strings.size(); i++) {
			if (i == 0) {
				res.append("\"" + BString.replace(get(i), "\"", "\"\"") + "\"");
			} else {
				res.append(",\"" + BString.replace(get(i), "\"", "\"\"") + "\"");
			}
		}

		return res.toString();
	}

	/**
	 * @param _filename
	 */
	public void loadFromFile(String _filename) {
		try {
			final StringBuffer buffer = new StringBuffer();
			final InputStreamReader isr = new InputStreamReader(
					new FileInputStream(new File(_filename)), "UTF8");
			final Reader in = new BufferedReader(isr);
			int ch;
			while ((ch = in.read()) > -1) {
				buffer.append((char) ch);
			}
			in.close();

			this.strings.clear();
			add(StringList.explode(buffer.toString(), "\n"));
		} catch (final IOException ex) {
			// nothing to do
		}

		/*        try
				{
					BTextfile inp = new BTextfile(_filename);
					inp.reset();
					strings.clear();
					while(!inp.eof())
					{
						String s = inp.readln();
						strings.add(s);
					}
					inp.close();
				}
				catch (Exception e)
				{
					System.err.println(e.getMessage());
				}
		 */
	}

	/**
	 * @param _filename
	 */
	public void saveToFile(String _filename) {
		try {
			final FileOutputStream fos = new FileOutputStream(_filename);
			final Writer out = new OutputStreamWriter(fos, "UTF8");
			out.write(getText());
			out.close();
			/*
			BTextfile inp = new BTextfile(_filename);
			inp.rewrite();
			inp.write(this.getText());
			inp.close();
			 */
		} catch (final IOException ex) {
			System.err.println(ex.getMessage());
		}
	}

	/**
	 * @param beginLine
	 * @param beginIndex
	 * @param endLine
	 * @param endIndex
	 * @return String
	 */
	public String copyFrom(int beginLine, int beginIndex, int endLine,
			int endIndex) {
//		String ret = "";
		StringBuffer ret = new StringBuffer();

		for (int i = beginLine; i <= endLine; i++) {
			final String line = get(i);
//debug  System.out.println(i+") "+line);
			if (i == beginLine) {
				if (line.length() > beginIndex && beginIndex >= 0)
					ret.append(line.substring(beginIndex));
			} else if (i == endLine) {
				ret.append("\n"
						+ line.substring(0, Math.min(endIndex, line.length())));
			} else {
				ret.append("\n" + line);
			}
		}/**/
//debug     System.out.println("Res = "+ret);
		return ret.toString();
	}

	@Override
	public String toString() {
		return getCommaText();
	}

}
