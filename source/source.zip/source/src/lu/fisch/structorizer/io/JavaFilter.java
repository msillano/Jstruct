/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.io;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    Inputfilter for pascal source files.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.27      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************///

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 *
 */
public class JavaFilter extends FileFilter {

	/**
	 * @param _filename
	 * @return boolean
	 */
	public static boolean isJava(String _filename)
	{
		return
		getExtension(_filename).equals("java");
	}

	/**
	 * Returns extension low-case (e.g. "java");
	 * @param s
	 * @return String or null
	 */
	public static String getExtension(String s)
	{
		String ext = null;
		final int i = s.lastIndexOf('.');

		if (i > 0 &&  i < s.length() - 1)
		{
			ext = s.substring(i+1).toLowerCase();
		}
		return ext;
	}

	/**
	 * @param f
	 * @return String
	 */
	public static String getExtension(File f)
	{
		return getExtension( f.getName());
	}

	@Override
	public String getDescription()
	{
		return "Java Source Files";
	}

	@Override
	public boolean accept(File f)
	{
		if (f.isDirectory())
		{
			return true;
		}

		final String extension = getExtension(f);
		if (extension != null)
		{
			return isJava(f.getName());
		}

		return false;
	}

}
