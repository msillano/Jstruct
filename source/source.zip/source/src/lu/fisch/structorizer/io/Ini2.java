// package and import
package lu.fisch.structorizer.io;

import java.io.*;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;

/**
 *JStruct
 *A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)
 *Copyright (C) 2009  Bob Fisch
 *This program is free software: you can redistribute it and/or modify
 *it under the terms of the GNU General Public License as published by
 *the Free Software Foundation, either version 3 of the License, or any
 *later version.
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *You should have received a copy of the GNU General Public License
 *along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ****************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class manages entries in the INI-file
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date         Description
 *      ------         ----         -----------
 *      Bob Fisch       2008.05.02      First Issue
 *      Marco Sillano   2011.03.01      updated for portability
 *      Marco Sillano   2015.05.10      bug correction
 ******************************************************************************************************
 *
 *      Comment:
 *
 *****************************************************************************************************
 *
 */
public class Ini {

   /* class global variables */
   // 2011.03.01 ms. added for portability:
   //  useAlternate = false: it uses regular: same dir as jar/class(only) - portable
   //  useAlternate = true: it uses alternate:  (in app_data), and regular as default
   // jar name
   public static final String jarname = "jstruct.jar";
   private final String ininame = "jstruct.ini";
   private boolean useAlternate = false;
   private String alternateFileName = "";
   private String regularFileName = "";
   private File file = null;
   private final Properties p = new Properties();
   private static Ini ini = null;
   private boolean regularExists = false;
   private boolean alternateExists = false;
   private boolean regularWritable = false;
   // 2011.03.01 ms. added for performances:
   private static volatile boolean INIread = false;

/**
 * @return Ini
 */
   public static Ini getInstance() {
      if(ini == null) {
         ini = new Ini();  // debug   System.out.println("INI-newInstance");
      }
      return ini;  // debug   System.out.println("INI-oldInstance");
   }

   private void load(String IniFileName) {
      try {
         FileInputStream inp = new FileInputStream(IniFileName);
         this.p.load(inp);
         inp.close();
         INIread = true;
      }
      catch (final Error e) {
         System.err.println(e.getMessage());
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
      }
   }

   public void load() {
      if(!INIread) {
         if(this.useAlternate) {
            load(this.alternateFileName);
         }
         else {
            load(this.regularFileName);
         }
      }
   }

   private void save(String IniFileName) throws FileNotFoundException, IOException {
      FileOutputStream out = new FileOutputStream(IniFileName);
      this.p.store(out, "last updated " + new java.util.Date());
      out.close();
   }

/**
 * @throws FileNotFoundException
 * @throws IOException
 */
   public void save() throws FileNotFoundException, IOException {
      if(this.useAlternate) {  //  saves backup
         save(this.alternateFileName);
      }
      else {
         save(this.regularFileName);
      }
   }

/**
 * @param _name
 * @param _default
 * @return String
 */
   public String getProperty(String _name, String _default) {
      if(this.p.getProperty(_name) == null) {
         this.p.setProperty(_name, _default);
         return _default;
      }
      return this.p.getProperty(_name);
   }

/**
 * @param _name
 * @param _value
 */
   public void setProperty(String _name, String _value) {
      this.p.setProperty(_name, _value);
   }

/**
 * @return keys
 */
   public Set <Object> keySet() {
      return this.p.keySet();
   }

/**
 * constructor
 */
   public Ini() {
      try {
         final URL mySource = Ini.class.getProtectionDomain().getCodeSource().getLocation();
         String dirname = mySource.getPath();
         if(dirname.contains(Ini.jarname)) {  // debug      System.out.println("urlDir= " + dirname);  using jar
            dirname = dirname.substring(0, dirname.indexOf(Ini.jarname));
         }
         this.regularFileName = dirname + this.ininame;
         final File sourceFile = new File(URLDecoder.decode(this.regularFileName, "UTF-8"));  // debug   System.out.println("regularFileName = " + this.regularFileName);
         this.regularFileName = sourceFile.getAbsolutePath();
      }
      catch (final Error e) {
         System.err.println(e.getMessage());  // debug   System.out.println("regularFileName = " + this.regularFileName);
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
      }
      try {
         this.file = new File(this.regularFileName);
         this.regularExists = this.file.exists();
      }
      catch (final Error e) {
         System.err.println(e.getMessage());
         this.regularExists = false;
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
         this.regularExists = false;
      }
      try {
         FileOutputStream out = new FileOutputStream(this.regularFileName);
         regularWritable = true;
      }
      catch (final Exception e) {
         regularWritable = false;
      }
      try {
         final String dirname = System.getProperty("user.home") + System.getProperty("file.separator") + "AppData" + System.getProperty("file.separator") + "Local" + System.getProperty("file.separator") + "JStruct";
         this.alternateFileName = dirname + System.getProperty("file.separator") + this.ininame;
      }
      catch (final Error e) {
         System.err.println(e.getMessage());
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
      }
      try {
         this.file = new File(this.alternateFileName);
         this.alternateExists = this.file.exists();
      }
      catch (final Error e) {
         System.err.println(e.getMessage());
         this.alternateExists = false;
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
         this.alternateExists = false;
      }
      this.useAlternate = !(regularExists && regularWritable);  // debug   System.out.println("INI regularFileName   = " + this.regularFileName +                       " : exists ==> "  + this.regularExists +                       " writable ==> " + this.regularWritable); debug   System.out.println("INI alternateFileName = " +     this.alternateFileName +                      " : exists ==> " + this.alternateExists);  2011.03.01 ms. added
      if(this.useAlternate && !this.alternateExists) {  //  create the alternate one, first dir
         try {
            this.file = new File(this.alternateFileName);
            File dir = this.file.getParentFile();
            if(!dir.exists()) {
               if(!dir.mkdir()) {
                  System.err.println("Error making dir" + dir);
               }
            }
         }
         catch (final Error e) {
            System.err.println(e.getMessage());
         }
         catch (final Exception e) {
            System.err.println(e.getMessage());
         }
         try {
            if(regularExists) {
               load(this.regularFileName);
            }
            save(this.alternateFileName);
         }
         catch (final Exception e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
         }
      }
   }

}
