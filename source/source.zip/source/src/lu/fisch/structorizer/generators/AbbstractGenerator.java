//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\generators\AbbstractGenerator.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//
// package and import
package lu.fisch.structorizer.generators;

import java.awt.Frame;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Call;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;
import lu.fisch.utils.BString;
import lu.fisch.utils.StringList;

/**
 * Base class for all generators.
 *
 * A generator gets the NSD Element tree and produces a source text file
 * in some language.<br />
 *
 * <br />Source build by JStruct [charset UTF-8].<br />
 *
 * @version 1.02.00  build 70  (2015.03.27-17:10:21) update to java 1.8
 * @version <br />1.01.01  build 21  (2012.03.30-17:59:18) JStruct-aware version
 * @version <br />1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public abstract class AbbstractGenerator
extends javax.swing.filechooser.FileFilter {

   /* class global variables */
   protected StringList code = new StringList();
   protected String jOutCode;

/**
 * default constructor
 */
   public AbbstractGenerator() {
      //      default none
   }

   private static String getExtension(File f) {
      return getExtension(f.getName());
   }

   private static String getExtension(String s) {
      String ext = null;
      final int i = s.lastIndexOf('.');
      if(i > 0 && i < s.length() - 1) {
         ext = s.substring(i + 1).toLowerCase();
      }
      return ext;
   }

   @Override()
   public boolean accept(File f) {
      if(f.isDirectory()) {
         return true;
      }
      final String extension = getExtension(f);
      if(extension != null) {
         return isOK(f.getName());
      }
      return false;
   }

/**
 * Generator entry point.
 *
 * Saves the source build from _jprogram,
 * asks user for the file name.
 *
 * @param _jprogram - the block tree
 * @param _currentDirectory - default directory for export file
 * @param frame - the parent component of the dialog, can be null; see showDialog for details
 * @param jcode - out charset coding
 */
   public void exportCode(CompilationUnit _jprogram, File _currentDirectory, Frame frame, String jcode) {
      boolean saveIt = true;
      final JFileChooser dlgSave = new JFileChooser();
      jOutCode = jcode;
      dlgSave.setDialogTitle(getDialogTitle());
// set directory
      if(_jprogram.getFile() != null) {
         dlgSave.setCurrentDirectory(_jprogram.getFile());
      }
      else {
         dlgSave.setCurrentDirectory(_currentDirectory);
      }
      dlgSave.setSelectedFile(new File(_jprogram.getDefaultFileName()));
      dlgSave.addChoosableFileFilter(this);
      final int result = dlgSave.showSaveDialog(frame);
      String filename = "";
      if(result == JFileChooser.APPROVE_OPTION) {
         filename = dlgSave.getSelectedFile().getAbsoluteFile().toString();
         if(!isOK(filename)) {
            filename += "." + getFileExtensions()[0];
         }
      }
      else {
         saveIt = false;
      }
      if(saveIt == true) {
         final File file = new File(filename);
         boolean writeDown = true;
         if(file.exists()) {
            final int response = JOptionPane.showConfirmDialog(null, "Overwrite existing file?", "Confirm Overwrite", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(response == JOptionPane.NO_OPTION) {
               writeDown = false;
            }
         }
         if(writeDown == true) {
            try {
               final String code1 = BString.replace(generateCode(_jprogram, ""), "\t", getIndent());
               final Writer out = new OutputStreamWriter(new FileOutputStream(filename), jcode);
               out.write(code1);
               out.close();
            }
            catch (final Exception e) {
// debug
               e.printStackTrace();
               JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage(), "Save error", JOptionPane.ERROR_MESSAGE);
            }
         }
      }
   }

   @Override()
   public String getDescription() {
      return getFileDescription();
   }

/**
 * getter for indent string.
 * The Generator uses TAB, then replaces any Tab with this.
 * compatible spaces/tab of any size
 * @return String
 */
   public String getIndent() {
      return "   ";
   }

/**
 * dispatch an AbstractElement
 */
   protected void doGenerate(AbstractElement _ele, String _indent) {
      try {
         if(_ele.getClass().getSimpleName().equals("Instruction")) {
            generateCode((Instruction) _ele, _indent);
         }
         else {
            if(_ele.getClass().getSimpleName().equals("Alternative")) {
               generateCode((Alternative) _ele, _indent);
            }
            else {
               if(_ele.getClass().getSimpleName().equals("Switch")) {
                  generateCode((Switch) _ele, _indent);
               }
               else {
                  if(_ele.getClass().getSimpleName().equals("For")) {
                     generateCode((For) _ele, _indent);
                  }
                  else {
                     if(_ele.getClass().getSimpleName().equals("While")) {
                        generateCode((While) _ele, _indent);
                     }
                     else {
                        if(_ele.getClass().getSimpleName().equals("Repeat")) {
                           generateCode((Repeat) _ele, _indent);
                        }
                        else {
                           if(_ele.getClass().getSimpleName().equals("Call")) {
                              generateCode((Call) _ele, _indent);
                           }
                           else {
                              if(_ele.getClass().getSimpleName().equals("Try")) {
                                 generateCode((Try) _ele, _indent);
                              }
                              else {
                                 if(_ele.getClass().getSimpleName().equals("JClass")) {
                                    generateCode((JClass) _ele, _indent);
                                 }
                                 else {
                                    if(_ele.getClass().getSimpleName().equals("JMethod")) {
                                       generateCode((JMethod) _ele, _indent);
                                    }
                                    else {
                                       if(_ele.getClass().getSimpleName().equals("Root")) {
                                          generateCode((JMethod) _ele, _indent);
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      catch (Exception e) {
         System.err.println(e.getMessage());
         e.printStackTrace();
      }
   }

/**
 * The method generateCode for Alternative
 */
   protected abstract void generateCode(Alternative _alt, String _indent);

/**
 * The method generateCode for Call
 */
   protected abstract void generateCode(Call _call, String _indent);

/**
 * The method generateCode for CompilationUnit
 */
   protected abstract String generateCode(CompilationUnit _jprogram, String _indent);

/**
 * The method generateCode for For
 */
   protected abstract void generateCode(For _for, String _indent);

/**
 * The method generateCode for Instruction
 */
   protected abstract void generateCode(Instruction _inst, String _indent);

/**
 * The method generateCode for JClass
 */
   protected abstract void generateCode(JClass _jclass, String _indent);

/**
 * The method generateCode for JMethod
 */
   protected abstract void generateCode(JMethod _root, String _indent);

/**
 * The method generateCode for Repeat
 */
   protected abstract void generateCode(Repeat _repeat, String _indent);

/**
 * The method generateCode for Subqueue
 */
   protected abstract void generateCode(Subqueue _subqueue, String _indent);

/**
 * The method generateCode for Switch
 */
   protected abstract void generateCode(Switch _case, String _indent);

/**
 * The method generateCode for Try
 */
   protected abstract void generateCode(Try _try, String _indent);

/**
 * The method generateCode for While
 */
   protected abstract void generateCode(While _while, String _indent);

/**
 * The method getDialogTitle
 */
   protected abstract String getDialogTitle();

/**
 * The method getFileDescription
 */
   protected abstract String getFileDescription();

/**
 * The method getFileExtensions
 */
   protected abstract String[] getFileExtensions();

/**
 * FileFilter tests Extension
 */
   protected boolean isOK(String _filename) {
      boolean res = false;
      if(getExtension(_filename) != null) {
         for(int i = 0; i < getFileExtensions().length; i++) {
            res = res || getExtension(_filename).equals(getFileExtensions()[i]);
         }
      }
      return res;
   }

}
