//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\generators\JavaGenerator.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
package lu.fisch.structorizer.generators;
import lu.fisch.utils.*;
import lu.fisch.structorizer.elements.*;
/**
 * Generator for internal XML format (.nsd files)
 * <br> NDS generator features:<ul>
 * <li> Not compatible with previous versions.
 * <li> Stores used font and, for every block, the color attribute.
 * </ul>
 *
 * <BR>Source build by JStruct.<BR>
 *
 * @version 1.01.01  build 22  (2012.03.14-20:59:39) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */

public class NSDGenerator extends AbbstractGenerator {

	/************ Fields ***********************/
	@Override
	protected String getDialogTitle()
	{
		return "JStruct Files";
	}

	@Override
	protected String getFileDescription()
	{
		return "NDS Files";
	}


	@Override
	protected String[] getFileExtensions()
	{
		final String[] exts = {"xml","nsd"};
		return exts;
	}

	/************ Code Generation **************/
	@Override
	protected void generateCode(Instruction _inst, String _indent)
	{
		this.code.add(_indent+"<instruction code=\""+BString.encodeToHtml(_inst.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_inst.getComment().getCommaText())+"\" color=\""+
				_inst.getHexColor()+"\" ></instruction>");
	}

	@Override
	protected void generateCode(Alternative _alt, String _indent)
	{
		this.code.add(_indent+"<alternative code=\""+BString.encodeToHtml(_alt.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_alt.getComment().getCommaText())+"\" color=\""+
				_alt.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qTrue>");
		generateCode(_alt.getTrueSubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qTrue>");
		this.code.add(_indent+_indent.substring(0,1)+"<qFalse>");
		generateCode(_alt.getFalseSubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qFalse>");
		this.code.add(_indent+"</alternative>");
	}

	@Override
	protected void generateCode(Switch _case, String _indent)
	{
		this.code.add(_indent+"<case code=\""+BString.encodeToHtml(_case.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_case.getComment().getCommaText())+"\" color=\""+
				_case.getHexColor()+"\" >");
		for(int i=0;i<_case.getSwitchSubqueues().size();i++)
		{
			this.code.add(_indent+_indent.substring(0,1)+"<qCase>");
			generateCode(_case.getSwitchSubqueues().get(i),_indent+_indent.substring(0,1)+_indent.substring(0,1));
			this.code.add(_indent+_indent.substring(0,1)+"</qCase>");
		}
		this.code.add(_indent+"</case>");
	}

	@Override
	protected void generateCode(For _for, String _indent)
	{
		this.code.add(_indent+"<for code=\""+BString.encodeToHtml(_for.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_for.getComment().getCommaText())+"\" color=\""+
				_for.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qFor>");
		generateCode(_for.getForSubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qFor>");
		this.code.add(_indent+"</for>");
	}

	@Override
	protected void generateCode(While _while, String _indent)
	{
		this.code.add(_indent+"<while code=\""+BString.encodeToHtml(_while.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_while.getComment().getCommaText())+"\" color=\""+
				_while.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qWhile>");
		generateCode(_while.getWhileSubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qWhile>");
		this.code.add(_indent+"</while>");
	}

	@Override
	protected void generateCode(Repeat _repeat, String _indent)
	{
		this.code.add(_indent+"<repeat code=\""+BString.encodeToHtml(_repeat.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_repeat.getComment().getCommaText())+"\" color=\""+
				_repeat.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qRepeat>");
		generateCode(_repeat.getDoSubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qRepeat>");
		this.code.add(_indent+"</repeat>");
	}

	@Override
	protected void generateCode(Call _call, String _indent)
	{
		this.code.add(_indent+"<call code=\""+BString.encodeToHtml(_call.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_call.getComment().getCommaText())+"\" color=\""+
				_call.getHexColor()+"\"></call>");
	}

	protected void generateXCode(Catch _catch, String _indent){
		this.code.add(_indent+"<catch code=\""+BString.encodeToHtml(_catch.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_catch.getComment().getCommaText())+"\" color=\""+
				_catch.getHexColor()+"\" >");
		for(int i=0;i<_catch.getCatchSubqueue().size();i++)
		{
			this.code.add(_indent+_indent.substring(0,1)+"<qCatch>");
			generateCode(_catch.getCatchSubqueue().get(i),_indent+_indent.substring(0,1)+_indent.substring(0,1));
			this.code.add(_indent+_indent.substring(0,1)+"</qCatch>");
		}
		this.code.add(_indent+"</catch>");

	}

	protected void generateXCode(Finally _finally, String _indent){

		this.code.add(_indent+"<finally code=\""+BString.encodeToHtml(_finally.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_finally.getComment().getCommaText())+"\" color=\""+
				_finally.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qFinally>");
		generateCode(_finally.getFinallySubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qFinally>");
		this.code.add(_indent+"</finally>");
	}

	@Override
	protected void generateCode(Try _try, String _indent)
	{
        this.code.add(_indent+"<try code=\""+BString.encodeToHtml(_try.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_try.getComment().getCommaText())+"\" color=\""+
				_try.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<qTry>");
		generateCode(_try.getTrySubqueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</qTry>");
// child
		generateXCode(_try.getCatch(), _indent+_indent.substring(0,1));
		generateXCode(_try.getFinally(), _indent+_indent.substring(0,1));
//
		this.code.add(_indent+"</try>");
	}

	@Override
	protected void generateCode(Subqueue _subqueue, String _indent)
	{
		// code.add(_indent+"");
		for(int i=0;i<_subqueue.getChildren().size();i++)
		{
			doGenerate(_subqueue.getChildren().get(i),_indent);
		}
		// code.add(_indent+"");
	}

	@Override
	public void generateCode(JMethod _root, String _indent)
	{
		String ni = "open";
		if(_root.isClosed()) {ni="close";}
//		code.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
//      code.add("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
		this.code.add(_indent+"<method code=\""+BString.encodeToHtml(_root.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_root.getComment().getCommaText())+"\" status=\""+ni+"\" color=\""+
				_root.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<body>");
		generateCode(_root.getChildQueue(),_indent+_indent.substring(0,1)+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</body>");
		this.code.add(_indent+"</method>");


	}

	@Override
	public void generateCode(JClass _jclass, String _indent) {
		String ni = "open";
		if(_jclass.isClosed()) {ni="close";}

		this.code.add(_indent+"<jclass code=\""+BString.encodeToHtml(_jclass.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_jclass.getComment().getCommaText())+"\" status=\""+ni+"\" color=\""+
				_jclass.getHexColor()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<methods>");
		generateCode(_jclass.getChildQueue(),_indent+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</methods>");
		this.code.add(_indent+"</jclass>");
	}

	/**
	 * @param comment
	 * @param _jprogram
	 */
	public void updateInfos( StringList comment, CompilationUnit _jprogram ){
		comment.addReplace("@source:",
				"@source: " + _jprogram.getFilename());
		if (comment.getHeadPosition("@JStruct:")<0){
		        comment.add("@JStruct: " + AbstractElement.E_VERSION );
		}
		AbstractElement.updateOptions(comment);
	}


	@Override
	public String generateCode(CompilationUnit _jprogram, String _indent) {
		// head comment
		updateInfos(_jprogram.getComment(), _jprogram );
		this.code.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		this.code.add(_indent+"<jprogram code=\""+BString.encodeToHtml(_jprogram.getCode().getCommaText())+"\" comment=\""+
				BString.encodeToHtml(_jprogram.getComment().getCommaText())+"\" font=\""+
				AbstractElement.getFont().getName()+"\" fontSize=\""+AbstractElement.getFont().getSize()+"\" >");
		this.code.add(_indent+_indent.substring(0,1)+"<children>");
		for (int i = 0; i <_jprogram.getSize(); i++ )
			doGenerate(_jprogram.getElement(i),_indent+_indent.substring(0,1));
		this.code.add(_indent+_indent.substring(0,1)+"</children>");
		this.code.add(_indent+"</jprogram>");
		return this.code.getText();
	}
}
