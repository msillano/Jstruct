//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2017 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\generators\JavaGenerator.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
// package and import
package lu.fisch.structorizer.generators;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Call;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;
import lu.fisch.utils.BString;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Java generator for JStruct.
 * <br> Java generator features:<ul>
 * <li> Processes  package and import expressions.
 * <li> Processes top level and nested Classes.
 * <li> Compatible with generic and Anonymous Classes.
 * <li> Processes annotations, enum, enhanced for.
 * <li> Processes instance initializers and static initializers.
 * <li> Compatible with all java operations, like  +=, *=, ?:,,... in code.
 * <li> Optional "()" for conditions in IF, FOR, WHILE, DO blocks.
 * <li> Optional &lt;prekeyword>, &lt;postkeyword> user defined in IF, SWICH, FOR, WHILE, DO Blocks
 * <li> Builds stub for missed Methods.
 * <li> Special &lt;Input> keyword (user defined) process:<ol>
 *       <li> generates System.in.read code
 *       <li> generates dialog pop-up code</ol>
 * <li> Special &lt;Ouput> keyword (user defined) process:<ol>
 *       <li> generates System.out.print code
 *       <li> generates dialog pop-up code</ol>
 * <li> Formatting style:<ol>
 *       <li> Code indented using 3 spaces.
 *       <li> Full parenthesized blocks for IF, ELSE, FOR, WHILE, DO
 *       <li> Complete comment management: header, Javadoc, inline </ol>
 * </ol>
 * <h3>Documentation processing options: </h3>
 *  <ul>
 *      <li> {@link AbstractElement#PROGRAMDOCONTOP PROGRAMDOCONTOP} if true places inline comments (non javadoc, using '//') before the code,
 *     else comments are placed on the right.
 *      <li> {@link AbstractElement#ADDJAVADOCEXTRA ADDJAVADOCEXTRA} controls jovadoc processing:<ol>
 *           <li> Adds
 *           <li> {@link AbstractElement#ADDJAVADOCPUBLIC ADDJAVADOCPUBLIC} if true adds missed Javadoc comments only to public Methods else
 *        adds missed javadoc comments to all Methods (with the exclusion for @override).
 *           <li> {@link AbstractElement#SETSOURCEVERSION SETSOURCEVERSION} if true
 *        sets/updates the build count in top comment.
 *           <li> {@link AbstractElement#ADDJAVADOCIMAGE ADDJAVADOCIMAGE} if true
 *        adds a link for an exported NSD image in javadoc.
 *
 *       <li> Adds missed Javadoc comments to all public members (optional, see {@link AbstractElement#ADDJAVADOCPUBLIC ADDJAVADOCPUBLIC})
 *       <li> Not Javadoc comments uses '//' and can be placed before or at right of code (optional, see {@link AbstractElement#PROGRAMDOCONTOP PROGRAMDOCONTOP}) </ol>
 * </ul>
 *
 * <br />Source build by JStruct [charset UTF-8].<br />
 *
 * @version 1.02.00  build 6  (2015.03.27-20:11:32) update to java 1.8
 * @version <dd>1.01.01  build 22  (2012.03.14-20:59:39) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class JavaGenerator
extends AbbstractGenerator {

   /* class global variables */
   protected boolean importSwingPane = false;
   protected boolean importScanner = false;
   protected StringList newMethod = new StringList();
   protected String commentKey = "build by JStruct";
   private static boolean header = false;

/**
 * @param comment
 * @param _jprogram
 * @see JavaParser.updateInfos(StringList comment, CompilationUnitTree tree)
 */
   public void updateInfos(StringList comment, CompilationUnit _jprogram) {
             AbstractElement.updateOptions(comment);
//10/04/2015 added: no exra infos if not required
            if(!AbstractElement.ADDJAVADOCEXTRA &&
            !AbstractElement.ADDJAVADOCPUBLIC &&
            !AbstractElement.ADDJAVADOCIMAGE &&
            !AbstractElement.SETSOURCEVERSION) return;
            comment.addReplace("@source:", "@source: "
                    +  _jprogram.getFilename());
             if (!comment.getLongString().contains("@JStruct:"))
                comment.addReplace("@JStruct:", "@JStruct: "
                        + AbstractElement.E_VERSION );
   }

   @Override()
   public String generateCode(CompilationUnit _jprogram, String _indent) {
      JavaGenerator.header = false;
// head comment
      updateInfos(_jprogram.getComment(), _jprogram);
      for(int i = 0; i < _jprogram.getComment().count(); i++) {
         this.code.add("//" + _jprogram.getComment().get(i));
      }
      final int endComment = this.code.count();
// code
      Java3Code lines = new Java3Code(_jprogram.getCode());
// debug        System.out.println("*********** \n"+lines.getCode()+"\n**************");
      lines.cleanupMultiline(_indent);
      for(String line : lines) {
         line = formatJavaSource(line, _indent);
         line = Java3Code.lineAddSColon(line);
         addCode(line);
      }
// debug            System.out.println(">"+line+"<");
      int endImport = this.code.count();
      for(int i = 0; i < _jprogram.getSize(); i++) {
         doGenerate(_jprogram.getElement(i), _indent);
         this.code.add("");
      }
      if(this.importSwingPane && !_jprogram.getCode().getLongString().contains("javax.swing.JOptionPane")) {
         this.code.insert("import javax.swing.JOptionPane;", endImport++);
      }
      if(this.importScanner && !_jprogram.getCode().getLongString().contains("java.util.Scanner")) {
         this.code.insert("import java.util.Scanner;", endImport++);
      }
// added 22/03/2015
      if(endComment != endImport) {
         this.code.insert("", endImport);
      }
      return this.code.getText();
   }

   @Override()
   public void generateCode(JClass _jclass, String _indent) {
// debug    System.out.println("in Class generate")      ;
      generateHeaderJavadoc(_jclass);
      int startVars = 0;
      String classname = "";
      do {
         classname += _jclass.getCode().get(startVars).trim() + (startVars == _jclass.getCode().count() - 1 ? "" : "\n" + _indent);
         startVars++;
      }
      while(!classname.contains(";") && startVars < _jclass.getCode().count());
//  cleanup
//26/03/2015: kill extra spaces
      while(classname.contains("  ")) {
         classname = classname.replace("  ", " ");
      }
      classname = Java3Code.lineTrimSColon(classname);
      if(classname.contains("enum ")) {
         this.code.add(_indent + classname + " {");
      }
      else {
// added 13/03/2015
         if(classname.contains("interface ")) {
            this.code.add(_indent + classname + " {");
         }
         else {
            if(classname.contains("class ")) {
               this.code.add(_indent + classname + " {");
            }
            else {
               this.code.add(_indent + "public class " + classname + " {");
            }
         }
      }
      this.code.add("");
      if(startVars < _jclass.getCode().count()) {
         while(startVars < _jclass.getCode().count()) {
//              this.code.add(_indent + "\t"
//                      + _jclass.getCode().get(startVars).trim());
// 25/03/2015: to prettyprint vars: but not processed by spaceTokenize...
            addCode(_indent + "\t" + _jclass.getCode().get(startVars).trim());
            startVars++;
         }
         this.code.add("");
      }
      for(int i = 0; i < _jclass.getSize(); i++) {
         doGenerate(_jclass.getElement(i), _indent + "\t");
         this.code.add("");
      }
      for(int i = 0; i < this.newMethod.count(); i++) {
         boolean found = false;
         for(int k = 0; k < _jclass.getChildQueue().getSize(); k++) {
            found |= _jclass.getElement(k) instanceof RootElement && this.newMethod.get(i).equals(((RootElement) _jclass.getElement(k)).getJName());
         }
         if(!found) {
            this.code.add(_indent + "\t" + "public static void " + this.newMethod.get(i) + "( /*[<type> <param>[, <type> <param>]*] */) {");
            this.code.add(_indent + "\t" + "\t" + "// TODO Auto-generated method stub");
            this.code.add(_indent + "\t" + "}");
            this.code.add("");
         }
      }
      this.code.add(_indent + "}");
   }

   @Override()
   public void generateCode(JMethod _root, String _indent) {
      generateHeaderJavadoc(_root);
// debug System.out.println(" root in: " + _root.getDeclaration().toString());
//  processes method declaration
      Java3Code decl = new Java3Code(_root.getDeclaration());
      String declare = decl.spaceTokenize(false).toString();
      if(declare == null) {
         declare = "ERROR()";
      }
      if(_root.getJName() == null) {
         System.err.println("JName() == null");
      }
      if(_root.getJName().equals("static")) {
         declare = "static";
      }
      else {
// workaround for incomplete main() declarations
         if((_root.getJName().equals("main")) && (!declare.contains("public"))) {
            declare = "public static void main(String[] args)";
         }
         else {
            declare = Java3Code.lineCosmetic(declare).trim();
            if(declare.charAt(0) == '@') {
               declare = declare.replace("@Override() ", "@Override() ");
//                   declare = declare.replace("@FunctionalInterface", "@FunctionalInterface()");
//26/03/2015: kill extra spaces
               while(declare.contains("  ")) {
                  declare = declare.replace("  ", " ");
               }
               declare = declare.replaceFirst("\\) ", ")\n" + _indent);
            }
            if(!declare.contains(")")) {
               declare += "()";
            }
         }
      }
// added 13/03/2015
// debug   System.out.println(" root: " + _root.getParent().getRoot().getCode().toString());
      if(!(_root.getParent().getRoot().getCode().toString().contains("interface") && _root.getChildQueue().getSize() == 0) && !declare.contains("abstract ")) {
         this.code.add(_indent + declare.trim() + " {");
         generateCode(_root.getChildQueue(), _indent + "\t");
         this.code.add(_indent + "}");
      }
      else {
         this.code.add(_indent + declare.trim() + ";");
      }
   }

/**
 *debug System.out.println("root out: >" + declare.replace("\t","T").replace(" ","-").replace("\n","N").replace("\r","R")+"<");
 * pretty print for java code lines
 */
   private void addCode(String code1) {
//debug System.out.println("addCode: >" + code1.replace("\t","T").replace(" ","-").replace("\n","N").replace("\r","R")+"<");
      String pretty = code1;
      if(code1.trim().startsWith("@")) {
         int pos = code1.indexOf("@");
         String indent = "";
         for(int i = 0; i < pos; i++) {
            indent += "\t";
         }
         pretty = code1.replaceFirst("\\) ", ")\n" + indent);
      }
      String[] lines = pretty.split("\n");
      for(int i = 0; i < lines.length; i++) {
         pretty = Java3Code.lineCosmetic(lines[i]);
         if(pretty != null) {
 //           pretty = pretty.replace("@Override() ", "@Override() ");
            this.code.add(pretty);
         }
      }
   }

/**
 * general purpose source line formatter, returns code using one space separator
 * final ";" are cut (exception for ' };' - anonymous classes ) and processes i/o instructions
 * output: can be multiline, using "\n" as separator
 * 24/03/2014: addeed _indent param for correct multiline management
 */
   private String formatJavaSource(String _input, String _indent) {
// debug  System.out.println("In formatJavaSource for: >"+_input.replace("\t","T")+"<");
// is w indent? save it
      String indent = "";
      int i = 0;
      if(!_input.equals("")) {
         while(_input.charAt(i++) == '\t') {
            indent += "\t";
         }
      }
      Java3Code line = new Java3Code(_input).spaceTokenize(false);
      String out = line.toString();
      if(out.trim() == "") {
         return "";
      }
// added 16/3/2015
      if(!out.endsWith("} ; ") && out.endsWith("; ")) {
         out = out.substring(0, out.length() - 3) + " ";
      }
      if(!out.endsWith("} ;") && out.endsWith(";")) {
         out = out.substring(0, out.length() - 2);
      }
// special i/o
      if(!Java3Code.input.equals("") && out.contains(" " + Java3Code.input.trim() + " ")) {
         String multi = processInput(out);
// added
         multi = multi.replace("\n", "\n" + _indent);
        return multi;
      }
       if(!Java3Code.output.equals("") && out.contains(" " + Java3Code.output.trim() + " ")) {
         String multi = processOutput(out);
// added
         multi = multi.replace("\n", "\n" + _indent);

         return multi;
      }
      out = indent + out;
// debug  System.out.println("Out formatJavaSource for: >"+out.replace("\t","T")+"<");
      return out;
   }

/**
 *  generates header (only for RootElements)
 *  ADDJAVADOCEXTRA + ADDJAVADOCPUBLIC : only for public
 *  ADDJAVADOCEXTRA  : for all
 *  else none
 */
   private void generateHeaderJavadoc(RootElement _ele) {
// debug
//System.out.println("In generateHeaderJavadoc for "+_ele.getJName());
//String options = "@JStructOptions: ";
//options += AbstractElement.ADDJAVADOCEXTRA ? "ADDJAVADOCEXTRA, " : "";
//options += AbstractElement.ADDJAVADOCIMAGE ? "ADDJAVADOCIMAGE, " : "";
//options += AbstractElement.ADDJAVADOCPUBLIC ? "ADDJAVADOCPUBLIC, " : "";
//options += AbstractElement.PROGRAMDOCONTOP ? "PROGRAMDOCONTOP, " : "";
//options += AbstractElement.SETSOURCEVERSION ? "SETSOURCEVERSION, " : "";
//options +=  " header is: "+header ;
//System.out.println(options);
      if(_ele instanceof JMethod && _ele.getDeclaration().contains("@Override")) {
         if(_ele.isCommented()) {
            getComment(_ele, true);
         }
// debug   System.out.println("Out generateHeaderJavadoc");
         return;
      }
//   no ( ADDJAVADOCEXTRA or (ADDJAVADOCPUBLIC and public))
// -> not changes   to Classes/Methods
      if(!(AbstractElement.ADDJAVADOCEXTRA || (_ele.getDeclaration().contains("public") && AbstractElement.ADDJAVADOCPUBLIC))) {
         if(_ele.isCommented()) {
            this.code.add("/**" );
            this.code.add(getJavadocComment(_ele));
            this.code.add(" */");
         }
// debug System.out.println("Out generateHeaderJavadoc : copy");
         return;
      }
// process
      final String className = _ele.getParent().getRoot().getJName();
      this.code.add("/**" );
      if(_ele.isCommented()) {
         this.code.add(getJavadocComment(_ele));
      }
      else {
         if(_ele instanceof JMethod && _ele.getJName().equals(className)) {
            this.code.add(" * The constructor " + _ele.getRootName());
         }
         else {
            if(_ele.getRootName().equals("static")) {
               this.code.add(" * This static block...");
            }
            else {
               if(_ele.getDeclaration().contains("enum ")) {
                  this.code.add(" * This enum...");
               }
// added 2017/01/24
           else {
               if(_ele.getDeclaration().contains("interface ")) {
                  this.code.add(" * The interface..." + _ele.getRootName());
               }
            else {
               if(_ele.getDeclaration().contains("class ")) {
                  this.code.add(" * The class..." + _ele.getRootName());
               }
// ends added
               else {
                  this.code.add(" * The method... " + _ele.getRootName());
               }
            }
         }
            }
         }
      }
      if(_ele instanceof JMethod) {
         final StringList pars = ((JMethod) _ele).getParametersNames();
         final StringList types = ((JMethod) _ele).getParametersTypes();
         for(int i = 0; i < pars.count(); i++) {
            if(!_ele.getComment().getLongString().contains(" " + pars.get(i))) {
               this.code.add(" * @param " + pars.get(i) + " " + types.get(i));
            }
         }
         if(!_ele.getDeclaration().contains("void") && !_ele.getDeclaration().contains("main") && !_ele.getRootName().equals(className)) {
            if(!_ele.getJName().equals("static")) {
               if(!_ele.getComment().getLongString().contains("@return")) {
                  this.code.add(" * @return " + ((JMethod) _ele).getReturnType());
               }
            }
         }
      }
       if(!AbstractElement.ADDJAVADOCEXTRA &&
            !AbstractElement.ADDJAVADOCPUBLIC &&
            !AbstractElement.ADDJAVADOCIMAGE &&
            !AbstractElement.SETSOURCEVERSION) return;

      if(!JavaGenerator.header) {
// debug System.out.println("In FirstHeader for "+_ele.getJName());
         JavaGenerator.header = true;
         int pos = - 1;
         if(!_ele.getComment().getLongString().contains(this.commentKey)) {
            for(int i = 0; i < this.code.count(); i++) {
               if(this.code.get(i).contains("@version")) {
                  pos = -- i;
                  break;
               }
            }
         }
         else {
            for(int i = 0; i < this.code.count(); i++) {
               if(this.code.get(i).contains("<img src=\"resources")) {
                  pos = i;
                  this.code.delete(i);
                  break;
               }
            }
            for(int i = 0; i < this.code.count(); i++) {
               if(this.code.get(i).contains(this.commentKey)) {
                  pos = i;
                  this.code.delete(i);
                  break;
               }
            }
         }
         if(pos < 0) {
            pos = this.code.count();
         }
//         final int line = this.code.count()   - _ele.getComment().count() + pos;
         if(AbstractElement.ADDJAVADOCIMAGE) {
// debug  System.out.println("In ADDJAVADOCIMAGE for "+_ele.getJName());
            this.code.insert(" *<img src=\"resources" + File.separator + _ele.getCompilationUnit().getDefaultFileName() + ".png\" alt=\"DNS model\" /><br />", pos);
            this.code.insert(" *<br />Source " + this.commentKey + " [charset " + this.jOutCode + "] from following DNS:<br /><br />", pos);
         }
         else {
// debug System.out.println("In SOURCE for "+_ele.getJName());
            this.code.insert(" * <br />Source " + this.commentKey + " [charset " + this.jOutCode + "].<br />", pos);
         }
         if(AbstractElement.SETSOURCEVERSION) {
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
            if(!_ele.getComment().getLongString().contains("@version")) {
               this.code.add(" *@version 1.00.00  build 1 " + sdf.format(Calendar.getInstance().getTime()));
            }
            if(!_ele.getComment().getLongString().contains("@author")) {
               this.code.add(" *@author " + System.getenv("USERNAME"));
            }
         }
      }
      this.code.add(" */");
// debug      System.out.println("Out generateHeaderJavadoc");
      return;
   }

/**
 *  processes inline comment (one line)
 */
   private String getComment(AbstractElement _ele, boolean top) {
      String comm = "";
      if(_ele.isCommented()) {
         if(AbstractElement.PROGRAMDOCONTOP || top) {
            for(int i = 0; i < _ele.getComment().count(); i++) {
               this.code.add("//" + _ele.getComment().get(i));
            }
         }
         else {
            comm = "  // " + _ele.getComment().getLongString();
         }
      }
      return comm;
   }

/**
 *  processes javadoc block comment (multiline)
 */
   private StringList getJavadocComment(AbstractElement _ele) {
      final StringList comm = new StringList();
      if(_ele.isCommented()) {
         int i = 0;
         for(; i < _ele.getComment().count() - 1; i++) {
            String comment = _ele.getComment().get(i);
            while(comment.length() > 0 && comment.charAt(0) == '/') {
               comment = comment.substring(1);
            }
            comm.add(" *" + _ele.getComment().get(i));
         }
         if(!_ele.getComment().get(i).trim().equals("")) {
            comm.add(" *" + _ele.getComment().get(i));
         }
      }
      return comm;
   }

/**
 *  special call code processing (one line)
 * 1: call: method;
 * 3: call: method|(|);
 * 4+: call: method|(|data|);
 * 3: call: var|=|method;
 * 4: call: int|var|=|method;
 * 5: call: var|=|method|(|);
 * 6: call: int[]|var|=|method|(|);
 * 6+: call: var|=|method|(|data|);
 * 7+: call: double|var|=|method|(|data|);
 */
   private void processCall(String _code) {
      Java3Code callCode = new Java3Code(_code);
      callCode.cleanupMultiline("\t").codeReduce(true);
      for(String s : callCode) {
         Java3Code line = new Java3Code(s);
         String xmeth = line.getMethodName();
         if(xmeth != null) {
            this.newMethod.addIfNew(xmeth);
         }
      }
   }

/**
 *final String[] parts = _code.trim().split(" ");
 *String methodName = "";
 *String preMethod = "";
 *String postMethod = "";
 *int namePos = 0;
 *if (_code.contains("=")) {
 *for (int i = 0; i < parts.length; i++) {
 *preMethod += parts[i] + " ";
 *if (parts[i].equals("=")) {
 *namePos = i + 1;
 *break;
 *}
 *}
 *}
 *methodName = parts[namePos];
 *for (int k = ++namePos; k < parts.length; k++) {
 *postMethod += " " + parts[k];
 *}
 *final String declare = preMethod + methodName + postMethod;
 *if (methodName.endsWith("(")) {
 *this.newMethod
 *.add(methodName.substring(0, methodName.length() - 1));
 *} else {
 *this.newMethod.add(methodName);
 *}
 *return declare;
 *  special Input code generation (one line)
 */
   private String processInput(String code1) {
// debug System.out.println("processInput < " + code1);
      Java3Code inputLine = new Java3Code(code1).spaceTokenize(false);
// debug   System.out.println("ProcessInp tokens <" + inputLine);
      final StringBuffer inputCode = new StringBuffer();
      final String[] parts = inputLine.getTokens();
      if(parts.length > 1 && parts[0].equalsIgnoreCase(Java3Code.input.trim())) {
         inputCode.append(parts[1]);
         for(int k = 2; k < parts.length; k++) {
            inputCode.append(" " + parts[k]);
         }
         this.importScanner = true;
// debug System.out.println("processInput 1> " +  Java3Code.deParenthesizeIt(inputCode.toString()) + " = (new Scanner(System.in)).nextLine()");
         return Java3Code.deParenthesizeIt(inputCode.toString()) + " = (new Scanner(System.in)).nextLine()";
      }
      String post = "(\"Please input a value\")";
      if(parts.length > 2 && parts[2].equalsIgnoreCase(Java3Code.input.trim()) && parts[1].equals("=")) {
         if(parts.length > 3) {
            inputCode.append(parts[3]);
            for(int k = 4; k < parts.length; k++) {
               inputCode.append(" " + parts[k]);
            }
            post = Java3Code.parenthesizeIt(inputCode.toString());
         }
         this.importSwingPane = true;
// debug System.out.println("processInput 2> " + parts[0] + " = JOptionPane.showInputDialog" + post);
         return parts[0] + " = JOptionPane.showInputDialog" + post;
      }
      if(parts.length > 3 && parts[3].equalsIgnoreCase(Java3Code.input.trim()) && parts[2].equals("=")) {
         if(parts.length > 4) {
            inputCode.append(parts[4]);
            for(int k = 5; k < parts.length; k++) {
               inputCode.append(" " + parts[k]);
            }
            post = Java3Code.parenthesizeIt(inputCode.toString());
         }
         this.importSwingPane = true;
// debug      System.out.println("processInput 3> " + parts[0] + " " + parts[1] + " = JOptionPane.showInputDialog" + post);
         return parts[0] + " " + parts[1] + " = JOptionPane.showInputDialog" + post;
      }
//  else: no changes
// debug     System.out.println("processInput exit >" + parts.length+" 0:" + parts[0] + " 1:" + parts[1] + " 2:" + parts[2] + " 3:" + parts[3] + " " );
      return code1;
   }

/**
 *  special Output code generation (one line)
 */
   private String processOutput(String code1) {
// debug    System.out.println("processOut < " + code1);
      String outputCode = code1.trim();
      String outStr = Java3Code.output.trim();
      if(outputCode.endsWith(";")) {
         outputCode = outputCode.substring(0, outputCode.length() - 1);
      }
// debug  System.out.println("outputCode <" + outputCode);
      if(outputCode.startsWith(outStr + " ") || outputCode.startsWith(outStr + "(")) {
         outputCode = outputCode.replace(outStr, "").trim();
         if(!Java3Code.needsPar(outputCode)) {

               outputCode = "try {\n   JOptionPane.showMessageDialog(null, " + Java3Code.deParenthesizeIt(outputCode) + "); \n} catch(Exception e){}";
               this.importSwingPane = true;
         }
         else {
            outputCode = "System.out.println" + Java3Code.parenthesizeIt(outputCode);
         }
      }
      return outputCode;
   }

   @Override()
   protected void generateCode(Alternative _alt, String _indent) {
      String condition = formatJavaSource(_alt.getCode().getLongString(), _indent);
      if(!Java3Code.preAlt.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.preAlt.trim() + " ", " ");
      }
      if(!Java3Code.postAlt.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.postAlt.trim() + " ", " ");
      }
      condition = Java3Code.parenthesizeIt(Java3Code.lineTrimSColon(condition));
      addCode(_indent + "if " + condition + " {" + getComment(_alt, false));
      generateCode(_alt.getTrueSubqueue(), _indent + "\t");
      this.code.add(_indent + "}");
      if(_alt.getFalseSubqueue().getSize() != 0) {
         this.code.add(_indent + "else {");
         generateCode(_alt.getFalseSubqueue(), _indent + "\t");
         this.code.add(_indent + "}");
      }
   }

   @Override()
   protected void generateCode(Call _call, String _indent) {
      boolean added = false;
// code
      Java3Code lines = new Java3Code(_call.getCode());
      lines.cleanupMultiline(_indent);
      for(String line : lines) {
         line = formatJavaSource(line, _indent);
         line = _indent + Java3Code.lineAddSColon(line);
         if(!added) {
            line += getComment(_call, false);
            added = true;
         }
         processCall(line);
         addCode(line);
      }
   }

   @Override()
   protected void generateCode(For _for, String _indent) {
      String condition = formatJavaSource(_for.getCode().getLongString(), _indent);
      if(!Java3Code.preFor.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.preFor.trim() + " ", " ");
      }
      if(!Java3Code.postFor.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.postFor.trim() + " ", " ");
      }
      condition = Java3Code.parenthesizeIt(Java3Code.lineTrimSColon(condition));
      addCode(_indent + "for " + condition + " {" + getComment(_for, false));
      generateCode(_for.getForSubqueue(), _indent + "\t");
      this.code.add(_indent + "}");
   }

   @Override()
   protected void generateCode(Instruction _inst, String _indent) {
      boolean added = false;
      Java3Code lines = new Java3Code(_inst.getCode());
      lines.cleanupMultiline(_indent);
      for(String line : lines) {
// debug System.out.println ("iterator gets: >" + line.replace("\r","R").replace("\n","N").replace("\t","T").replace(" ","-")+"<") ;
         line = formatJavaSource(line, _indent);
// debug System.out.println ("format gets:   >" + line.replace("\r","R").replace("\n","N").replace("\t","T").replace(" ","-")+"<") ;
// modified 13/03/2015 for labels
         if(line.trim().endsWith(":") && _indent != "") {
            line = _indent.substring(1) + line;
         }
         else {
            line = _indent + Java3Code.lineAddSColon(line);
         }
         if(!added) {
            line += getComment(_inst, false);
            added = true;
         }
// debug      System.out.println ("final is:   >" + line.replace("\r","R").replace("\n","N").replace("\t","T").replace(" ","-")+"<") ;
//          processCall(line);
         addCode(line);
      }
   }

   @Override()
   protected void generateCode(Repeat _repeat, String _indent) {
      String condition = formatJavaSource(_repeat.getCode().getLongString(), _indent);
      if(!Java3Code.preRepeat.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.preRepeat.trim() + " ", " ");
      }
      if(!Java3Code.postRepeat.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.postRepeat.trim() + " ", " ");
      }
      condition = Java3Code.parenthesizeIt(Java3Code.lineTrimSColon(condition));
      this.code.add(_indent + "do {" + getComment(_repeat, false));
      generateCode(_repeat.getDoSubqueue(), _indent + "\t");
      addCode(_indent + "}");
      addCode(_indent + "while " + condition + ";");
   }

   @Override()
   protected void generateCode(Subqueue _subqueue, String _indent) {
      for(int i = 0; i < _subqueue.getChildren().size(); i++) {
         doGenerate(_subqueue.getChildren().get(i), _indent);
      }
   }

   @Override()
   protected void generateCode(Switch _case, String _indent) {
//  pre-defined multi-line
      String condition = formatJavaSource(_case.getCode().get(0), _indent);
      if(!Java3Code.preCase.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.preCase.trim() + " ", "");
      }
      if(!Java3Code.postCase.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.postCase.trim() + " ", " ");
      }
      condition = Java3Code.parenthesizeIt(condition);
      this.code.add(_indent + "switch " + condition + " {" + getComment(_case, false));
      for(int i = 0; i < _case.getSwitchSubqueues().size() - 1; i++) {
         this.code.add(_indent + "\t" + "case " + _case.getCode().get(i + 1).trim() + ":");
         generateCode(_case.getSwitchSubqueues().get(i), _indent + "\t" + "\t");
      }
      if(!_case.getCode().get(_case.getSwitchSubqueues().size()).trim().equals("%")) {
         this.code.add(_indent + "\t" + "default:");
         generateCode(_case.getSwitchSubqueues().get(_case.getSwitchSubqueues().size() - 1), _indent + "\t" + "\t");
      }
      this.code.add(_indent + "}");
   }

   @Override()
   protected void generateCode(Try _try, String _indent) {
      Java3Code lines = new Java3Code(_try.getCode());
      for(String line : lines) {
         addCode(_indent + line);
      }
      addCode(_indent + " { ");
      generateCode(_try.getTrySubqueue(), _indent + "\t");
      addCode(_indent + "}");
       if(_try.getCatch().getCatchSubqueue().size() > 0) {
            for(int i = 0; i < _try.getCatch().getCatchSubqueue().size() - 1; i++) {
         String param = _try.getCatch().getCode().get(i + 1).trim();
         if(!param.contains(" ")) {
            param += " e";
         }
// 13/05/15 added, comments in catch/finally blocks
if (i==0)  {
         this.code.add(_indent + "catch (" + param + ") {"+ getComment(_try.getCatch(), false));
} else {
          this.code.add(_indent + "catch (" + param + ") {");
}
        generateCode(_try.getCatch().getCatchSubqueue().get(i), _indent + "\t");
         addCode(_indent + "}");
      }
       }
else {
      this.code.add(getComment(_try.getCatch(), false));
}

      if(_try.getFinally().getFinallySubqueue().getSize() > 0) {
         this.code.add(_indent + "finally {" + getComment(_try.getFinally(), false));
         generateCode(_try.getFinally().getFinallySubqueue(), _indent + "\t");
         this.code.add(_indent + "}");
      } else {
        this.code.add(getComment(_try.getFinally(), false));
      }
   }

   @Override()
   protected void generateCode(While _while, String _indent) {
      String condition = formatJavaSource(_while.getCode().getLongString(), _indent);
      if(!Java3Code.preWhile.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.preWhile.trim() + " ", " ");
      }
      if(!Java3Code.postWhile.equals("")) {
         condition = BString.replace(condition, " " + Java3Code.postWhile.trim() + " ", " ");
      }
      condition = Java3Code.parenthesizeIt(Java3Code.lineTrimSColon(condition));
      addCode(_indent + "while " + condition + " {" + getComment(_while, false));
      generateCode(_while.getWhileSubqueue(), _indent + "\t");
      this.code.add(_indent + "}");
   }

   @Override()
   protected String getDialogTitle() {
      return "Export Java...";
   }

   @Override()
   protected String getFileDescription() {
      return "Java Source Code";
   }

   @Override()
   protected String[] getFileExtensions() {
      final String[] exts = { "java" };
      return exts;
   }

}
