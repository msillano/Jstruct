//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
package lu.fisch.structorizer.parsers;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import javax.lang.model.element.Modifier;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Catch;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.Finally;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

import com.sun.source.tree.AssertTree;
import com.sun.source.tree.BlockTree;
import com.sun.source.tree.BreakTree;
import com.sun.source.tree.CaseTree;
import com.sun.source.tree.CatchTree;
import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.ContinueTree;
import com.sun.source.tree.DoWhileLoopTree;
import com.sun.source.tree.EmptyStatementTree;
import com.sun.source.tree.EnhancedForLoopTree;
import com.sun.source.tree.ExpressionStatementTree;
import com.sun.source.tree.LabeledStatementTree;

import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.ForLoopTree;
import com.sun.source.tree.IfTree;
import com.sun.source.tree.ImportTree;
import com.sun.source.tree.LineMap;
import com.sun.source.tree.MethodTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.ReturnTree;
import com.sun.source.tree.SwitchTree;
import com.sun.source.tree.ThrowTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.Tree.Kind;
import com.sun.source.tree.TryTree;
import com.sun.source.tree.VariableTree;
import com.sun.source.tree.WhileLoopTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SourcePositions;
import com.sun.source.util.TreeScanner;
import com.sun.source.util.Trees;

/**
 * Java  parser.
 * Transforms a java source in an Element tree.
 *
 * Problems:
 * Anonymous Classes are parsed as Instruction block (and not as Classes).
 * Source build by JStruct.<br />
 *
 * @version 1.01.01  build 18  (2012.03.12-20:59:31) JStruct-aware version
 * @version <br />1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class JavaParser {

	int _iocount = 0;
	int _varcount = 1;
	int lastEnd = 0;
	static boolean changeblockIn = false;

	CompilationUnit myProgram = new CompilationUnit();
	ArrayList<String> sourceDocLines;

	JavaCompiler compiler;
	static String javacVer;

	/**
	 * constructor
	 */
	public JavaParser() {
//		loadFromINI();
	}

	/**
	 * Method getter for sourceDocLines
	 * @return ArrayList<String>
	 */
	public ArrayList<String> getSourceDocLines() {
		return this.sourceDocLines;
	}

	/**
	 * Method getter for myProgram
	 * @return CompilationUnit
	 */
	public CompilationUnit getMyProgram() {
		return this.myProgram;
	}

	/**
	 * Method readComments.
	 * Creates sourceDocLines containing only comment
	 * every line of source code is processed:
	 * Block comment line start w '*'
	 * inline comment start w '/'
	 * code line start w 'c'
	 * @param fileName String
	 */


    private void readComments(String fileName, String jcode) {
        Java3Code jline;
        String line = "";
        this.sourceDocLines = new ArrayList<String>();
        try {
            final BufferedReader br = new BufferedReader(
                    (new InputStreamReader(new FileInputStream(fileName), jcode)));
            while ((line = br.readLine()) != null) {
// 20/03/2015 rewrited method
// debug
/*
      if (sourceDocLines.size()>0)
          System.out.println(" added:                 >" + sourceDocLines.get(sourceDocLines.size()-1 ));
*/
// debug      System.out.println("processing readComments >" + line);
                jline = new Java3Code(line.trim());
                if (jline.isBlockCommented()) {
                    line = jline.getBlockComment().trim();
// only start/end: skip
                    if (line.equals("/**")) {
                            this.sourceDocLines.add("c");
                            continue;
                    }
                    if (line.equals("/*")) {
                            this.sourceDocLines.add("c");
                            continue;
                    }

                    if (line.equals("*/")) {
                            this.sourceDocLines.add("c");
                            continue;
                    }
 // start/end embedded:
                    line = line.replace("/**","") ;
                    line = line.replace("/*","") ;
                    line = line.replace("*/","") ;
                    if ((line.length() >0) && line.charAt(0) == '*')
                            line = line.substring(1);
                    this.sourceDocLines.add("*" + line);
                    continue;
                }

                if (jline.isLineCommented()) {
                    this.sourceDocLines
                            .add(jline.getLineComment().substring(1));
                    continue;
                }

                this.sourceDocLines.add("c");
            }
            br.close();


//  save for debug
            StringList comments = StringList.getNew(this.sourceDocLines);
            comments.saveToFile("comments_extract.txt");

        } catch (final FileNotFoundException fN) {
            fN.printStackTrace();
        } catch (final IOException e) {
            System.err.println(e);
        }
    }




/*
 // old version not working after Java3Code update (12/03/2015)
	private void readComments(String fileName, String jcode) {
        Java3Code jline;
		String line = "";
		boolean inComment = false;
		this.sourceDocLines = new ArrayList<String>();
		try {
			final BufferedReader br = new BufferedReader(
					(new InputStreamReader(new FileInputStream(fileName), jcode)));
			while ((line = br.readLine()) != null) {

				if (inComment) {
					jline = new Java3Code(line.trim());
				} else {
					jline = new Java3Code(line.trim()).killStrings();
				}
// start block comment
				if (jline.isBlockCommented()) {
					line = jline.getBlockComment().trim();
                    inComment = true;
// cleanup
                    if ((line.length() >0) && line.charAt(0) == '/')
                        line = line.substring(1);
                    if ((line.length() >0) && line.charAt(0) == '*')
                        line = line.substring(1);
                    if ((line.length() >0) && line.charAt(0) == '*')
                        line = line.substring(1);

					if (line.equals("")) {
						this.sourceDocLines.add("c1");
						continue;
					}
                    if (line.equals("*"+"/")) {
                        this.sourceDocLines.add("c2");
                        inComment = false;
                        continue;
                    }

					if (line.contains("*"+"/")) {
						line = line.substring(0, line.indexOf("*"+"/"));
						if (!line.trim().equals("")) {
							this.sourceDocLines.add("*3" + line);
						} else {
							this.sourceDocLines.add("c3");
						}
						inComment = false;
						continue;
					}
				    this.sourceDocLines.add("*4" + line);

					continue;
				}

				if (!inComment && jline.isLineCommented()) {
					this.sourceDocLines
							.add(jline.getLineComment().substring(1));
					continue;
				}
				if (inComment && jline.contains("*"+"/")) {
					if (jline.getCode().indexOf("*>>>>>>>>>>>"+"/") == 0){
						this.sourceDocLines.add("+5");
					}
					else {
    					if (jline.startsWith("*")){
    						this.sourceDocLines.add("+6" + jline.getCode().substring(1, jline.getCode().indexOf("*"+"/")));
    					}else  {
    						this.sourceDocLines.add("+6" + jline.getCode().substring(0, jline.getCode().indexOf("*"+"/")));
    					}
					}
					inComment = false;
					continue;
				}
				if (inComment) {
					if (jline.getCode().length() > 0 && jline.getCode().charAt(0) == '*') {
						this.sourceDocLines.add(jline.toString());
					} else {
						this.sourceDocLines.add("*7" + jline.toString());
					}
					continue;
				}
				this.sourceDocLines.add("c8");
			}
			br.close();

//   debug
			StringList comments = StringList.getNew(this.sourceDocLines);
			comments.saveToFile("comments_extract.txt");

		} catch (final FileNotFoundException fN) {
			fN.printStackTrace();
		} catch (final IOException e) {
			System.err.println(e);
		}
	}
*/



	void deleteComment(int start, int end) {
		for (int i = start; i < end; i++) {
			this.sourceDocLines.set(i,
					"c - deleted: " + this.sourceDocLines.get(i));

		}
	}

	/**
	 * Method parse.
	 * @param javaFileName String
	 * @param jcode coding
	 * @return CompilationUnit
	 */
	public CompilationUnit parse(String javaFileName, String jcode) {
		this.compiler = ToolProvider.getSystemJavaCompiler();
		if (this.compiler == null) {
			throw new IllegalStateException(
					"Cannot find the system Java compiler. ");
		}
// gets version
		final OutputStream outStream = new ByteArrayOutputStream();
		this.compiler.run(null, outStream, outStream, "-version");
		JavaParser.javacVer = outStream.toString().trim();
// setup
		final DiagnosticCollector<JavaFileObject> diagnosticsCollector = new DiagnosticCollector<JavaFileObject>();
		final StandardJavaFileManager fileManager = this.compiler
				.getStandardFileManager(diagnosticsCollector, null,
						Charset.forName(jcode));
		final Iterable<? extends JavaFileObject> fileObjects = fileManager
				.getJavaFileObjectsFromStrings(Arrays.asList(javaFileName));
		final CompilationTask task = this.compiler.getTask(null, fileManager,
				diagnosticsCollector, null, null, fileObjects);
// Here we switch to Sun-specific APIs
		final JavacTask javacTask = (JavacTask) task;
		final SourcePositions sourcePositions = Trees.instance(javacTask)
				.getSourcePositions();
		Iterable<? extends CompilationUnitTree> parseResult = null;
		try {
			parseResult = javacTask.parse();
		} catch (final IOException e) {
			e.printStackTrace();
//		System.exit(0);
			return null;
		}
		this.myProgram.setFilename(javaFileName);
		readComments(javaFileName, jcode);
		if (parseResult != null) {
			for (final CompilationUnitTree compilationUnitTree : parseResult) {
				compilationUnitTree.accept(new MethodLineLogger(
						compilationUnitTree, sourcePositions), null);
			}
		}
		return this.myProgram;
	}

//
	/**
	 * to get line infos
	 */
	class MethodLineLogger extends TreeScanner<String, String> {

		private final CompilationUnitTree compilationUnitTree;
		private final SourcePositions sourcePositions;
		private final LineMap lineMap;

		/**
		 * Constructor for MethodLineLogger.
		 * @param compilationUnitTree CompilationUnitTree
		 * @param sourcePositions SourcePositions
		 */
		MethodLineLogger(CompilationUnitTree compilationUnitTree,
				SourcePositions sourcePositions) {
			this.compilationUnitTree = compilationUnitTree;
			this.sourcePositions = sourcePositions;
			this.lineMap = compilationUnitTree.getLineMap();
		}

		private final Stack<AbstractElement> elementsStack = new Stack<AbstractElement>();
		private final Stack<Subqueue> subQStack = new Stack<Subqueue>();

		/*
		private String blockLines(Tree pos) {
			long startLine = lineMap.getLineNumber(sourcePositions
					.getStartPosition(compilationUnitTree, pos));
			long endLine = lineMap.getLineNumber(sourcePositions
					.getEndPosition(compilationUnitTree, pos));
			return startLine + ":" + endLine;
		}
		 */

		private int getStartLine(Tree pos) {
			final long startLine = this.lineMap
					.getLineNumber(this.sourcePositions.getStartPosition(
							this.compilationUnitTree, pos));
			return (int) startLine;
		}

		private int getEndLine(Tree pos) {
			final long startLine = this.lineMap
					.getLineNumber(this.sourcePositions.getEndPosition(
							this.compilationUnitTree, pos));
			return (int) startLine;
		}

		/**
		 * Method reduce.
		 * @param arg0 String
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String reduce(String arg0, String arg1) {
			return "" + arg1 + ", " + arg0;
		}

		/**
		 * Method getBlockComment: returns StringList comment w "*"
		 * @param pos code line
		 * @param back lines to explore
		 * @return StringList
		 */
		private StringList getBlockComment(int pos, int back) {
			int line = pos - 1;
			final StringList newComment = new StringList();
			for (; line >= 0 && line > pos - back; line--) {
//debug				System.out.println("try_comm#" + line + "="	+ comments.get(line));
				if (getSourceDocLines().get(line).startsWith("+")) { // $codepro.audit.disable useCharAtRatherThanStartsWith
					String txt = getSourceDocLines().get(line).substring(1);
					getSourceDocLines().set(line, "- done end block");
					if (!txt.trim().equals("")) {
						newComment.insert(txt, 0);
					}
					while (getSourceDocLines().get(--line).startsWith("*")) { // $codepro.audit.disable useCharAtRatherThanStartsWith
						txt = getSourceDocLines().get(line).substring(1);
						getSourceDocLines().set(line, "- done block");
						newComment.insert(txt, 0);
					}
					return newComment;
				}
				if (getSourceDocLines().get(line).startsWith("x")) { // $codepro.audit.disable useCharAtRatherThanStartsWith
					final String txt = getSourceDocLines().get(line).substring(
							1);
					getSourceDocLines().set(line, "- done block single line");
					newComment.insert(txt, 0);
					return newComment;
				}
			}
			return newComment;
		}

		/**
		 * Method getNotes.
		 * @param pos code line (back = 5, fix)
		 * @return StringList
		 */
		private StringList getNotes(int pos) {
			int line = pos;
			final StringList newNotes = new StringList();
			String comment;
			while (line > 0) {
				comment = getSourceDocLines().get(--line);
				switch (comment.charAt(0)) {
				case 'x':
				case '*':
				case '+':
				case '/':
					getSourceDocLines().set(line, "- done line");
					newNotes.insert(comment.substring(1), 0);
				}
			}
			return newNotes;
		}

		private StringList getStartNotes() {

			int line = 0;
			String comment;
			final StringList newNotes = new StringList();
			while (true) {
				if ((comment = getSourceDocLines().get(line++)).startsWith("/")) {
					comment = comment.substring(1);
					getSourceDocLines().set(line - 1, "- done line");
					newNotes.add(comment);
				} else {
					if (line > 3)
						break;
				}
			}
			return newNotes;
		}

//
// @see  JavaGenerator.updateInfos(StringList comment, CompilationUnitTree tree)

		public void updateInfos(StringList comment, CompilationUnitTree tree) {
			AbstractElement.updateOptions(comment);
//10/04/2015 added: no exra infos if not required
            if(!AbstractElement.ADDJAVADOCEXTRA &&
            !AbstractElement.ADDJAVADOCPUBLIC &&
            !AbstractElement.ADDJAVADOCIMAGE &&
            !AbstractElement.SETSOURCEVERSION) return;

            comment.addReplace("@source:", "@source: "
                    + tree.getSourceFile().getName());
            comment.addReplace("@JStruct:", "@JStruct: "
                    + AbstractElement.E_VERSION + " Parser: "
                    + JavaParser.javacVer);
            comment.delete("package and ");
		}

		/**
		 * Method closeInstruction. common stuff for sequences blocks
		 * @param destroy boolean
		 */
		private void closeInstruction(boolean destroy) {
			if (this.elementsStack.peek() instanceof Instruction) {
				final AbstractElement x = this.elementsStack.pop();
				boolean ok = destroy;
				if (destroy) {
					for (int i = 0; i < x.getCode().count(); i++) {
						if (!x.getCode().get(i).startsWith("@")) { // $codepro.audit.disable useCharAtRatherThanStartsWith
							ok = false;
						}
					}
				}
				// empty
				if (ok && this.subQStack.peek().getChildren().contains(x)) {
					this.subQStack.peek().getChildren().remove(x);
				}
			}
		}

		/**
		 * Method openInstruction: common stuff for sequences blocks
		 * @param arg0 Tree
		 */
		private void openInstruction(Tree arg0) {
			if (!this.subQStack.empty()) {
				final AbstractElement newBlock = new Instruction();
				this.subQStack.peek().addElement(newBlock);
				this.elementsStack.push(newBlock);
				changeblockIn = false;
				newBlock.getComment().add(getNotes(getStartLine(arg0)));
//				newBlock.comment.add("@line: " + getStartLine(arg0));
			}

		}

		/* ======================= special visitTree ========================== */

		//      public R visitCompilationUnit(CompilationUnitTree node, P p)
		/**
		 * Method visitCompilationUnit.
		 * @param arg0 CompilationUnitTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitCompilationUnit(CompilationUnitTree arg0, String arg1) {
			this.elementsStack.push(getMyProgram());
			this.subQStack.push(getMyProgram().getChildQueue());
			getMyProgram().getCode().clear();
//debug			System.out.println(" in Unit " + arg0.getKind().toString());


			getMyProgram().getCode().add("// package and import");

			if (arg0.getPackageName() != null) {
				getMyProgram().getCode().add(
						"package " + arg0.getPackageName().toString() + ";");
				getMyProgram().getCode().add("");

			}
			if (arg0.getImports() != null) {
				for (final ImportTree tree : arg0.getImports()) {
					final String code = tree.toString();
					getMyProgram().getCode().add(Java3Code.lineCosmetic(code));
				}
			}
			getMyProgram().setJName(arg0.getSourceFile().getName());
			if (getMyProgram().getJName().contains(".")) {
				getMyProgram().setJName(
						getMyProgram().getJName().substring(0,
								getMyProgram().getJName().indexOf('.')));
			}
			getMyProgram().getComment().add(getStartNotes());
			updateInfos(getMyProgram().getComment(), arg0);

//
			super.visitCompilationUnit(arg0, null);
//debug			System.out.println(" out from Unit " + arg0.getKind().toString());
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop();
			return null;
		}

		//	     71       public R visitClass(ClassTree node, P p) {
		/**
		 * Method visitClass.
		 * @param arg0 ClassTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitClass(ClassTree arg0, String arg1) {
			/*
			 *  modifiers class simpleName typeParameters
			 *           extends extendsClause
			 *           implements implementsClause
			 *    {
			 *     members
			 *    }
			 */
			JClass newJClass;
			JavaParser.this._iocount = 0;
			JavaParser.this._varcount = 0;
			// create new root
//debug			System.out.println(" in Class " + arg0.getSimpleName());
			newJClass = new JClass();
			newJClass.setChangedNow(false);
			this.subQStack.peek().addElement(newJClass);
			this.elementsStack.push(newJClass);
// Class declaration
			String classDecl = "";
			if (arg0.getModifiers() != null) {
				classDecl += arg0.getModifiers();
			}
            if (!classDecl.contains("interface"))
		      	classDecl += "class ";
            classDecl += arg0.getSimpleName() + " ";
			newJClass.setJName(arg0.getSimpleName().toString());
			if (arg0.getTypeParameters() != null) {
				classDecl += arg0.getTypeParameters().toString() + " ";
			}
			if (arg0.getExtendsClause() != null) {
				classDecl += "\n   extends " + arg0.getExtendsClause();
			}
			if (arg0.getImplementsClause() != null
					&& !arg0.getImplementsClause().isEmpty()) {
				classDecl += "\n    implements " + arg0.getImplementsClause();
			}
			// eliminates defaults
			classDecl = classDecl.trim();
			newJClass.getCode().clear();
			newJClass.setCode(classDecl + ";");
			StringList jdoc = this.getBlockComment(getStartLine(arg0), 10);
			newJClass.getComment().add(this.getNotes(getStartLine(arg0)));
			newJClass.getComment().add(jdoc);

			if (AbstractElement.SETSOURCEVERSION)
				newJClass.setComment(Java3Code.updateBuild(newJClass
						.getComment()));
			// child - variables
			final List<VariableTree> globalVars = new ArrayList<VariableTree>();
			final List<Tree> members = new ArrayList<Tree>();
			for (final Tree aTree : arg0.getMembers()) {
				if (aTree.getKind().equals(Kind.VARIABLE)) {
					globalVars.add((VariableTree) aTree);
				} else {
					members.add(aTree);
				}
			}
			boolean isEnum = false;
			if (!globalVars.isEmpty()) {
				if (!newJClass.getCode().getLongString()
						.contains("global variables"))
					newJClass.getCode().add("/* class global variables */");
				for (final VariableTree aTree : globalVars) {
					String aVar = visitVariable(aTree, "");
// after javadoc
					final StringList comm = getBlockComment(
							getStartLine(aTree), 5);
					final StringList notes = getNotes(getStartLine(aTree));
					//adds notes
					for (int i = 0; i < notes.count(); i++) {
						if ((!notes.get(i).trim()
								.equals("class global variables")) && !(notes.get(i).trim()
								.equals("package and import")))
							newJClass.getCode().add("//" + notes.get(i));
					}
					switch (comm.count()) {
					case 0:
						break;
					case 1:
						if (!comm.get(0).trim()
								.equals("class global variables")) {
							final String x = "/" + "*" + comm.get(0) + "*"
									+ "/";
							newJClass.getCode().add(x);
						}
						break;
					default:
						int i = 0;
						if (comm.get(i).trim().equals("class global variables"))
							i++;
			         	if (comm.get(i).trim().equals("package and import"))
							i++;

						if (aVar.contains("public")) {
							newJClass.getCode().add("/" + "**");
							newJClass.getCode().add("*" + comm.get(i++));

						} else {
							newJClass.getCode().add("/" + "*" + comm.get(i++));

						}
						while (i < comm.count() - 1) {
							newJClass.getCode().add("*" + comm.get(i++));
						}
						newJClass.getCode().add(comm.get(i) + "*" + "/");
					}

//debug					System.out.println(" class.var : " + aVar);
					if (aVar.startsWith("/*public static")) {
						isEnum = true;
						classDecl = newJClass.getCode().getCommaText()
								.replace("class ", "enum ");
						newJClass.getCode().setCommaText(classDecl);
						aVar = aVar.replace("/*public static final*/", "")
								.trim();
						aVar = aVar.replace("/*public static final*/", "");
						aVar = aVar.replace("/* = new ", "");
						aVar = aVar.replace("/*enum", "");
						aVar = aVar.replace("*/", "");
						aVar = aVar.replace(newJClass.getJName(), "");
						aVar = aVar.replace("()", "");
						aVar = aVar.substring(0, aVar.length() - 1) + ",";
						newJClass.getCode().addLines(aVar);
					} else {
						if (isEnum) {
							int lastP1 = newJClass.getCode().count() - 1;
							String vList1 = newJClass.getCode().get(lastP1);
							vList1 = vList1.substring(0, vList1.length() - 1)
									+ ";";
							newJClass.getCode().set(lastP1, vList1);
						}
						newJClass.getCode().addLines(aVar);
					}

				}
				if (isEnum) {
					int lastP2 = newJClass.getCode().count() - 1;
					String vList2 = newJClass.getCode().get(lastP2);
					if (vList2.endsWith(",")) {
						vList2 = vList2.substring(0, vList2.length() - 1);
						newJClass.getCode().set(lastP2, vList2);
					}
				}
			}
			this.subQStack.push(newJClass.getChildQueue());
			// child - methods = Root
			for (final Tree aTree : members) {
				if (aTree.getKind().equals(Kind.METHOD)) {
					visitMethod((MethodTree) aTree, null);
				} else {
					if (aTree.getKind().equals(Kind.CLASS)) {
						visitClass((ClassTree) aTree, null);
					} else {
						if (aTree.getKind().equals(Kind.BLOCK)) {
							visitBlock((BlockTree) aTree, null);
                        } else {
                        if (aTree.getKind().equals(Kind.ENUM)) {
                            visitClass((ClassTree) aTree, null);

						} else {
							System.err.println("Warning: found member not Class or Method or Block but: "
											+ aTree.getKind().toString());
						}
						}
					}
				}
			}
//debug			System.out.println(" out class: " + arg0.getSimpleName());
			this.subQStack.pop();
			this.elementsStack.pop();
			return null;
		}

// 	   75       public R visitMethod(MethodTree node, P p) {
		/**
		 * Method visitMethod.
		 * @param arg0 MethodTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitMethod(MethodTree arg0, String arg1) {
			/*
			 *  modifiers typeParameters type name
			 *     ( parameters )
			 *     body
			 *
			 *  modifiers type name () default defaultValue
			 */
			int lineStart;
			JMethod newMethod = null;
			JavaParser.this._iocount = 0;
			JavaParser.this._varcount = 0;
			newMethod = new JMethod(StringList.getNew("mName"));
			newMethod.setClosed(false);
			this.subQStack.peek().addElement(newMethod);
//workaround for constructors
			lineStart = getStartLine(arg0);
			if (lineStart == 0) {
				if (arg0.getBody() != null)
					lineStart = getStartLine(arg0.getBody());
				else
					lineStart = getEndLine(arg0);
				do
					--lineStart;
				while (!getSourceDocLines().get(lineStart).startsWith("c"));
			}
// debug	System.out.println(" in Method: " + arg0.getName() + " start line: " +lineStart+ " end: " +getEndLine(arg0));

			StringList jdoc = this.getBlockComment(lineStart, 10);
			// method declaration
			String methDecl = "";
			// annotations
			if (arg0.getModifiers() != null) {
				if (!arg0.getModifiers().getAnnotations().isEmpty()) {

					methDecl += arg0.getModifiers().getAnnotations().toString()
							+ "\n";
				}
// flags
				if (arg0.getModifiers().getFlags() != null) {
					for (Modifier xM : arg0.getModifiers().getFlags()) {

						methDecl += xM.toString() + " ";
					}
				}
			}
			if (arg0.getTypeParameters() != null) {
				methDecl += arg0.getTypeParameters() + " ";
			}
			if (arg0.getReturnType() != null) {
				methDecl += arg0.getReturnType().toString() + " ";
			}
			newMethod.setJName(arg0.getName().toString());
// constructor
			if (newMethod.getJName().equals("<init>")) {
				AbstractElement x = newMethod;
				while (!(x instanceof JClass)) {
					x = x.getParent();
				}
				newMethod.setJName(((RootElement) x).getJName());
			}
			methDecl += newMethod.getJName() + "(";
			if (arg0.getParameters() != null) {
				methDecl += arg0.getParameters().toString();
			}
			methDecl += ") ";
			if (!arg0.getThrows().isEmpty()) {
				methDecl += "throws ";
				methDecl += arg0.getThrows().toString();
			}
			newMethod.getCode().clear();
			methDecl = methDecl.trim();
			newMethod.setCode(methDecl);
			newMethod.getComment().add(this.getNotes(getStartLine(arg0)));
			newMethod.getComment().add(jdoc);
			if (AbstractElement.SETSOURCEVERSION)
				newMethod.setComment(Java3Code.updateBuild(newMethod
						.getComment()));
			this.elementsStack.push(newMethod);
			this.subQStack.push(newMethod.getChildQueue());
// process children
			if (arg0.getBody() != null)
				visitBlock(arg0.getBody(), null);
			this.subQStack.pop();
			this.elementsStack.pop();
//debug			System.out.println(" out Root " + arg0.getName());
			return null;
		}

// 	   87       public R visitBlock(BlockTree node, P p) {
		/**
		 * Method visitBlock.
		 * @param arg0 BlockTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitBlock(BlockTree arg0, String arg1) {
			/*		   { }
			 *		   { statements }
			 *		   static { statements }
			 */
//debug			System.out.println(" in Block ");
			if (arg0.isStatic()) {
// debug				System.out.println(" == is static! ");
				JMethod newMethod = new JMethod(StringList.getNew("mName"));
				newMethod.setClosed(false);
				this.subQStack.peek().addElement(newMethod);
				newMethod.setJName("static");
				newMethod.setCode(newMethod.getJName());
				newMethod.getComment().add(this.getNotes(getStartLine(arg0)));
				if (newMethod.getComment().count() == 0)
					newMethod.getComment().add("static method");
				this.elementsStack.push(newMethod);
				this.subQStack.push(newMethod.getChildQueue());
//
				openInstruction(arg0);
				super.visitBlock(arg0, null);
				closeInstruction(true);

				this.subQStack.pop();
				this.elementsStack.pop();
			} else if (arg0.getStatements().isEmpty()) {
				openInstruction(arg0);
				final StringList notes = getNotes(getEndLine(arg0));
				if (notes.getLongString().equals(""))
					this.elementsStack.peek().getCode()
							.add(" /* empty statement */ ");
				else
					this.elementsStack.peek().getCode()
							.add("//" + notes.getLongString());
				closeInstruction(true);
			} else {
				openInstruction(arg0);
				super.visitBlock(arg0, null);
				closeInstruction(true);
			}
			return null;
		}

// 	   91       public R visitWhileLoop(WhileLoopTree node, P p) {
		/**
		 * Method visitWhileLoop.
		 * @param arg0 WhileLoopTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitWhileLoop(WhileLoopTree arg0, String arg1) {
			/*		   while ( condition )
			 *             statement
			 */
//debug			System.out.println(" in Wile ");
			final String code = Java3Code.preWhile + " "
					+ arg0.getCondition().toString();
			final While myWhile = new While(StringList.explode(code, "\n"));
			myWhile.getComment().add(getNotes(getStartLine(arg0)));
// and subqueue
			final Subqueue qCase = myWhile.getWhileSubqueue();
			closeInstruction(true);
// adds while
			this.subQStack.peek().addElement(myWhile);
			this.elementsStack.push(myWhile);
			this.subQStack.push(qCase);
			openInstruction(arg0);
			super.visitWhileLoop(arg0, null);
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop();
// adds instruction
			openInstruction(arg0);
//debug			System.out.println(" out while ");
			return null;
		}

//	        public R visitDoWhileLoop(DoWhileLoopTree node, P p) {
		/**
		 * Method visitDoWhileLoop.
		 * @param arg0 DoWhileLoopTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitDoWhileLoop(DoWhileLoopTree arg0, String arg1) {
			/*		   do
			 *           statement
			 *   while ( expression );
			 */
//debug			System.out.println(" in DoWile ");
			final String code = Java3Code.postRepeat + " "
					+ arg0.getCondition().toString();
			// base element
			final Repeat myRepeat = new Repeat(StringList.explode(code, "\n"));
			myRepeat.getComment().add(getNotes(getStartLine(arg0)));
			// and subqueue
			final Subqueue qCase = myRepeat.getDoSubqueue();
			// stacks management
// close sequence
			closeInstruction(true);
// adds while
			this.subQStack.peek().addElement(myRepeat);
			this.elementsStack.push(myRepeat);
			this.subQStack.push(qCase);
			super.visitDoWhileLoop(arg0, null);
			this.subQStack.pop();
			this.elementsStack.pop();
// adds instruction
			openInstruction(arg0);
//debug                   System.out.println(" out doWhile ");
			return null;
		}

		/**
		 * Method getCaseLabel.
		 * @param arg0 CaseTree
		 * @return String
		 */
		String getCaseLabel(CaseTree arg0) {
			if (arg0.getExpression() == null) {
				return "default";
			}
			return arg0.getExpression().toString();
		}

//		    	  111       public R visitSwitch(SwitchTree node, P p) {
		/**
		 * Method visitSwitch.
		 * @param arg0 SwitchTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitSwitch(SwitchTree arg0, String arg1) {
			/*     switch ( expression ) {
			 *         cases
			 *     }
			 */
			final String expression = Java3Code.deParenthesizeIt(arg0
					.getExpression().toString());
			final Switch myCase = new Switch(expression);
			closeInstruction(true);
			this.elementsStack.push(myCase);
			myCase.getComment().add(getNotes(getStartLine(arg0)));
//			myCase.comment.add("@lines:switch:"+ blockLines(arg0));
			this.subQStack.peek().addElement(myCase);
// loop cases
			for (final CaseTree cTree : arg0.getCases()) {
				final Subqueue lastQ = new Subqueue();
				lastQ.setParent(myCase);
				// handle stacks
				myCase.getSwitchSubqueues().addElement(lastQ);
				this.subQStack.push(lastQ);
				openInstruction(arg0);
				myCase.getCode().add(getCaseLabel(cTree));
				visitCase(cTree, null);
				closeInstruction(true);
				this.subQStack.pop();
			}
			if (!myCase.getCode().contains("default")) {
				myCase.getCode().add("%");
				final Subqueue lastQ = new Subqueue();
				lastQ.setParent(myCase);
				myCase.getSwitchSubqueues().addElement(lastQ);
			}
			this.elementsStack.pop();
			openInstruction(arg0);
			return null;
		}

// 	  135       public R visitIf(IfTree node, P p) {

		/**
		 * Method visitIf.
		 * @param arg0 IfTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitIf(IfTree arg0, String arg1) {
			/*
			 *  if ( condition )
			 *    thenStatement
			 *
			 *  if ( condition )
			 *     thenStatement
			 *  else
			 *     elseStatement
			 */
			final String condition = Java3Code.deParenthesizeIt(arg0
					.getCondition().toString()) + "\n?";
			final Alternative myIf = new Alternative(StringList.explode(
					condition, "\n"));
			//adds if
			closeInstruction(true);
			this.elementsStack.push(myIf);
			myIf.getComment().add(getNotes(getStartLine(arg0)));
//			myIf.comment.add("@lines:if:"+ blockLines(arg0));
			this.subQStack.peek().addElement(myIf);
			this.subQStack.push(myIf.getTrueSubqueue());
			openInstruction(arg0);
			this.scan(arg0.getThenStatement(), null);
			closeInstruction(true);
			this.subQStack.pop();
			if (arg0.getElseStatement() != null) {
				this.subQStack.push(myIf.getFalseSubqueue());
				openInstruction(arg0);
				this.scan(arg0.getElseStatement(), null);
				closeInstruction(true);
				this.subQStack.pop();
			}
			this.elementsStack.pop();
			openInstruction(arg0);
			return null;
		}

//	   99       public R visitForLoop(ForLoopTree node, P p) {
		/**
		 * Method visitForLoop.
		 * @param arg0 ForLoopTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitForLoop(ForLoopTree arg0, String arg1) {
			/*
			 *	for ( initializer ; condition ; update )
			 *			statement
			 */
//new error 4/3/2015: 	arg0.getInitializer() and 	arg0.getUpdate() ends with ";"
// now accepts all
			String sfor = "for (" + arg0.getInitializer();
			if (sfor.endsWith(";"))  sfor += " "; else sfor += "; ";
			sfor += arg0.getCondition();
			if (sfor.endsWith(";"))  sfor += " "; else sfor += "; ";
			sfor += arg0.getUpdate();
			if (sfor.endsWith(";"))
				sfor = sfor.substring(0, sfor.length() -1);

			 sfor+= ")";
			final For myFor = new For(sfor);
			//adds if
			closeInstruction(true);
			this.elementsStack.push(myFor);
			myFor.getComment().add(getNotes(getStartLine(arg0)));
//			myFor.comment.add("@lines:for:"	+ blockLines(arg0));
			this.subQStack.peek().addElement(myFor);
			this.subQStack.push(myFor.getForSubqueue());
			openInstruction(arg0);
			this.scan(arg0.getStatement(), null);
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop();
			openInstruction(arg0);
			return null;
		}

//  	  103       public R visitEnhancedForLoop(EnhancedForLoopTree node, P p) {
		/**
		 * Method visitEnhancedForLoop.
		 * @param arg0 EnhancedForLoopTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitEnhancedForLoop(EnhancedForLoopTree arg0, String arg1) {
			/*
			 *		  for ( variable : expression )
			 *            statement
			 */
			String sfor = "for (" + arg0.getVariable();
			sfor += " : " + arg0.getExpression() + ")";
			final For myFor = new For(sfor);
			//adds if
			closeInstruction(true);
			this.elementsStack.push(myFor);
			myFor.getComment().add(getNotes(getStartLine(arg0)));
//			myFor.comment.add("@lines:for:"	+ blockLines(arg0));
			this.subQStack.peek().addElement(myFor);
			this.subQStack.push(myFor.getForSubqueue());
			openInstruction(arg0);
			this.scan(arg0.getStatement(), null);
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop();
			openInstruction(arg0);
			return null;
		}

//	 	  123       public R visitTry(TryTree node, P p) {
		/**
		 * Method visitTry.
		 * @param arg0 TryTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitTry(TryTree arg0, String arg1) {
			/*	 try
			         block
			     catches
			     finally
			         finallyBlock

			 */
			// special case: skip try added by JStruct like:
			/*
						try {
							JOptionPane.showMessageDialog(null,  "inserire scelta >>");
							}
							catch(Exception e){
							}
			 */
			final String code = arg0.getBlock().getStatements().toString();
//debug                   System.out.println("XX try:" + code);
			if (!code.contains("\n")
					&& code.startsWith("JOptionPane.showMessageDialog")
					&& code.contains("null")) {
				deleteComment(getStartLine(arg0) - 1, getEndLine(arg0));
				visitExpressionStatement((ExpressionStatementTree) arg0
						.getBlock().getStatements().get(0), null);
				return null;
			}
			closeInstruction(true);
			final Try myTry = new Try("try");
			this.elementsStack.push(myTry);
			this.subQStack.peek().addElement(myTry);
			this.subQStack.push(myTry.getTrySubqueue());
//
// List<? extends Tree>    getResources()
            String resources = "";
            for (final Tree rTree : arg0.getResources()){
                 resources += rTree.toString() + ";\n    ";
    //debug     System.out.println("XX try.resources " + resources);
            }
            if (resources.length() > 2) {
                resources = resources.substring(0,resources.length()-6);
                myTry.setResorce(resources);
            }
        	myTry.getComment().add(getNotes(getStartLine(arg0)));
			openInstruction(arg0);
			this.scan(arg0.getBlock(), null);
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop(); // pop Try
			//
			final Catch myCatch = myTry.getCatch();
			myCatch.getCode().clear();
			myCatch.getCatchSubqueue().clear();
			this.elementsStack.push(myCatch);
// TODO
//Exception in thread "AWT-EventQueue-0" java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
//    at com.sun.tools.javac.util.List.get(List.java:476)
//    at lu.fisch.structorizer.parsers.JavaParser$MethodLineLogger.visitTry(JavaParser.java:1143)

//			myCatch.getComment().add(
//					getNotes(getStartLine(arg0.getCatches().get(0))));


//old			myCatch.comment.add("@lines:catch:"	+ blockLines(arg0.getCatches().get(0)));
			myCatch.getCode().add("catch");
			Subqueue lastQ;
			for (final CatchTree cTree : arg0.getCatches()) {
				lastQ = new Subqueue();
				lastQ.setParent(myTry);
				myCatch.getCatchSubqueue().addElement(lastQ);
				myCatch.getCode().add(cTree.getParameter().toString());
				// handle stacks
				this.subQStack.push(lastQ);
				openInstruction(arg0);
				super.visitBlock(cTree.getBlock(), null);
				closeInstruction(true);
				this.subQStack.pop();
			}
			// handle stacks
			this.elementsStack.pop();
			myCatch.getCode().add("%");
//			myCatch.getCode().add("default");
			lastQ = new Subqueue();
			lastQ.setParent(myTry);
			myCatch.getCatchSubqueue().addElement(lastQ);
//
			final Finally myFinally = myTry.getFinally();
			this.elementsStack.push(myFinally);
			myFinally.getComment().add(
					getNotes(getStartLine(arg0.getFinallyBlock())));
			this.subQStack.push(myFinally.getFinallySubqueue());
			openInstruction(arg0);
			this.scan(arg0.getFinallyBlock(), null);
			closeInstruction(true);
			this.subQStack.pop();
			this.elementsStack.pop();
			openInstruction(arg0);
			return null;
		}

//  ==============================================================
//  CODE LINE ELEMENTS
//  ==============================================================
		/**
		 * Method varchange.
		 * @param code String
		 * @return String
		 */
		private String varchange(String code) {
			if (code.trim().equals("String[] args")) { // skip main params
				return "";
			}
			return code.trim();
		}

//	       79       public R visitVariable(VariableTree node, P p) {
		/**
		 * Method visitVariable.
		 * @param arg0 VariableTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitVariable(VariableTree arg0, String arg1) {
//			  modifiers type name initializer ;
// debug 	System.out.println(getStartLine(arg0) +" in Variable " + arg0.toString());
			if (arg1 == null) {
				String code = varchange(arg0.toString());
				code = iochange(code);
				if (!code.equals("")) {
//debug				System.out.println("commento0: "+this.elementsStack.peek().getComment().getLongString());
					isVAR();
					if (changeblockIn) {
						closeInstruction(true);
						openInstruction(arg0);
					}
//debug					System.out.println("out Variable code: " + code);
					this.elementsStack.peek().getCode().addLines(code);
					StringList comm = getBlockComment(getStartLine(arg0), 10);
					StringList notes = getNotes(getStartLine(arg0));
					this.elementsStack.peek().getComment().add(notes);
					this.elementsStack.peek().getComment().add(comm);
//debug			System.out.println("commento1: "+this.elementsStack.peek().getComment().getLongString());
//debug			System.out.println("comm= "+ comm +" notes= "+ notes );

				}
				return null;
			}
//debug     System.out.println("out Variable ");
			final String code = varchange(arg0.toString());
			return arg1 + iochange(code);
		}

		private void isVAR() {
			changeblockIn = false;
			JavaParser.this._iocount = 0;
			JavaParser.this._varcount++;
			if (JavaParser.this._varcount == 1) {
				changeblockIn = true;
			}
		}

		private void isIO() {
			changeblockIn = false;
			JavaParser.this._varcount = 0;
			JavaParser.this._iocount++;
			if (JavaParser.this._iocount == 1) {
				changeblockIn = true;
			}
		}

		private void isSTD() {
			changeblockIn = false;
			if (JavaParser.this._iocount > 0) {
				JavaParser.this._iocount = 0;
				changeblockIn = true;
			}
			if (JavaParser.this._varcount > 0) {
				JavaParser.this._varcount = 0;
				changeblockIn = true;
			}
		}

		/**
		 * Method iochange.
		 * @param code String
		 * @return String
		 */
		private String iochange(String code) {
// like:
//   JOptionPane.showMessageDialog(null,  "maggiore di" + "\"\\  u 5\\\" t  ");
			String format;
			if (code.startsWith("JOptionPane.showMessageDialog(")
                    && code.contains("null")){
// 22/03/2015 added: only one ','
                Java3Code IOline = new Java3Code(code);
                IOline.killStrings();
                if (IOline.getCode().indexOf(",") != IOline.getCode().lastIndexOf(",")) {
                    return (code);
                }
// stampa (x)
				format = code.replace("JOptionPane.showMessageDialog", "");
				format = Java3Code.lineTrimSColon(format);
				format = Java3Code.deParenthesizeIt(format).trim();
				format = format.replace("null", "").trim();
				if (format.length() > 0 && format.charAt(0) == ',') {
					format = format.substring(1).trim();
					format = Java3Code.deParenthesizeIt(format).trim();
					isIO();
					return Java3Code.output + " (" + format + ");";
				}
//debug	System.out.println(d);
			} else if (code.startsWith("System.out.println(")) {
//  stampa x
				format = code.replace("System.out.println", "").trim();
				format = Java3Code.deParenthesizeIt(format).trim();
				if (!format.equals("")) {
					isIO();
					return Java3Code.output + " " + format + ";";
				}
// like:
// t = JOptionPane.showInputDialog("Please input a value");
			} else if (code.contains("JOptionPane.showInputDialog")) {
// t = leggi(" ")
				format = code.replace("JOptionPane.showInputDialog",
						Java3Code.input + " ").trim();
				isIO();
				return format + ";";
// like:
// u  = (new Scanner(System.in)).nextLine();
			} else if (code.contains("=") && code.contains("System.in")
					&& code.contains(".nextLine(") && code.contains("Scanner")) {
// leggi u
				final String[] parts = code.split("=");
				format = Java3Code.input + " " + parts[0].trim();
				isIO();
				return format + ";";
			}
			isSTD();
			return code.trim() + ";";
		}

		//	  139       public R visitExpressionStatement(ExpressionStatementTree node, P p) {
		/**
		 * Method visitExpressionStatement.
		 * @param arg0 ExpressionStatementTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitExpressionStatement(ExpressionStatementTree arg0,
				String arg1) {
			//		 expression ;
			final String code;
			/*
						if (arg0.getExpression().getKind().equals(Kind.NEW_CLASS)){
						code = this.scan(arg0.getExpression(), arg1);
			//				return null;
						}
						else
			*/
//			final String code = arg0.getExpression().toString();
			code = arg0.getExpression().toString();
//debug 	System.out.println(getStartLine(arg0) + " in visitExp: " + arg0.getExpression().getKind());
//	        if (code.contains("\n")){
//	        	super.visitExpressionStatement(arg0, arg1);
//	        	return null;
//	        }
			if (arg1 == null) {
				final String c = iochange(code);
				/* old
								if (changeblockIn) {
									closeInstruction(true);
									openInstruction(arg0);
								}
								this.elementsStack.peek().getText().add(c);
								final StringList notes = getNotes(getStartLine(arg0));
								if (notes.count() > 0) {
									this.elementsStack.peek().comment.add(notes);
									closeInstruction(true);
									openInstruction(arg0);
								}
				*/
				final StringList notes = getNotes(getStartLine(arg0));
				StringList sCode = StringList.explode(c, "\n");
//debug				if (sCode.count()>1)
//debug				    System.out.println("last char = "+ sCode.get(1).codePointAt(sCode.get(1).length()-1));
				if (changeblockIn || notes.count() > 0 || sCode.count() > 1) {
					closeInstruction(true);
					openInstruction(arg0);
				}
				this.elementsStack.peek().getCode().add(sCode);
				this.elementsStack.peek().getComment().add(notes);
				if (sCode.count() > 1) {
					closeInstruction(true);
					openInstruction(arg0);
				}

				return null;
			}
			return arg1 + code;
		}

// 	  155       public R visitThrow(ThrowTree node, P p)
		/**
		 * Method visitThrow.
		 * @param arg0 ThrowTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitThrow(ThrowTree arg0, String arg1) {
			//  throw expression;
			final String code = arg0.toString();
			if (arg1 == null) {
				closeInstruction(true);
				openInstruction(arg0);
				this.elementsStack.peek().getCode().add(code);
				closeInstruction(true);
				openInstruction(arg0);
				return null;
			}
			return arg1 + code;
		}

//  	  159       public R visitAssert(AssertTree node, P p) {
		/**
		 * Method visitAssert.
		 * @param arg0 AssertTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitAssert(AssertTree arg0, String arg1) {
//			  assert condition ;
//			   assert condition : detail ;
			final String code = arg0.toString();
			if (arg1 == null) {
				closeInstruction(true);
				openInstruction(arg0);
				this.elementsStack.peek().getCode().add(code);
				closeInstruction(true);
				openInstruction(arg0);
				return null;
			}
			return arg1 + code;
		}

		@Override
		public String visitContinue(ContinueTree arg0, String arg1) {
			final String code = arg0.toString();
			if (arg1 == null) {
				closeInstruction(true);
				openInstruction(arg0);
				this.elementsStack.peek().getCode().add(code);
				closeInstruction(true);
				openInstruction(arg0);
				return null;
			}
			return arg1 + code;
		}
// added 13/03/2015
        @Override
        public String visitLabeledStatement(LabeledStatementTree arg0, String arg1) {
            final String code = arg0.getLabel().toString() + " :";
            if (arg1 == null) {
                closeInstruction(true);
                openInstruction(arg0);
                this.elementsStack.peek().getCode().add(code);
                final StringList notes = getNotes(getStartLine(arg0));
                this.elementsStack.peek().getComment().add(notes);
                closeInstruction(true);
                openInstruction(arg0);
                super.visitLabeledStatement(arg0, arg1);
                return null;
            }
            return super.visitLabeledStatement(arg0, arg1 + code );
        }

		@Override
		public String visitBreak(BreakTree arg0, String arg1) {
			final String code = arg0.toString();
			if (arg1 == null) {
				closeInstruction(true);
				openInstruction(arg0);
				this.elementsStack.peek().getCode().add(code);
				closeInstruction(true);
				openInstruction(arg0);
				return null;
			}
			return arg1 + code;
		}

// 	  151       public R visitReturn(ReturnTree node, P p) {
		/**
		 * Method visitReturn.
		 * @param arg0 ReturnTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitReturn(ReturnTree arg0, String arg1) {
//			  return;
//			   return expression;
			final String code = arg0.toString();
			if (arg1 == null) {
				closeInstruction(true);
				openInstruction(arg0);
				this.elementsStack.peek().getCode().add(code);
				closeInstruction(true);
				openInstruction(arg0);
				return null;
			}
			return arg1 + code;
		}

//	  167       public R visitNewClass(NewClassTree node, P p) {
		/**
		 * Method visitNewClass.
		 * @param arg0 NewClassTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitNewClass(NewClassTree arg0, String arg1) {
//debug		System.out.println("in NewClass");
			final StringBuffer code = new StringBuffer();
			String scode = "";
			if (arg0.getEnclosingExpression() == null) {
				code.append("new ");
				if (arg0.getTypeArguments() != null
						&& !arg0.getTypeArguments().isEmpty()) {
					for (final Tree taTree : arg0.getTypeArguments()) {
// debug    			System.out.println("taTree = " + taTree.getKind());

						code.append(super.scan(taTree, "") + ", ");
					}
				}
				code.append(super.scan(arg0.getIdentifier(), "") + "( ");
				if (arg0.getArguments() != null
						&& !arg0.getArguments().isEmpty()) {
					for (final ExpressionTree etree : arg0.getArguments()) {
						code.append(super.scan(etree, "") + ", ");
					}
					code.delete(code.length() - 2, code.length());
				}

				scode = code.toString().trim() + ") ";
				if (arg0.getClassBody() != null) {
					scode += "\n/* structurizer limit: nested classes not allowed */\n";
				}
			} else {
				code.append(super.scan(arg0.getEnclosingExpression(), "")
						+ ".new ");
				code.append(super.scan(arg0.getIdentifier(), "") + "( ");
				if (arg0.getArguments() != null
						&& !arg0.getArguments().isEmpty()) {
					for (final ExpressionTree etree : arg0.getArguments()) {
						code.append(super.scan(etree, "") + ", ");
					}
//      			code = code.substring(0, code.length() - 2);
					code.delete(code.length() - 2, code.length());
				}
//				code = code.trim() + ") ";
				scode = code.toString().trim() + ") ";
			}

//debug      System.out.println("out NewClass: " + scode);
			return arg1 + scode;
		}

//	   83       public R visitEmptyStatement(EmptyStatementTree node, P p) {
		/**
		 * Method visitEmptyStatement.
		 * @param arg0 EmptyStatementTree
		 * @param arg1 String
		 * @return String
		 */
		@Override
		public String visitEmptyStatement(EmptyStatementTree arg0, String arg1) {
			final StringList notes = getNotes(getEndLine(arg0));
			if (notes.getLongString().equals(""))
				return arg1 + "\n// empty statement";
			return arg1 + "\n//" + notes.getLongString();
		}
	} // ends MethodLineLogger

}