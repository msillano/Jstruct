/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.parsers;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    Parse plugin-file
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------		----			-----------
 *      Bob Fisch       2008.04.12              First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************///

import java.io.BufferedInputStream;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import lu.fisch.structorizer.helpers.GENPlugin;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 */
public class GENParser extends DefaultHandler {

	private Vector<GENPlugin> plugins = new Vector<GENPlugin>();

	@Override
	public void startElement(String namespaceUri, String localName, String qualifiedName, Attributes attributes) throws SAXException
	{
		// --- PLUGINS ---
		if (qualifiedName.equals("plugin"))
		{
			final GENPlugin plugin = new GENPlugin();

			if(attributes.getIndex("class")!=-1)  {plugin.className=attributes.getValue("class");}
			if(attributes.getIndex("title")!=-1)  {plugin.title=attributes.getValue("title");}
			if(attributes.getIndex("icon")!=-1)  {plugin.icon=attributes.getValue("icon");}

			this.plugins.add(plugin);
		}
	}
	@Override
	public void endElement(String namespaceUri, String localName, String qualifiedName) throws SAXException
	{
		/*empty*/
	}

	@Override
	public void characters(char[] chars, int startIndex, int endIndex)
	{
		/*empty*/
	}

	/**
	 * @param _is
	 * @return Vector
	 */
	public Vector<GENPlugin> parse(BufferedInputStream _is)
	{
		this.plugins = new Vector<GENPlugin>();

		final SAXParserFactory factory = SAXParserFactory.newInstance();
		try
		{
			final SAXParser saxParser = factory.newSAXParser();
			saxParser.parse(_is,this);
		}
		catch(final Exception e)
		{
			final String errorMessage = "Error parsing input bugger: " + e;
			System.err.println(errorMessage);
			e.printStackTrace();
		}

		return this.plugins;
	}
}
