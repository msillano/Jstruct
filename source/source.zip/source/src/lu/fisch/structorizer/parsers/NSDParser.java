/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.parsers;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    XML input parser to generate a structogramm frm it savefile.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------		----			-----------
 *      Bob Fisch       2007.12.13              First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************/
//

import java.awt.Color;
import java.awt.Font;
import java.util.Stack;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Call;
import lu.fisch.structorizer.elements.Catch;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.Finally;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * nsd  parser.
 * Transforms a ".nsd" file (XML) in an Element tree.
 */
public class NSDParser extends DefaultHandler {

	private CompilationUnit jprogram = null;

	private final Stack<AbstractElement> stack = new Stack<AbstractElement>();
	private final Stack<AbstractElement> ifStack = new Stack<AbstractElement>();
	private final Stack<Subqueue> qStack = new Stack<Subqueue>();
	private final Stack<AbstractElement> cStack = new Stack<AbstractElement>();

    String filename;
    String myParser;

	private Subqueue lastQ = null;
	private AbstractElement lastE = null;

	/**
	 * @param comment
	 */
	public void updateInfos( StringList comment ){
		comment.addReplace("@source:",
				"@source: " + this.filename );
		comment.addReplace(
				"@JStruct:",
				"@JStruct: " + AbstractElement.E_VERSION + " SAXParser: "
						+  this.myParser );
		AbstractElement.updateOptions(comment);
	}


	@Override
	public void startElement(String namespaceUri, String localName,
			String qualifiedName, Attributes attributes) throws SAXException {
		// --- ELEMENTS ---
		// 2011.03.01 added
		if (qualifiedName.equals("jprogram")) {
			this.jprogram = new CompilationUnit();
			this.jprogram.getChildQueue().getChildren().clear();
			if (attributes.getIndex("code") != -1) {
				this.jprogram.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				this.jprogram.getComment().setCommaText(
						attributes.getValue("comment"));
				this.updateInfos(this.jprogram.getComment());
			}
			String fName = null;
			if (attributes.getIndex("font") != -1) {
				fName = attributes.getValue("font");
			}
			int fSize = 0;
			if (attributes.getIndex("fontSize") != -1) {
				fSize = Integer.parseInt(attributes.getValue("fontSize"));
			}
			if (fName != null){
				AbstractElement.setFont(new Font(fName,Font.PLAIN,fSize));
			}
			this.lastE = this.jprogram;
			this.stack.push(this.jprogram);

		} else if (qualifiedName.equals("jclass")) {
			// 2011.03.01 added
			final JClass aclass = new JClass(StringList.getNew("???"));
			aclass.getChildQueue().getChildren().clear();
			aclass.setClosed(true);
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					aclass.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}
			if (attributes.getIndex("code") != -1) {
				aclass.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				aclass.getComment()
				.setCommaText(attributes.getValue("comment"));
				aclass.setComment(Java3Code.updateBuild(aclass.getComment()));
			}
			if (attributes.getIndex("status") != -1) {
				if (attributes.getValue("status").equals("open")) {
					aclass.setClosed(false);
				}
			}
			// place stack
			aclass.getChildQueue().setColor(aclass.getColor());
			this.lastE = aclass;
			this.stack.push(aclass);
			this.lastQ.addElement(aclass);
		} else if (qualifiedName.equals("method")) {
			// 2011.03.01 added
			// create element
			final JMethod root = new JMethod(StringList.getNew("???"));
			root.setClosed(true);
			// read attributes
			// 2011.03.01
			if (attributes.getIndex("status") != -1) {
				if (attributes.getValue("status").equals("open")) {
					root.setClosed(false);
				}
			}
			// 2011.03.01
			//		if(attributes.getIndex("style")!=-1)  {if (attributes.getValue("type").equals(" ")) {root.isNice=true;}}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					root.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}
			if (attributes.getIndex("code") != -1) {
				root.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				root.getComment().setCommaText(attributes.getValue("comment"));
				// 2011.03.01
				root.setComment(Java3Code.updateBuild(root.getComment()));
			}

			root.getChildQueue().setColor(root.getColor());
			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}
			// place stack
			this.lastE = root;
			this.stack.push(root);
			this.lastQ.addElement(root);
			// handle stacks

//			lastQ.addElement(root);
		}

		else if (qualifiedName.equals("instruction")) {
			// create element
			final Instruction ele = new Instruction(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}
/*
			if (attributes.getIndex("rotated") != -1) {
				if (attributes.getValue("rotated").equals("1")) {
					ele.rotated = true;
				}
			}
*/
			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		}
		// 2011.03.01 deleted
		/*
		else if (qualifiedName.equals("jump"))
		{
			// create element
			Jump ele = new Jump(StringList.getNew("???"));

			// read attributes
			// read attributes
			if(attributes.getIndex("code")!=-1)  {ele.getText().setCommaText(attributes.getValue("code"));}
			if(attributes.getIndex("comment")!=-1)  {ele.getComment().setCommaText(attributes.getValue("comment"));}
			if(attributes.getIndex("color")!=-1)  {if (!attributes.getValue("color").equals("")) {ele.setColor(ele.getColor().decode("0x"+attributes.getValue("color")));}}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// place stack
			lastE=ele;
			stack.push(ele);
			lastQ.addElement(ele);
		}
		 */
		else if (qualifiedName.equals("call")) {
			// create element
			final Call ele = new Call(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		} else if (qualifiedName.equals("alternative")) {
			// create element
			final Alternative ele = new Alternative(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getTrueSubqueue().setColor(ele.getColor());
			ele.getFalseSubqueue().setColor(ele.getColor());

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		} else if (qualifiedName.equals("while")) {
			// create element
			final While ele = new While(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getWhileSubqueue().setColor(ele.getColor());

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		} else if (qualifiedName.equals("for")) {
			// create element
			final For ele = new For(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getForSubqueue().setColor(ele.getColor());

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		}

		// 2011.03.01 added
		else if (qualifiedName.equals("finally")) {
			// create element
			final Finally ele = new Finally(StringList.getNew("finally"));

			// read attributes
            //      if(attributes.getIndex("code")!=-1)  {ele.getCode().setCommaText(attributes.getValue("code"));}
            if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getFinallySubqueue().setColor(ele.getColor());

			if (this.stack.peek() instanceof Try) {
				((Try) this.stack.peek()).setFinally(ele);
			} else {
				System.err.println("Finally-error: not found parent Try "
						+ this.stack.peek().getClass().getSimpleName());
			}

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			//		lastQ.addElement(ele); not added
		} else if (qualifiedName.equals("try")) {
			// create element
			final Try ele = new Try(StringList.getNew("try"));

			// read attributes
            if(attributes.getIndex("code")!=-1)  {
                ele.getCode().setCommaText(attributes.getValue("code"));
            }
            if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getTrySubqueue().setColor(ele.getColor());

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		} else if (qualifiedName.equals("catch")) {
			// create element
			final Catch ele = new Catch("catch");

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			ele.getCatchSubqueue().clear();
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			if (this.stack.peek() instanceof Try) {
				((Try) this.stack.peek()).setCatch(ele);
			} else {
				System.err.println("Catch-error: not found parent Try "
						+ this.stack.peek().getClass().getSimpleName());
			}
			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			//		lastQ.addElement(ele); not added
			this.cStack.push(ele);
		}

		// 2011.03.01 deleted
		/*
				else if (qualifiedName.equals("forever"))
				{
					// create element
					Forever ele = new Forever(StringList.getNew("???"));

					// read attributes
					if(attributes.getIndex("code")!=-1)  {ele.getText().setCommaText(attributes.getValue("code"));}
					if(attributes.getIndex("comment")!=-1)  {ele.getComment().setCommaText(attributes.getValue("comment"));}
					if(attributes.getIndex("color")!=-1)  {if (!attributes.getValue("color").equals("")) {ele.setColor(ele.getColor().decode("0x"+attributes.getValue("color")));}}

					// set system attribute - NO!
					// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

					// set children
					ele.q.setColor(ele.getColor());

					// place stack
					lastE=ele;
					stack.push(ele);
					lastQ.addElement(ele);
				}
		 */
		else if (qualifiedName.equals("repeat")) {
			// create element
			final Repeat ele = new Repeat(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// set children
			ele.getDoSubqueue().setColor(ele.getColor());

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
		} else if (qualifiedName.equals("case")) {
			// create element
			final Switch ele = new Switch(StringList.getNew("???"));

			// read attributes
			if (attributes.getIndex("code") != -1) {
				ele.getCode().setCommaText(attributes.getValue("code"));
			}
			ele.getSwitchSubqueues().clear();
			if (attributes.getIndex("comment") != -1) {
				ele.getComment().setCommaText(attributes.getValue("comment"));
			}
			if (attributes.getIndex("color") != -1) {
				if (!attributes.getValue("color").equals("")) {
					ele.setColor(Color.decode(
							"0x" + attributes.getValue("color")));
				}
			}

			// set system attribute - NO!
			// if(attributes.getIndex("comment")!=-1)  {AbstractElement.E_SHOWCOMMENTS = AbstractElement.E_SHOWCOMMENTS || !attributes.getValue("comment").trim().equals("");}

			// place stack
			this.lastE = ele;
			this.stack.push(ele);
			this.lastQ.addElement(ele);
			this.cStack.push(ele);
		}
		// --- QUEUES ---
		else if (qualifiedName.equals("qCase")) {
			// create new queue
			this.lastQ = new Subqueue();
			// setup queue
			this.lastQ.setParent(this.cStack.peek());
			this.lastQ.setColor(this.lastQ.getParent().getColor());
			// handle stacks
			((Switch) this.cStack.peek()).getSwitchSubqueues().addElement(this.lastQ);
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("children")) {
			if (this.lastE instanceof CompilationUnit) {
				this.lastQ = ((CompilationUnit) this.lastE).getChildQueue();
				this.qStack.push(this.lastQ);
			} else {
				System.err.println("Catch-error: not found parent CompilationUnit "
						+ this.stack.peek().getClass().getSimpleName());
			}
		} else if (qualifiedName.equals("methods")) {
			// 2011.03.01
			if (this.lastE instanceof JClass) {
				this.lastQ = ((JClass) this.lastE).getChildQueue();
				this.qStack.push(this.lastQ);
			} else {
				System.err.println("Catch-error: not found parent JClass "
						+ this.stack.peek().getClass().getSimpleName());
			}
		} else if (qualifiedName.equals("body")) {
			// 2011.03.01
			if (this.lastE instanceof JMethod) {
				// handle stacks
				this.lastQ = ((JMethod) this.lastE).getChildQueue();
				this.qStack.push(this.lastQ);
			} else {
				System.err.println("Catch-error: not found parent JMethod "
						+ this.stack.peek().getClass().getSimpleName());
			}
		} else if (qualifiedName.equals("qTrue")) {
			// create new queue
			this.lastQ = ((Alternative) this.lastE).getTrueSubqueue();
			this.ifStack.push(((Alternative) this.lastE).getFalseSubqueue());
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qFalse")) {
			// handle stacks
			this.lastQ = (Subqueue) this.ifStack.pop();
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qFor")) {
			// handle stacks
			this.lastQ = ((For) this.lastE).getForSubqueue();
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qTry")) {
			// 2011.03.01
			// handle stacks
			this.lastQ = ((Try) this.lastE).getTrySubqueue();
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qFinally")) {
			// handle stacks
			// 2011.03.01
			this.lastQ = ((Finally) this.lastE).getFinallySubqueue();
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qCatch")) {
			// create new queue like case
			this.lastQ = new Subqueue();
			// setup queue
			this.lastQ.setParent(this.cStack.peek());
			this.lastQ.setColor(this.lastQ.getParent().getColor());
			// handle stacks
			((Catch) this.cStack.peek()).getCatchSubqueue().addElement(this.lastQ);
			this.qStack.push(this.lastQ);
		}
		/*
			else if (qualifiedName.equals("qForever"))
			{
				// handle stacks
				lastQ = ((Forever) lastE).q;
				qStack.push(lastQ);
			}
		 */
		else if (qualifiedName.equals("qWhile")) {
			// handle stacks
			this.lastQ = ((While) this.lastE).getWhileSubqueue();
			this.qStack.push(this.lastQ);
		} else if (qualifiedName.equals("qRepeat")) {
			// handle stacks
			this.lastQ = ((Repeat) this.lastE).getDoSubqueue();
			this.qStack.push(this.lastQ);
		}
	}

	@Override
	public void endElement(String namespaceUri, String localName,
			String qualifiedName) throws SAXException {
		// --- STRUCTURES ---
		if (qualifiedName.equals("method")
				||
				// 2011.03.01
				qualifiedName.equals("jclass") || qualifiedName.equals("call")
				|| qualifiedName.equals("jprogram")
				|| qualifiedName.equals("instruction")
				|| qualifiedName.equals("while")
				|| qualifiedName.equals("repeat")
				|| qualifiedName.equals("alternative")

//		   qualifiedName.equals("forever") ||
				|| qualifiedName.equals("try")
				|| qualifiedName.equals("finally")
				||qualifiedName.equals("for")) {
			this.lastE = this.stack.pop();
		} else if (qualifiedName.equals("case")
				|| qualifiedName.equals("catch")) {
			this.lastE = this.stack.pop();
			this.cStack.pop();
		}
		// -- QUEUES ---
		else if (qualifiedName.equals("qCase")
				|| qualifiedName.equals("qFor")
				|| qualifiedName.equals("qTry")
				|| qualifiedName.equals("qCatch")
				|| qualifiedName.equals("qFinally")
				|| qualifiedName.equals("qWhile")
				|| qualifiedName.equals("qRepeat")
				//			|| qualifiedName.equals("qTrue")
				|| qualifiedName.equals("qFalse")) {
			this.lastQ =  this.qStack.pop();
			this.lastQ =  this.qStack.peek();
		} else if (qualifiedName.equals("body")) {
			this.lastQ =  this.qStack.pop();
			this.lastQ =  this.qStack.peek();
		} else if (qualifiedName.equals("children")) {
			this.lastQ =  this.qStack.pop();
			// 2011.03.01
//			lastQ = (Subqueue) qStack.peek();
		} else if (qualifiedName.equals("methods")) {
			this.lastQ =  this.qStack.pop();
			this.lastQ =  this.qStack.peek();
		} else if (qualifiedName.equals("qTrue")) {
			this.lastQ =  this.qStack.pop();
		}
	}

	@Override
	public void characters(char[] chars, int startIndex, int endIndex) {
		//String dataString =	new String(chars, startIndex, endIndex).trim();
	}

	// 2011.03.01
	/**
	 * @param _filename
	 * @return  the elements tree
	 */
	public CompilationUnit parse(String _filename) {
       // test for filename

		// clear stacks
		this.stack.clear();
		this.ifStack.clear();
		this.qStack.clear();
		this.cStack.clear();
		this.filename= _filename;
		SAXParserFactory factory  = SAXParserFactory.newInstance();
		try {
			final SAXParser saxParser = factory.newSAXParser();
			this.myParser = saxParser.getClass().getCanonicalName() + " " +saxParser.getClass().getPackage().getSpecificationVersion();
			saxParser.parse(_filename, this);
		} catch (final Exception e) {
			final String errorMessage = "Error parsing " + _filename + ": " + e;
			System.err.println(errorMessage);
			e.printStackTrace();
		}
		// 2011.03.01
		this.jprogram.setChangedNow(false);

		return this.jprogram;
	}
}
