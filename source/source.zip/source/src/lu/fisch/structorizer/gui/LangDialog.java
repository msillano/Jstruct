/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class extends a "JDialog" to support language settings
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2008.01.14      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************///

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import lu.fisch.utils.StringList;

/**
 *
 */
public class LangDialog extends JDialog
{
	private static final long serialVersionUID = 1294083077924976923L;

	protected String langFile = null;

	private static JFrame dummyFrame = new JFrame();


	 void setLang(String _langfile)
	{
		this.langFile = _langfile;
		setLang(this,_langfile);
	}

	 void setLang(StringList _lines)
	{
		setLang(this,_lines);
	}

	 static void setLang(Component _com, String _langfile)
	{
		  StringBuffer input = new StringBuffer();

		try
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(_com.getClass().getResourceAsStream(_langfile), "UTF-8"));
			//BufferedReader in = new BufferedReader(new InputStreamReader(_com.getClass().getResourceAsStream(_langfile), "ISO-8859-1"));
			String str;
			while ((str = in.readLine()) != null)
			{
				input.append(str+"\n");
			}
			in.close();
		}
		catch (IOException e)
		{
			System.err.println("LANG: Error while loading language file => "+e.getMessage());
		}

		StringList lines = new StringList();
		lines.setText(input.toString());
		setLang(_com,lines);
	}

	 static void setLang(Component _com, StringList _lines)
	{
		StringList pieces;
		StringList parts;
// debug
/*
		if(_com instanceof Mainform)
					System.out.println("LANG: in setLang call ");
*/

		for(int i=0;i<_lines.count();i++)
		{
			parts = StringList.explode(_lines.get(i),"=");
			pieces = StringList.explode(parts.get(0),"\\.");

			if (pieces.get(0).toLowerCase().equals(_com.getClass().getSimpleName().toLowerCase()))
			{
				if(pieces.get(1).toLowerCase().equals("title"))
				{
					if(_com instanceof JDialog)
					{
						((JDialog) _com).setTitle(parts.get(1));
					}
				}
				else
				if(pieces.get(1).toLowerCase().equals("message"))
				{
					if(_com instanceof Mainform)
					{
//debug					System.out.println("LANG: message ["+parts.get(1)+"]");
						((Mainform) _com).getParsePane().setMessage(parts.get(1));
					}
				}
				else
				{
					try
					{
						Field field = _com.getClass().getDeclaredField(pieces.get(1));

						if(field!=null)
						{
							Class<?> fieldClass = field.getType();

							if (pieces.get(2).toLowerCase().equals("text"))
							{
								Method method = fieldClass.getMethod("setText",new Class [] {String.class});
								method.invoke(field.get(_com),new Object [] {parts.get(1)});
							}
							else if (pieces.get(2).toLowerCase().equals("tooltip"))
							{
								Method method = fieldClass.getMethod("setToolTipText",new Class [] {String.class});
								method.invoke(field.get(_com),new Object [] {parts.get(1)});
							}
							else if (pieces.get(2).toLowerCase().equals("border"))
							{
								Method method = fieldClass.getMethod("setBorder",new Class [] {Border.class});
								method.invoke(field.get(_com),new Object [] {new TitledBorder(parts.get(1))});
						 	}
							else if (pieces.get(2).toLowerCase().equals("tab"))
							{
								Method method = fieldClass.getMethod("setTitleAt",new Class [] {int.class,String.class});
								method.invoke(field.get(_com),new Object [] {Integer.valueOf(pieces.get(3)),parts.get(1)});
							}
						}
						else
						{
							System.err.println("LANG: Field not found <"+pieces.get(1)+">");
						}
					}

				    catch (SecurityException e) {
						System.err.println("LANG: Error while setting field <"+pieces.get(2)+"> for element <"+pieces.get(1)+">!\n"+e.getMessage());
					}
					catch (IllegalAccessException e)
					{
						System.err.println("LANG: Error while setting field <"+pieces.get(2)+"> for element <"+pieces.get(1)+">!\n"+e.getMessage());
					}
					catch ( NoSuchFieldException e)
					{
						System.err.println("LANG: Error while setting field <"+pieces.get(2)+"> for element <"+pieces.get(1)+">!\n"+e.getMessage());
					}
					catch ( NoSuchMethodException e)
					{
						System.err.println("LANG: Error while setting field <"+pieces.get(2)+"> for element <"+pieces.get(1)+">!\n"+e.getMessage());
					}
					catch ( InvocationTargetException e)
					{
						System.err.println("LANG: Error while setting field <"+pieces.get(2)+"> for element <"+pieces.get(1)+">!\n"+e.getMessage());
					}

				}
			}
		}
	}

	 LangDialog()
	{
		super(dummyFrame);
		dummyFrame.setIconImage(IconLoader.ico074.getImage());
		this.repaint();
	}

	 LangDialog(Frame owner)
	{
		super(owner);
	}

	 LangDialog(Dialog owner)
	{
		super(owner);
	}

	 LangDialog(Frame owner, boolean modal)
	{
		super(owner, modal);
	}
}
