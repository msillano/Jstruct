/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the GUI for the analyser preferences
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2008.05.23      First Issue
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

/**
 * @author Bob Fisch
 */
public class AnalyserPreferences extends LangDialog {

	/**
	 *
	 */
	private static final long serialVersionUID = -8035957316928975120L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Bob Fisch
	private JPanel dialogPane;
	private JPanel contentPanel;
//	public JCheckBox check1;
//	public JCheckBox check2;
           JCheckBox check3;
	       JCheckBox check4;
	       JCheckBox check5;
	       JCheckBox check6;
           JCheckBox check7;
           JCheckBox check8;
//	public JCheckBox check9;
           JCheckBox check10;
	       JCheckBox check11;
	       JCheckBox check12;
           JCheckBox check13;
           JPanel buttonBar;
           JButton okButton;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	/*public AnalyserPreferences()
	{
		super();
		setModal(true);
		initComponents();
	}*/

	 AnalyserPreferences(Frame owner) {
		super(owner);
		setModal(true);
		initComponents();
	}

	/*public AnalyserPreferences(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Bob Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
//		check1 = new JCheckBox();
//		check2 = new JCheckBox();
        this.check3 = new JCheckBox();
		this.check4 = new JCheckBox();
		this.check5 = new JCheckBox();
		this.check6 = new JCheckBox();
		this.check7 = new JCheckBox();
		this.check8 = new JCheckBox();
//		check9 = new JCheckBox();
		this.check10 = new JCheckBox();
		this.check11 = new JCheckBox();
		this.check12 = new JCheckBox();
		this.check13 = new JCheckBox();
		this.buttonBar = new JPanel();
		this.okButton = new JButton();

		//======== this ========
		setTitle("Analyser preferences");
		setResizable(false);
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			/*dialogPane.setBorder(new javax.swing.border.CompoundBorder(
				new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
					"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
					javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
					java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new GridLayout(10, 1));

				//---- check1 ----
//				check1.setText("Check for modified loop variable.");
//				contentPanel.add(check1);

				//---- check2 ----
//				check2.setText("Check for endless loop (as far as detectable!).");
//				contentPanel.add(check2);

				//---- check3 ----
				check3.setText("Check for empty Catch.");
				contentPanel.add(check3);

				//---- check4 ----
				this.check4.setText("Check for incorrect use of the IF-statement.");
				this.contentPanel.add(this.check4);

				//---- check5 ----
				this.check5.setText("Check for correct variable names.");
				this.contentPanel.add(this.check5);

				//---- check6 ----
				this.check6.setText("Check for correct Classes / Methods names.");
				this.contentPanel.add(this.check6);

				//---- check7 ----
				this.check7.setText("Check for valid java identifiers.");
				this.contentPanel.add(this.check7);

				//---- check8 ----
				this.check8.setText("Check for assignment in conditions.");
				this.contentPanel.add(this.check8);

				//---- check9 ----
//				check9.setText("Check that the program / sub name is not equal to any other identifier.");
//				contentPanel.add(check9);

				//---- check10 ----
				this.check10.setText("Check for multiple instruction sequences.");
				this.contentPanel.add(this.check10);

				//---- check11 ----
				this.check11.setText("Check for Methods calls.");
				this.contentPanel.add(this.check11);

				//---- check12 ----
				this.check12.setText("Check for public Class name");
				this.contentPanel.add(this.check12);

				//---- check13----
				this.check13.setText("Check Methods return.");
				this.contentPanel.add(this.check13);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

				//---- okButton ----
				this.okButton.setText("OK");
				this.buttonBar.add(this.okButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);

		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// Bob-thinks
		// add the KEY-listeners
		this.okButton.requestFocus(true);
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
			// nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
			//  nothing to do
			}
		};
		this.okButton.addKeyListener(keyListener);

		// add the ACTION-listeners
		final ActionListener actionListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				setVisible(false);
			}
		};
		this.okButton.addActionListener(actionListener);
	}

}
