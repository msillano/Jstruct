/*
    JStruct
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class is a special speedbutton.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2008.01.27      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		Differents parts of code have been copied from different forums on the net.
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.print.*;

import javax.swing.*;
import javax.swing.border.*;

/**
 * @author Bob Fisch
 */
public class PrintPreview extends LangDialog implements Runnable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6521569951515133839L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Bob Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JScrollPane scrPreview;
	protected JPanel buttonBar;
	protected JComboBox<String> m_cbScale;
	protected JButton btnOrientation;
	protected JButton btnOK;
	protected JButton btnCancel;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	// Bob
	protected int m_wPage;
	protected int m_hPage;
	protected Printable m_target;
	protected PreviewContainer m_preview;
	protected PageFormat pp_pf = null;


	/**
	 * @param frame
	 * @param target
	 */
	public PrintPreview(Frame frame, Printable target) {
		super(frame);
		this.m_target = target;
		initComponents();
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Bob Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.scrPreview = new JScrollPane();
		this.buttonBar = new JPanel();
		this.m_cbScale = new JComboBox<String>();
		this.btnOrientation = new JButton();
		this.btnOK = new JButton();
		this.btnCancel = new JButton();

		this.btnOrientation.setVisible(false);

		//======== this ========
		setTitle("Print Preview");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new BorderLayout());
				this.contentPanel.add(this.scrPreview, BorderLayout.CENTER);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 0, 85, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0, 0.0, 0.0};
				this.buttonBar.add(this.m_cbScale, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 5), 0, 0));

				//---- btnOrientation ----
				this.btnOrientation.setText("Toggle Orientation");
				this.buttonBar.add(this.btnOrientation, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 5), 0, 0));

				//---- btnOK ----
				this.btnOK.setText("OK");
				this.buttonBar.add(this.btnOK, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 5), 0, 0));

				//---- btnCancel ----
				this.btnCancel.setText("Cancel");
				this.buttonBar.add(this.btnCancel, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// Bob
		setModal(true);
		setSize(680,400);

		// add the KEY-listeners
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				// nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
				// nothing to do
			}
		};
		this.btnCancel.addKeyListener(keyListener);
		this.btnOrientation.addKeyListener(keyListener);
		addKeyListener(keyListener);

		// OK button
		ActionListener lst = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					// Use default printer, no dialog
					final PrinterJob prnJob = PrinterJob.getPrinterJob();
					prnJob.setPrintable(PrintPreview.this.m_target,PrintPreview.this.pp_pf);
					if (prnJob.printDialog())
					{
						setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
						prnJob.print();
						setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						dispose();
					}
				}
				catch (final PrinterException ex)
				{
					ex.printStackTrace();
					System.err.println("Printing error: "+ex.toString());
				}
			}
		};
		this.btnOK.addActionListener(lst);

		// add the KEY-listeners 2
		final KeyListener keyListenerPrint = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER)
				{
					try
					{
						final PrinterJob prnJob = PrinterJob.getPrinterJob();
						prnJob.setPrintable(PrintPreview.this.m_target,PrintPreview.this.pp_pf);
						if (prnJob.printDialog())
						{
							setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
							prnJob.print();
							setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
							dispose();
						}
					}
					catch (final PrinterException ex)
					{
						ex.printStackTrace();
						System.err.println("Printing error: "+ex.toString());
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				// nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
				// nothing to do
			}
		};
		this.btnOK.addKeyListener(keyListenerPrint);


		// Cancel button
		lst = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				dispose();
			}
		};
		this.btnCancel.addActionListener(lst);

		// scale list
		this.m_cbScale.addItem("10 %");
		this.m_cbScale.addItem("25 %");
		this.m_cbScale.addItem("50 %");
		this.m_cbScale.addItem("75 %");
		this.m_cbScale.addItem("100 %");
		this.m_cbScale.setSelectedIndex(4);
		lst = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				final Thread runner = new Thread(PrintPreview.this);
				runner.start();
			}
		};
		this.m_cbScale.addActionListener(lst);

		// orientation
		final ActionListener orient = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (PrintPreview.this.pp_pf.getOrientation() == PageFormat.PORTRAIT)
				{
					PrintPreview.this.pp_pf.setOrientation(PageFormat.LANDSCAPE);
				}
				else
				{
					PrintPreview.this.pp_pf.setOrientation(PageFormat.PORTRAIT);
				}
				final Thread runner = new Thread(PrintPreview.this);
				runner.start();
			}
		};
		this.btnOrientation.addActionListener(orient);


		// preview
		this.m_preview = new PreviewContainer();

		final PrinterJob prnJob = PrinterJob.getPrinterJob();
		this.pp_pf = prnJob.defaultPage();
		if (this.pp_pf.getHeight() == 0 || this.pp_pf.getWidth() == 0)
		{
			System.err.println("Unable to determine default page size");
			return;
		}

		this.m_wPage = (int)this.pp_pf.getWidth();
		this.m_hPage = (int)this.pp_pf.getHeight();

		final int scale = 100;
		final int w = (this.m_wPage * scale / 100);
		final int h = (this.m_hPage * scale / 100);

		int pageIndex = 0;
		try
		{
			while (true)
			{
				final BufferedImage img = new BufferedImage(this.m_wPage, this.m_hPage, BufferedImage.TYPE_INT_RGB);
				final Graphics g = img.getGraphics();
				g.setColor(Color.white);
				g.fillRect(0, 0, this.m_wPage, this.m_hPage);
				if (this.m_target.print(g, this.pp_pf, pageIndex) != Printable.PAGE_EXISTS)
					break;
				final PagePreview pp = new PagePreview(w, h, img);
				this.m_preview.add(pp);
				pageIndex++;
			}
		}
		catch (final PrinterException e)
		{
			e.printStackTrace();
			System.err.println("Printing error: "+e.toString());
		}
		this.m_preview.addKeyListener(keyListener);

		this.scrPreview.setViewportView(this.m_preview);

		this.btnOrientation.setFocusable(false);
		this.m_cbScale.setFocusable(false);
		this.btnOK.requestFocus(true);
	}

	// runnable interface
	@Override
	public void run()
	{
		this.m_wPage = (int)this.pp_pf.getWidth();
		this.m_hPage = (int)this.pp_pf.getHeight();

		String str = this.m_cbScale.getSelectedItem().toString();
		if (str.endsWith("%"))
			str = str.substring(0, str.length() - 1);
		str = str.trim();
		int scale = 0;
		try
		{
			scale = Integer.parseInt(str);
		}
		catch (final NumberFormatException ex)
		{
			return;
		}
		final int w = (this.m_wPage * scale / 100);
		final int h = (this.m_hPage * scale / 100);

		this.m_preview = new PreviewContainer();

		int pageIndex = 0;
		try
		{
			while (true)
			{
				final BufferedImage img = new BufferedImage(this.m_wPage, this.m_hPage, BufferedImage.TYPE_INT_RGB);
				final Graphics g = img.getGraphics();
				g.setColor(Color.white);
				g.fillRect(0, 0, this.m_wPage, this.m_hPage);
				if (this.m_target.print(g, this.pp_pf, pageIndex) != Printable.PAGE_EXISTS)
					break;
				final PagePreview pp = new PagePreview(w, h, img);
				this.m_preview.add(pp);
				pageIndex++;
			}
		}
		catch (final PrinterException e)
		{
			e.printStackTrace();
			System.err.println("Printing error: "+e.toString());
		}

		this.scrPreview.setViewportView(this.m_preview);
// TODO test use of gc()
//		System.gc();

		/*
		Component[] comps = m_preview.getComponents();
		for (int k = 0; k < comps.length; k++)
		{
			if (!(comps[k] instanceof PagePreview))
				continue;
			PagePreview pp = (PagePreview) comps[k];
			pp.setScaledSize(w, h);
		}
		m_preview.doLayout();
		m_preview.getParent().getParent().validate();
		 */
	}


	// sub classes
	static class PreviewContainer extends JPanel
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 3326214856472743948L;
		protected int H_GAP = 16;
		protected int V_GAP = 10;

		@Override
		public Dimension getPreferredSize()
		{
			final int n = getComponentCount();
			if (n == 0)
				return new Dimension(this.H_GAP, this.V_GAP);
			final Component comp = getComponent(0);
			final Dimension dc = comp.getPreferredSize();
			final int w = dc.width;
			final int h = dc.height;

			final Dimension dp = getParent().getSize();
			final int nCol = Math.max((dp.width - this.H_GAP) / (w + this.H_GAP), 1);
			int nRow = n / nCol;
			if (nRow * nCol < n)
				nRow++;

			final int ww = nCol * (w + this.H_GAP) + this.H_GAP;
			final int hh = nRow * (h + this.V_GAP) + this.V_GAP;
			final Insets ins = getInsets();
			return new Dimension(ww + ins.left + ins.right, hh + ins.top + ins.bottom);
		}

		@Override
		public Dimension getMaximumSize()
		{
			return getPreferredSize();
		}

		@Override
		public Dimension getMinimumSize()
		{
			return getPreferredSize();
		}

		@Override
		public void doLayout()
		{
			final Insets ins = getInsets();
			int x = ins.left + this.H_GAP;
			int y = ins.top + this.V_GAP;

			final int n = getComponentCount();
			if (n == 0)
				return;
			Component comp = getComponent(0);
			final Dimension dc = comp.getPreferredSize();
			final int w = dc.width;
			final int h = dc.height;

			final Dimension dp = getParent().getSize();
			final int nCol = Math.max((dp.width - this.H_GAP) / (w + this.H_GAP), 1);
			int nRow = n / nCol;
			if (nRow * nCol < n)
				nRow++;

			int index = 0;
			for (int k = 0; k < nRow; k++)
			{
				for (int m = 0; m < nCol; m++)
				{
					if (index >= n)
						return;
					comp = getComponent(index++);
					comp.setBounds(x, y, w, h);
					x += w + this.H_GAP;
				}
				y += h + this.V_GAP;
				x = ins.left + this.H_GAP;
			}
		}
	}

 static	class PagePreview extends JPanel
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = -7598774054674598444L;
		protected int m_w;
		protected int m_h;
		protected Image m_source;
		protected Image m_img;

		public PagePreview(int w, int h, Image source)
		{
			this.m_w = w;
			this.m_h = h;
			this.m_source = source;
			this.m_img = this.m_source.getScaledInstance(this.m_w, this.m_h, Image.SCALE_SMOOTH);
			this.m_img.flush();
			setBackground(Color.white);
			setBorder(new MatteBorder(1, 1, 2, 2, Color.black));
		}

		public void setScaledSize(int w, int h)
		{
			this.m_w = w;
			this.m_h = h;
			this.m_img = this.m_source.getScaledInstance(this.m_w, this.m_h, Image.SCALE_SMOOTH);
			repaint();
		}

		@Override
		public Dimension getPreferredSize()
		{
			final Insets ins = getInsets();
			return new Dimension(this.m_w + ins.left + ins.right, this.m_h + ins.top + ins.bottom);
		}

		@Override
		public Dimension getMaximumSize()
		{
			return getPreferredSize();
		}

		@Override
		public Dimension getMinimumSize()
		{
			return getPreferredSize();
		}

		@Override
		public void paint(Graphics g)
		{
			g.setColor(getBackground());
			g.fillRect(0, 0, getWidth(), getHeight());
			g.drawImage(this.m_img, 0, 0, this);
			paintBorder(g);
		}
	}

}
