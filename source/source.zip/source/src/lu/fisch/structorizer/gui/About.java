/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the "about" dialog window.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.29      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		I used JFormDesigner to design this window graphically.
 *
 ******************************************************************************************************/

/*
 * Created by JFormDesigner on Sat Dec 29 21:36:58 CET 2007
 */

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import lu.fisch.structorizer.elements.AbstractElement;
/**
 * 
 */
public class About extends LangDialog implements ActionListener, KeyListener {
	private static final long serialVersionUID = 1616675595892919373L;
	private final String E_THANKS = "Developped by\n - Marco Sillano <marco.sillano@gmail.com>\n\nBased on Structurizer 3.20 by\n - Robert Fisch <robert.fisch@education.lu>\n\nFile dropper class by\n - Robert W. Harder <robertharder@mac.com>\n\nAKDocLayout class by\n - Kobrix Software, Inc <http://www.kobrix.com/seco.jsp>\n\nHTMLViewer class by\n -  Stephen Halstead <http://www.cs.york.ac.uk>\n\nJStruct developped using Eclipse SDK - 3.6.2";
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JPanel pnlLeft;
	protected JPanel pnlTop;
	protected JPanel panel2;
	protected JLabel lblName;
	protected JLabel lblVersion;
	protected JLabel label2;
	protected JTabbedPane pnlTabbed;
	protected JScrollPane scrollPane1;
	protected JTextPane txtThanks;
	protected JScrollPane scrollPane2;
	protected JTextPane txtChangelog;
	protected JScrollPane scrollPane3;
	protected JTextPane txtLicense;
	protected JPanel buttonBar;
	protected JButton btnOK;

	// JFormDesigner - End of variables declaration  //GEN-END:variables
/**
 * 
 */
	public void create() {
		// set window title
		setTitle("About");
		// set layout (OS default)
		setLayout(null);
		// set windows size
		setSize(650, 400);
		// show form
		setVisible(false);
		// set action to perfom if closed
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		// set icon

		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.pnlLeft = new JPanel();
		this.pnlTop = new JPanel();
		this.panel2 = new JPanel();
		this.lblName = new JLabel();
		this.lblVersion = new JLabel();
		this.label2 = new JLabel();
		this.pnlTabbed = new JTabbedPane();
		this.scrollPane1 = new JScrollPane();
		this.txtThanks = new JTextPane();
		this.scrollPane2 = new JScrollPane();
		this.scrollPane3 = new JScrollPane();
		this.txtChangelog = new JTextPane();
		this.txtLicense = new JTextPane();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();

		this.txtChangelog.setFont(new Font("Courier", Font.PLAIN, 10));
		this.txtLicense.setFont(new Font("Courier", Font.PLAIN, 12));

		//======== this ========
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			/*
			dialogPane.setBorder(new javax.swing.border.CompoundBorder(
																	   new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
																										   "JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
																										   javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
																										   java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new BorderLayout(5, 5));

				//======== pnlLeft ========
				{
					this.pnlLeft.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.pnlLeft, BorderLayout.WEST);

				//======== pnlTop ========
				{
					this.pnlTop.setLayout(new BorderLayout());

					//======== panel2 ========
					{
						this.panel2.setLayout(new BorderLayout());

						//---- lblName ----
						this.lblName.setText("JStruct");
						this.lblName.setFont(this.lblName.getFont().deriveFont(
								this.lblName.getFont().getStyle() | Font.BOLD,
								this.lblName.getFont().getSize() + 10f));
						this.panel2.add(this.lblName, BorderLayout.NORTH);

						//---- lblVersion ----
						this.lblVersion.setText(AbstractElement.E_VERSION);
						this.panel2.add(this.lblVersion, BorderLayout.CENTER);
					}
					this.pnlTop.add(this.panel2, BorderLayout.CENTER);

					//---- label2 ----
					this.label2.setIcon(IconLoader.icoNSD48);
					this.label2.setBorder(BorderFactory.createEmptyBorder(8, 8,
							8, 8));
					this.pnlTop.add(this.label2, BorderLayout.WEST);
				}
				this.contentPanel.add(this.pnlTop, BorderLayout.NORTH);

				//======== pnlTabbed ========
				{
					//pnlTabbed.setSelectedIndex(0);
					this.pnlTabbed.setTabPlacement(SwingConstants.BOTTOM);

					//======== scrollPane1 ========
					{
						this.scrollPane1.setViewportView(this.txtThanks);
					}
					this.pnlTabbed.addTab("Implicated Persons",
							this.scrollPane1);

					//======== scrollPane2 ========
					{
						this.scrollPane2.setViewportView(this.txtChangelog);
					}
					this.pnlTabbed.addTab("Changelog", this.scrollPane2);

					//======== scrollPane3 ========
					{
						this.scrollPane3.setViewportView(this.txtLicense);
					}
					this.pnlTabbed.addTab("License", this.scrollPane3);
				}
				this.contentPanel.add(this.pnlTabbed, BorderLayout.CENTER);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout) this.buttonBar.getLayout()).columnWidths = new int[] {
						0, 80 };
				((GridBagLayout) this.buttonBar.getLayout()).columnWeights = new double[] {
						1.0, 0.0 };

				//---- okButton ----
				this.btnOK.setText("OK");
				this.btnOK.addActionListener(this);
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1,
						1, 0.0, 0.0, GridBagConstraints.CENTER,
						GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		//pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		this.btnOK.addKeyListener(this);
		this.txtThanks.addKeyListener(this);
		this.txtChangelog.addKeyListener(this);
		this.txtLicense.addKeyListener(this);
		this.pnlTabbed.addKeyListener(this);
		addKeyListener(this);

		this.txtThanks.setEditable(false);
		this.txtChangelog.setEditable(false);
		this.txtLicense.setEditable(false);

		StringBuffer buf = new StringBuffer();
		try {
			final BufferedReader in = new BufferedReader(new InputStreamReader(
					getClass().getResourceAsStream("changelog.txt"), "UTF8"));
			String str;
			while ((str = in.readLine()) != null) {
				buf.append(str + "\n");
			}
			in.close();
		} catch (final IOException e) {
			System.err.println(e.getMessage());
		}
		this.txtChangelog.setText(buf.toString());

		buf = new StringBuffer();
		try {
			final BufferedReader in = new BufferedReader(new InputStreamReader(
					getClass().getResourceAsStream("license.txt"), "UTF8"));
			String str;
			while ((str = in.readLine()) != null) {
				buf.append(str + "\n");
			}
			in.close();
		} catch (final IOException e) {
			System.err.println(e.getMessage());
		}
		this.txtLicense.setText(buf.toString());

		this.txtThanks.setText(this.E_THANKS);
		this.txtThanks.setCaretPosition(0);

		//txtChangelog.setText(AbstractElement.E_CHANGELOG);
		this.txtChangelog.setCaretPosition(0);

		this.txtLicense.setCaretPosition(0);

		this.lblVersion.setText("Version " + AbstractElement.E_VERSION);
	}

	// listen to actions
	@Override
	public void actionPerformed(ActionEvent event) {
		setVisible(false);
	}

	@Override
	public void keyTyped(KeyEvent kevt) { /* nothing */
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			setVisible(false);
		} else if (e.getKeyCode() == KeyEvent.VK_ENTER
				&& (e.isShiftDown() || e.isControlDown())) {
			setVisible(false);
		}
	}

	@Override
	public void keyReleased(KeyEvent ke) { /*nothing */
	}

	/**
	 * @param owner
	 */
	public About(Frame owner) {
		super(owner);
		setModal(true);
		create();
	}

}
