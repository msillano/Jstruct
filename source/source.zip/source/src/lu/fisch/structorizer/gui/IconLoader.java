/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class is responsible for loading all the application icons.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.28      First Issue
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.image.*;

import javax.swing.*;


/**
 *
 */
public class IconLoader {

	private static String from = "";
	// Icons
     static ImageIcon icoNSD   = new ImageIcon(getURI(from+"icons/structorizer.png"));
	 static ImageIcon icoNSD48 = new ImageIcon(getURI(from+"icons/structorizer48.png"));

	 static ImageIcon ico001 = new ImageIcon(getURI(from+"icons/001_New.png"));
	 static ImageIcon ico002 = new ImageIcon(getURI(from+"icons/002_Open.png"));
	 static ImageIcon ico003 = new ImageIcon(getURI(from+"icons/003_Save.png"));
	 static ImageIcon ico004 = new ImageIcon(getURI(from+"icons/004_Make.png"));
	 static ImageIcon ico005 = new ImageIcon(getURI(from+"icons/005_Delete.png"));
	 static ImageIcon ico006 = new ImageIcon(getURI(from+"icons/006_update.png"));
	 static ImageIcon ico007 = new ImageIcon(getURI(from+"icons/007_intBefore.png"));
	 static ImageIcon ico008 = new ImageIcon(getURI(from+"icons/008_altBefore.png"));
	 static ImageIcon ico009 = new ImageIcon(getURI(from+"icons/009_tryBefore.png"));
	 static ImageIcon ico010 = new ImageIcon(getURI(from+"icons/010_whileBefore.png"));
	 static ImageIcon ico011 = new ImageIcon(getURI(from+"icons/011_repeatBefore.png"));
	 static ImageIcon ico012 = new ImageIcon(getURI(from+"icons/012_intAfter.png"));
	 static ImageIcon ico013 = new ImageIcon(getURI(from+"icons/013_altAfter.png"));
	 static ImageIcon ico014 = new ImageIcon(getURI(from+"icons/014_tryAfter.png"));
	 static ImageIcon ico015 = new ImageIcon(getURI(from+"icons/015_whileAfter.png"));
	 static ImageIcon ico016 = new ImageIcon(getURI(from+"icons/016_repeatAfter.png"));
	 static ImageIcon ico017 = new ImageIcon(getURI(from+"icons/017_Eye.png"));
	 static ImageIcon ico018 = new ImageIcon(getURI(from+"icons/018_add.png"));
	 static ImageIcon ico019 = new ImageIcon(getURI(from+"icons/019_Up.png"));
	 static ImageIcon ico020 = new ImageIcon(getURI(from+"icons/020_Down.png"));
	 static ImageIcon ico021 = new ImageIcon(getURI(from+"icons/021_function.png"));
	 static ImageIcon ico022 = new ImageIcon(getURI(from+"icons/022_program.png"));
	 static ImageIcon ico023 = new ImageIcon(getURI(from+"icons/023_font.png"));
	// 2011.03.01 added:
//	 static ImageIcon ico025 = new ImageIcon(getURI(from+"icons/025_add_function.png"));
	 static ImageIcon ico026 = new ImageIcon(getURI(from+"icons/026_java.png"));

	 static ImageIcon ico031 = new ImageIcon(getURI(from+"icons/031_make_copy.png"));
	 static ImageIcon ico032 = new ImageIcon(getURI(from+"icons/032_make_bmp.png"));
	 static ImageIcon ico033 = new ImageIcon(getURI(from+"icons/033_font_up.png"));
	 static ImageIcon ico034 = new ImageIcon(getURI(from+"icons/034_font_down.png"));

	 static ImageIcon ico038 = new ImageIcon(getURI(from+"icons/038_redo.png"));
	 static ImageIcon ico039 = new ImageIcon(getURI(from+"icons/039_undo.png"));
	 static ImageIcon ico040 = new ImageIcon(getURI(from+"icons/040_notnice.png"));
	 static ImageIcon ico041 = new ImageIcon(getURI(from+"icons/041_print.png"));
	 static ImageIcon ico042 = new ImageIcon(getURI(from+"icons/042_copy.png"));
	 static ImageIcon ico043 = new ImageIcon(getURI(from+"icons/043_paste.png"));
	 static ImageIcon ico044 = new ImageIcon(getURI(from+"icons/044_cut.png"));
	 static ImageIcon ico045 = new ImageIcon(getURI(from+"icons/045_fr.png"));
	 static ImageIcon ico046 = new ImageIcon(getURI(from+"icons/046_uk.png"));
	 static ImageIcon ico047 = new ImageIcon(getURI(from+"icons/047_casebefore.png"));
	 static ImageIcon ico048 = new ImageIcon(getURI(from+"icons/048_caseafter.png"));
	 static ImageIcon ico049 = new ImageIcon(getURI(from+"icons/049_callbefore.png"));
	 static ImageIcon ico050 = new ImageIcon(getURI(from+"icons/050_callafter.png"));
	 static ImageIcon ico051 = new ImageIcon(getURI(from+"icons/051_nl.png"));
	 static ImageIcon ico052 = new ImageIcon(getURI(from+"icons/052_update.png"));
	// 2011.03.01 removed:
//	 static ImageIcon ico055 = new ImageIcon(getURI(from+"icons/055_jumpafter.png"));
//	 static ImageIcon ico056 = new ImageIcon(getURI(from+"icons/056_jumpbefore.png"));

	 static ImageIcon ico061 = new ImageIcon(getURI(from+"icons/061_conv_try.png"));

	 static ImageIcon ico074 = new ImageIcon(getURI(from+"icons/074_nsd.png"));
	 static ImageIcon ico075 = new ImageIcon(getURI(from+"icons/075_lu.png"));
	 static ImageIcon ico076 = new ImageIcon(getURI(from+"icons/076_latex.png"));
	 static ImageIcon ico077 = new ImageIcon(getURI(from+"icons/077_bubble.png"));
	 static ImageIcon ico078 = new ImageIcon(getURI(from+"icons/078_java.png"));
	 static ImageIcon ico079 = new ImageIcon(getURI(from+"icons/079_marker.png"));
	 static ImageIcon ico080 = new ImageIcon(getURI(from+"icons/080_de.png"));
	 static ImageIcon ico081 = new ImageIcon(getURI(from+"icons/081_pen.png"));
	 static ImageIcon ico082 = new ImageIcon(getURI(from+"icons/082_din.png"));
	 static ImageIcon ico083 = new ImageIcon(getURI(from+"icons/083_loupe.png"));
	 static ImageIcon ico084 = new ImageIcon(getURI(from+"icons/084_es.png"));
	 static ImageIcon ico085 = new ImageIcon(getURI(from+"icons/085_pt_br.png"));
	 static ImageIcon ico086 = new ImageIcon(getURI(from+"icons/086_it.png"));
	 static ImageIcon ico087 = new ImageIcon(getURI(from+"icons/087_cn.png"));
	 static ImageIcon ico088 = new ImageIcon(getURI(from+"icons/088_cz.png"));
	 static ImageIcon ico102 = new ImageIcon(getURI(from+"icons/102_help.png"));
	 static ImageIcon ico120 = new ImageIcon(getURI(from+"icons/120_cafe.png"));

   // public static ImageIcon turtle = new ImageIcon(getURI(from+"icons/turtle.png"));

	static java.net.URL getURI(String _filename)
	{
		IconLoader icol = new IconLoader();
//		System.out.println("URI = " +  icol.getClass().getResource(_filename) );
		return icol.getClass().getResource(_filename);
	}

	 static ImageIcon generateIcon(Color _color)
	{
		int size = 16;
		BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.setColor(Color.BLACK);
		graphics.fillRect(0,0,size,size);
		graphics.setColor(_color);
		graphics.fillRect(1,1,size-2,size-2);
		return new ImageIcon(image);
	}

     static void setFrom(String _from)
	{
		from=_from;
	}
}
