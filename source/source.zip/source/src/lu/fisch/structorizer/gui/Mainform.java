/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the main application form.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.11      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************///

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.io.Ini;
import lu.fisch.utils.Java3Code;

// Synchronize code with SStructorizerApplet
/**
  *
 */
public class Mainform  extends JFrame implements NSDController
{
	private static final long serialVersionUID = 7695931865878882638L;
    /** the diagram */
	public Diagram diagram = null;
	private Menu menu = null;
	private Editor editor = null;

	private String lang = "en.txt";
	private String laf = null;
	private String outCoding = "UTF-8";
   	private JOptionPane pane = null;
// added test parser  4/3/2015

	/******************************
	 * Setup the Mainform
	 ******************************/
	private void create()
	{
		Ini.getInstance();

		/*
		try {
			ClassPathHacker.addFile("JStruct.app/Contents/Resources/Java/quaqua-filechooser-only.jar");
			UIManager.setLookAndFeel(
									 "ch.randelshofer.quaqua.QuaquaLookAndFeel"
									 );
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}*/

		/******************************
		 * Load values from INI
		 ******************************/
		// spostato
		loadFromINI();

		/******************************
		 * Some JFrame specific things
		 ******************************/
		// set window title
		setTitle("JStruct");
		// set layout (OS default)
		setLayout(null);
		// set windows size
		//setSize(550, 550);
		// set action to perfom if closed
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// set icon depending on OS ;-)
		final String os = System.getProperty("os.name").toLowerCase();
//		setIconImage(IconLoader.ico074.getImage());
		if (os.indexOf("windows") != -1)
		{
			setIconImage(IconLoader.ico074.getImage());
		}
		else if (os.indexOf("mac") != -1)
		{
			setIconImage(IconLoader.icoNSD.getImage());
		}
	// show form
		setVisible(true);

		/******************************
		 * Setup the editor
		 ******************************/
		this.editor = new Editor(this);
		// get reference to the diagram
		this.diagram = getEditor().diagram;
		final Container container = getContentPane();
		this.pane =  new JOptionPane(
             "information", JOptionPane.ERROR_MESSAGE);
        this.pane.setIcon(IconLoader.ico120);

		container.setLayout(new BorderLayout());
		container.add(getEditor(),BorderLayout.CENTER);

		/******************************
		 * Setup the menu
		 ******************************/
		this.menu = new Menu(this.diagram,this);
		setJMenuBar(this.menu);

// tentative: esplicit validate to setup LookAndFeel, to evite startup error :
// thread "AWT-EventQueue-0" java.lang.NullPointerException

        container.validate();

		/******************************
		 * Update the buttons and menu
		 ******************************/
		doButtons();

		/******************************
		 * Set onClose event
		 ******************************/
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				Mainform.this.diagram.fileSaveNSD(true);
				saveToINI();
			}

			@Override
			public void windowOpened(WindowEvent e)
			{
				//editor.componentResized(null);
				//editor.revalidate();
				//repaint();
			}

			@Override
			public void windowActivated(WindowEvent e)
			{
				//editor.componentResized(null);
				//editor.revalidate();
				//repaint();
			}

			@Override
			public void windowGainedFocus(WindowEvent e)
			{
				//editor.componentResized(null);
				//editor.revalidate();
				//repaint();
			}
		});

		/******************************
		 * Load values from INI
		 ******************************/
		loadFromINI();
		setLang(this.lang);


		/******************************
		 * Resize the toolbar
		 ******************************/
		//editor.componentResized(null);
		getEditor().revalidate();
	//	repaint();
		getEditor().diagram.paintNSD();
//		repaint();

	}


	/******************************
	 * Load & save INI-file
	 ******************************/
    public void loadFromINI()
	{
//		try
		{
			final Ini ini = Ini.getInstance();
			ini.load();

			// position
			int top = Integer.valueOf(ini.getProperty("Top","0")).intValue();
			int left = Integer.valueOf(ini.getProperty("Left","0")).intValue();
			int width = Integer.valueOf(ini.getProperty("Width","750")).intValue();
			int height = Integer.valueOf(ini.getProperty("Height","550")).intValue();

			// reset to defaults if wrong values
			if (top<0) top=0;
			if (left<0) left=0;
			if (width<=0) width=750;
			if (height<=0) height=550;

			// language
			this.lang=ini.getProperty("Lang","en.txt");
			this.outCoding=ini.getProperty("Coding","UTF-8");
			// look & feel
			this.laf=ini.getProperty("laf","Mac OS X");
			setLookAndFeel(this.laf);

			// size
			setPreferredSize(new Dimension(width,height));
			setSize(width,height);
			setLocation(new Point(top,left));
			validate();

			if(this.diagram!=null)
			{
				// current directory
				this.diagram.currentDirectory = new File(ini.getProperty("currentDirectory", System.getProperty("file.separator")));
				// comments
				if (ini.getProperty("showComments","0").equals("1")) // default = 0
				{
					this.diagram.doSetComments(true);
				}
				// comments
				if (ini.getProperty("varHightlight","0").equals("1")) // default = 0
				{
					this.diagram.doSetHightlightVars(true);
				}
				if (ini.getProperty("analyser","0").equals("1")) // default = 0
				{
					this.diagram.setAnalyser(true);
				}

			}

			// recent files
//			try
			{
				if(this.diagram!=null)
				{
					for(int i=9;i>=0;i--)
					{
						if(ini.keySet().contains("recent"+i))
						{
							if(!ini.getProperty("recent"+i,"").trim().equals(""))
							{
								this.diagram.recentFileAdd(ini.getProperty("recent"+i,""),false);
							}
						}
					}
				}
			}
/*
 			catch(final Exception e)
			{
				e.printStackTrace();
				System.err.println(e.getMessage());
			}
*/
			// analyser
			RootElement.setCheck1(ini.getProperty("check1","1").equals("1"));
			RootElement.setCheck3(ini.getProperty("check3","1").equals("1"));
			RootElement.setCheck4(ini.getProperty("check4","1").equals("1"));
			RootElement.setCheck5(ini.getProperty("check5","1").equals("1"));
			RootElement.setCheck6(ini.getProperty("check6","1").equals("1"));
			RootElement.setCheck7(ini.getProperty("check7","1").equals("1"));
			RootElement.setCheck8(ini.getProperty("check8","1").equals("1"));
			RootElement.setCheck9(ini.getProperty("check9","1").equals("1"));
			RootElement.setCheck10(ini.getProperty("check10","1").equals("1"));
			RootElement.setCheck11(ini.getProperty("check11","1").equals("1"));
			RootElement.setCheck12(ini.getProperty("check12","1").equals("1"));
			RootElement.setCheck13(ini.getProperty("check13","1").equals("1"));

			doButtons();
		}
/*
		catch ( IOException e)
		{
			e.printStackTrace();
			System.err.println(e);

			setPreferredSize(new Dimension(500,500));
			setSize(500,500);
			setLocation(new Point(0,0));
			validate();
		}
*/
	}

	/**
	 *
	 */
	public void saveToINI()
	{
		try
		{
			final Ini ini = Ini.getInstance();
			ini.load();

            if (this.isVisible()){
			// position
			ini.setProperty("Top",Integer.toString(getLocationOnScreen().x));
			ini.setProperty("Left",Integer.toString(getLocationOnScreen().y));
			ini.setProperty("Width",Integer.toString(getWidth()));
			ini.setProperty("Height",Integer.toString(getHeight()));
            }
			// current directory
			if(this.diagram!=null)
			{
				if(this.diagram.currentDirectory!=null)
				{
					ini.setProperty("currentDirectory",this.diagram.currentDirectory.getAbsolutePath());
				}
			}

			// language
			ini.setProperty("Lang",this.lang);
			ini.setProperty("Coding",this.outCoding);

			ini.setProperty("showComments",(AbstractElement.isE_SHOWCOMMENTS()?"1":"0"));
			ini.setProperty("varHightlight",(AbstractElement.isE_VARHIGHLIGHT()?"1":"0"));
			ini.setProperty("analyser",(AbstractElement.isE_ANALYSER()?"1":"0"));

			// look and feel
			if(this.laf!=null)
			{
				ini.setProperty("laf", this.laf);
			}

			// recent files
			if(this.diagram!=null)
			{
				if(this.diagram.recentFiles.size()!=0)
				{
					for(int i=0;i<this.diagram.recentFiles.size();i++)
					{
						//System.out.println(i);
						ini.setProperty("recent"+String.valueOf(i), this.diagram.recentFiles.get(i));
					}
				}
			}

			ini.save();
		}
		catch (final Exception e)
		{
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
	}

	/******************************
	 * This method dispatches the
	 * command to all sublisteners
	 ******************************/
	@Override
	public void doButtons()
	{
		if(this.menu!=null)
		{
			this.menu.doButtonsLocal();
		}

		if (getEditor()!=null)
		{
			getEditor().doButtonsLocal();
		}

		doButtonsLocal();
	}

	@Override
	public String getLookAndFeel()
	{
		return this.laf;
	}

	public JOptionPane getParsePane()
	{
		return this.pane;
	}

	@Override
	public void setLookAndFeel(String _laf)
	{
		if(_laf!=null)
		{
			//System.out.println("Setting: "+_laf);
			this.laf=_laf;

			final UIManager.LookAndFeelInfo plafs[] = UIManager.getInstalledLookAndFeels();
			for(int j = 0; j < plafs.length; ++j)
			{
				//System.out.println("Listing: "+plafs[j].getName());
				if(_laf.equals(plafs[j].getName()))
				{
					//System.out.println("Found: "+plafs[j].getName());
					try
					{
						UIManager.setLookAndFeel(plafs[j].getClassName());
						SwingUtilities.updateComponentTreeUI(this);
						this.saveToINI();

					}
					catch (final Exception e)
					{
						// show error
						JOptionPane.showOptionDialog(null,e.getMessage(),
								"Error ...",
								JOptionPane.OK_OPTION,JOptionPane.ERROR_MESSAGE,null,null,null);
					}
				}
			}
		}
	}

	@Override
	public void setLang(String _langfile)
	{
		this.lang=_langfile;
		if(this.pane!=null)
		{
			this.setLangLocal(_langfile);
		}

		if(this.menu!=null)
		{
			this.menu.setLangLocal(_langfile);
		}

		if (getEditor()!=null)
		{
			getEditor().setLangLocal(_langfile);
		}
	}

	@Override
	public void setLangLocal(String _langfile) {
       LangDialog.setLang(this, getLang());
	}

	@Override
	public String getLang()
	{
		return this.lang;
	}

	@Override
	public String getOutCoding() {
		return this.outCoding;
	}


	@Override
	public void setOutCoding(String outCoding) {
		this.outCoding = outCoding;
	}


	@Override
	public void savePreferences()
	{
		AbstractElement.saveToINI();
		RootElement.saveToINI();
		Java3Code.saveToINI();
		saveToINI();
	}

	@Override
	public void pan (int x, int y){
		// only for Editor
	}

	/******************************
	 * Local listener (empty)
	 ******************************/
	@Override
	public void doButtonsLocal()
	{
		if(this.diagram!=null)
			if(this.diagram.getProgram()!=null){
				setTitle("JStruct - "+ this.diagram.getProgram().getDefaultFileName());
				return;
			    }
		setTitle("JStruct");
	}

	@Override
	public void updateColors() {
		// nothing to do
	}

	/******************************
	 * Constructor
	 ******************************/
	public Mainform()
	{
		super();
		create();
	}

	/**
	 * @return the editor
	 */
	public Editor getEditor()
	{
		return this.editor;
	}

	@Override
	public JFrame getFrame()
	{
		return this;
	}

}
