//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions:PROGRAMDOCONTOP,ADDJAVADOCPUBLIC,SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\gui\Diagram.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.SystemFlavorMap;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileFilter;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Catch;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.DetectedError;
import lu.fisch.structorizer.elements.Finally;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.generators.AbbstractGenerator;
import lu.fisch.structorizer.generators.NSDGenerator;
import lu.fisch.structorizer.io.EMFFilter;
import lu.fisch.structorizer.io.Ini;
import lu.fisch.structorizer.io.JavaFilter;
import lu.fisch.structorizer.io.PDFFilter;
import lu.fisch.structorizer.io.PNGFilter;
import lu.fisch.structorizer.io.SVGFilter;
import lu.fisch.structorizer.io.SWFFilter;
import lu.fisch.structorizer.io.StructogramFilter;
import lu.fisch.structorizer.parsers.JavaParser;
import lu.fisch.structorizer.parsers.NSDParser;
import lu.fisch.utils.BString;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;
import net.iharder.dnd.FileDrop;
import org.freehep.graphicsio.emf.EMFGraphics2D;
import org.freehep.graphicsio.pdf.PDFGraphics2D;
import org.freehep.graphicsio.svg.SVGGraphics2D;
import org.freehep.graphicsio.swf.SWFGraphics2D;
import designTools.HTMLViewer;

/**
 * Extends JPanel as specialized container for NSD diagrams.
 * <br>The <CODE>program</CODE> field is the CompilationUnit of the actual NSD tree.
 * <br> Diagram responsibilities: <ul>
 * <li> In {@link #create()} instantiates a FileDrop Class for Drop operations.
 * <li> Implements MouseListener and MouseMotionListener functions: mouseXxxx().
 * <br> Implements methods invoked when menu action occurs: doXxxx().
 * <li> Implements Java comments as pop-up dialog.
 * <li> Paint() shows the diagram and print() produces images for export or clipboard.
 *
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @version 1.02.00  build 67  (2015.03.27-20:02:46) update version java 1.8
 *@version 1.01.01  build 121  (2012.03.16-15:18:00) JStruct-aware version
 * @version  1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Diagram
extends JPanel
implements MouseMotionListener,MouseListener,Printable {

   /* class global variables */
   private static final long serialVersionUID = 1001001000L;
   private CompilationUnit program = new CompilationUnit();
   //   private TurtleBox turtle = null;
   private boolean mouseMove = false;
   private int mouseX = -1;
   private int mouseY = -1;
   private AbstractElement selectedDown = null;
   private AbstractElement selectedUp = null;
   private AbstractElement selectedMoved = null;
   private AbstractElement selected = null;
   private NSDController NSDControl = null;
   private JList<DetectedError> errorlist = null;
   private AbstractElement eCopy = null;
   public File currentDirectory = new File(System.getProperty("user.home"));
   // recently opened files
   public Vector<String> recentFiles = new Vector<String>();
   // popup for comment
   private final JLabel lblPop = new JLabel("", SwingConstants.CENTER);
   private final JPopupMenu pop = new JPopupMenu();
   // for replace
   private String oldx = "";
   private String newy = "";
   private boolean parseCapability = true;
   // toolbar management
   Vector<MyToolbar> toolbars = new Vector<MyToolbar>();

/**
 * Inner class is used to hold an image while on the clipboard.
 */
   static class EMFSelection
   implements Transferable,ClipboardOwner {

      /* class global variables */
      public static final DataFlavor emfFlavor = new DataFlavor("image/emf", "Enhanced Meta File");
      // the Image object which will be housed by the ImageSelection
      private final ByteArrayOutputStream os;
      private static DataFlavor[] supportedFlavors = {emfFlavor};

/**
 * static initializer
 */
      static {
         try {
            final SystemFlavorMap sfm = (SystemFlavorMap) SystemFlavorMap.getDefaultFlavorMap();
            sfm.addUnencodedNativeForFlavor(emfFlavor, "ENHMETAFILE");
         }
         catch (final Exception e) {
            System.err.println(e.getMessage());
         }
      }

/**
 * constructor
 * @param os ByteArrayOutputStream
 */
      EMFSelection(ByteArrayOutputStream os) {
         this.os = os;
      }

// Returns Image object housed by Transferable object
      @Override()
      public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
         if(flavor.equals(emfFlavor)) {
            return new ByteArrayInputStream(this.os.toByteArray());
         }
         throw new UnsupportedFlavorException(flavor);
      }

// Returns the supported flavors of our implementation
      @Override()
      public DataFlavor[] getTransferDataFlavors() {
         return supportedFlavors;
      }

// Returns true if flavor is supported
      @Override()
      public boolean isDataFlavorSupported(DataFlavor flavor) {
         for(final DataFlavor f : supportedFlavors) {
            if(f.equals(flavor)) {
               return true;
            }
         }
         return false;
      }

      @Override()
      public void lostOwnership(Clipboard arg0, Transferable arg1) {
         //   nothing to do
      }

   }

/**
 * Inner class is used to hold an image while on the clipboard.
 */
   static class ImageSelection
   implements Transferable {

      /* class global variables */
      // the Image object which will be housed by the ImageSelection
      private final Image image;

/**
 * The constructor ImageSelection
 * @param image Image
 */
      ImageSelection(Image image) {
         this.image = image;
      }

// Returns Image object housed by Transferable object
      @Override()
      public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
         if(!DataFlavor.imageFlavor.equals(flavor)) {
            throw new UnsupportedFlavorException(flavor);
         }
// else return the payload
         return this.image;
      }

// Returns the supported flavors of our implementation
      @Override()
      public DataFlavor[] getTransferDataFlavors() {
         return new DataFlavor[] { DataFlavor.imageFlavor };
      }

// Returns true if flavor is supported
      @Override()
      public boolean isDataFlavorSupported(DataFlavor flavor) {
         return DataFlavor.imageFlavor.equals(flavor);
      }

   }

/**
 * Constructor
 * @param _editor NSDControl
 */
   Diagram(Editor _editor) {
      super(true);
//      setDoubleBuffered(false); // we don't need double buffering,
      if(_editor != null) {
         this.errorlist = _editor.errorlist;
         this.NSDControl = _editor;
      }
      create();
   }

/**
 * added 4/3/2015
 *getter for parseCapability
 * @return boolean
 */
   public boolean getParseCapability() {
      return parseCapability;
   }

/**
 *setter for parseCapability
 * @param capable boolean
 */
   public void setParseCapability(boolean capable) {
      parseCapability = capable;
   }

/**
 * The method doOpenNSD reads a nsd file and shows the diagram.
 * @param _filename String
 */
   public void doOpenNSD(String _filename) {
      try {
         final File f = new File(_filename);
//debug  System.out.println(f.toURI().toString());
         if(f.exists() == true) {
// only save if something has been changed
            fileSaveNSD(true);
// open an existing file
            final NSDParser parser = new NSDParser();
            final boolean hil = AbstractElement.isE_VARHIGHLIGHT();
            this.program = parser.parse(f.toURI().toString());
            AbstractElement.setE_VARHIGHLIGHT(hil);
            this.program.setFilename(_filename);
            this.currentDirectory = new File(_filename);
            recentFileAdd(_filename);
            paintNSD();
            analyse();
         }
      }
      catch (final Exception e) {
         System.err.println(e.getMessage());
      }
   }

/**
 * The method fileImportJAVA opens a java file and shows the diagram.
 * @param filename String
 */
   public void fileImportJAVA(String filename) {
// 4/3/2015
// only save if something has been changed
      if(getParseCapability()) {
         fileSaveNSD(true);
         final JavaParser jParser = new JavaParser();
         final CompilationUnit module = jParser.parse(filename, this.NSDControl.getOutCoding());
         final boolean HV = AbstractElement.isE_VARHIGHLIGHT();
         this.program = module;
         AbstractElement.setE_VARHIGHLIGHT(HV);
         this.program.setChangedNow(false);
         paintNSD();
         analyse();
      }
      else {
         doNewNSD();
      }
   }

/**
 * The method getRoot gets the root element (Class or Method or Program) for ele
 * @param ele AbstractElement
 * @return RootElement or program
 */
   public RootElement getRoot(AbstractElement ele) {
      if(ele != null) {
         final AbstractElement root = ele.getRoot();
         if(root != null) {
            return(RootElement) root;
         }
      }
      return this.program;
   }

/**
 * Mouse management
 *
 *Mouse pressed SX/DX: select
 *
 *Mouse double SX: Expand/Edit
 *Mouse dx: context menu
 * 01/03/2015  rewrited, creating mouseActionXxxxxxx()  methods
 * TODO test it in linux, macOS
 * @param e MouseEvent
 */
   public void mouseActionSelectElement(MouseEvent e) {
// in case of aborted drag
      this.mouseMove = false;
      this.selectedDown = null;
      AbstractElement.setE_DRAWCOLOR(Color.YELLOW);
// click/press on program: set selected and repaint
      final AbstractElement ele = this.program.selectElementByCoord(e.getX(), e.getY(), true);
      if(this.selected != ele) {
         if(ele == null) {
            this.selected = this.program;
         }
         else {
            this.selected = ele;
         }
         this.selected.setSelected(true);
         if(this.selectedDown != ele) {
            paintNSD();
         }
         if(this.NSDControl != null) {
            this.NSDControl.doButtons();
         }
      }
// fort start drag (if any)
// not draggable elements
      if(this.selected.getClass().getSimpleName().equals("Subqueue") || this.selected.getClass().getSimpleName().equals("Root") || this.selected.getClass().getSimpleName().equals("CompilationUnit") || this.selected.getClass().getSimpleName().equals("Catch") || this.selected.getClass().getSimpleName().equals("Finally")) {
// == not draggable
         this.selectedDown = null;
      }
      else {
         this.selectedDown = ele;
      }
      this.mouseX = e.getX();
      this.mouseY = e.getY();
// not moved
      this.mouseMove = false;
   }

/**
 * ============================== mouse processing
 */
   private void mouseActionSelectErrorMessage(MouseEvent e) {
// click/press on error pane: goto relate element, select it and repaint
      if(this.errorlist.getSelectedIndex() != - 1) {
         final AbstractElement ele = this.program.getErrors().get(this.errorlist.getSelectedIndex()).getElement();
         if(ele != null) {
            if(this.selected != null) {
               this.selected.setSelected(false);
            }
            this.selected = ele;
            ele.setSelected(true);
            doOpenSelected();
            doGotoSelected();
            if(this.NSDControl != null) {
               this.NSDControl.doButtons();
            }
         }
      }
   }

   private void mouseAction2ClickElement(MouseEvent e) {
      final AbstractElement ele = this.program.selectElementByCoord(e.getX(), e.getY(), true);
      if(ele == null) {
         return;
      }
// expands if closed
      if(ele instanceof RootElement && ((RootElement) ele).isClosed()) {
         this.selected = ele;
         ((RootElement) ele).setClosed(false);
         paintNSD();
         return;
      }
// edit CompilationUnit
      if(ele instanceof CompilationUnit) {
         this.selected = ele;
         doEditNSD();
         this.program.setChangedNow(true);
         if(this.NSDControl != null) {
            this.NSDControl.doButtons();
         }
         return;
      }
// edit element
      if(!(ele.getParent() instanceof JClass)) {
         this.selected = ele;
         doEditNSD();
         getRootSelected().setChangedNow(true);
         this.program.setChangedNow(true);
         if(this.NSDControl != null) {
            this.NSDControl.doButtons();
         }
         return;
      }
   }

   private void mouseAction2ClickErrorMessage(MouseEvent e) {
// edit element from error list
      if(this.errorlist.getSelectedIndex() != - 1) {
         final AbstractElement elee = this.program.getErrors().get(this.errorlist.getSelectedIndex()).getElement();
         if(elee != null) {
            if(this.selected != null) {
               this.selected.setSelected(false);
            }
            this.selected = elee;
            elee.setSelected(true);
            doEditNSD();
            if(this.NSDControl != null) {
               this.NSDControl.doButtons();
            }
         }
      }
   }

   private void mouseActionDragElement(MouseEvent e) {
      if(this.selectedDown != null) {
         final AbstractElement ele = this.program.selectElementByCoord(e.getX(), e.getY(), true);
         if((ele != null) && !(ele instanceof CompilationUnit)) {
            ele.setSelected(true);
            this.selectedDown.setSelected(true);
            if(e.getX() != this.mouseX && e.getY() != this.mouseY && this.selectedMoved != ele) {
               this.mouseMove = true;
               if((ele instanceof CompilationUnit && !(this.selectedDown instanceof RootElement)) || ele.getRoot().checkChild(ele, this.selectedDown) || (this.selectedDown instanceof JClass && ele instanceof JClass) || ele instanceof Catch || ele instanceof Finally) {
                  AbstractElement.setE_DRAWCOLOR(Color.RED);
               }
               else {
                  AbstractElement.setE_DRAWCOLOR(Color.GREEN);
               }
               paintNSD();
            }
            this.selectedMoved = ele;
         }
      }
   }

   private void mouseActionEndDrag(MouseEvent e) {
      boolean doDraw = false;
// any move?
      if(this.mouseMove == true && this.selectedDown != null) {
         AbstractElement selectedUp = this.program.selectElementByCoord(e.getX(), e.getY(), true);
         if(selectedUp != null) {
            selectedUp.setSelected(false);
            if((selectedUp != this.selectedDown) && !selectedUp.getClass().getSimpleName().equals("CompilationUnit") && (AbstractElement.getE_DRAWCOLOR() == Color.GREEN)) {
// cut-paste
               this.selectedDown.getRoot().addUndo();
               this.selectedDown.getRoot().removeElement(this.selectedDown);
               selectedUp.getRoot().addAfter(selectedUp, this.selectedDown);
            }
         }
         this.selectedDown.setSelected(true);
         doDraw = true;
      }
      if(doDraw == true) {
         paintNSD();
         analyse();
         if(this.NSDControl != null) {
            this.NSDControl.doButtons();
         }
      }
   }

// placed in the listener  6/3/2015
//    this.mouseMove = false;
//    this.selectedDown = null;
//    AbstractElement.setE_DRAWCOLOR(Color.YELLOW);
// ===================== mouse MouseMotionListener, MouseListener
   @Override()
   public void mousePressed(MouseEvent e) {
      if((e.getClickCount() < 2) && (e.getSource() == this)) {
         mouseActionSelectElement(e);
         return;
      }
   }

   @Override()
   public void mouseReleased(MouseEvent e) {
      if(this.mouseMove == true && this.selectedDown != null && e.getSource() == this) {
         mouseActionEndDrag(e);
      }
// set 'no moved'
      this.mouseMove = false;
// none dragging
      this.selectedDown = null;
// standard select color
      AbstractElement.setE_DRAWCOLOR(Color.YELLOW);
   }

   @Override()
   public void mouseClicked(MouseEvent e) {
      if((e.getClickCount() < 2) && (e.getSource() != this)) {
//1 click on ERROR message list: show related element
         mouseActionSelectErrorMessage(e);
         return;
      }
      if((e.getClickCount() > 1) && (e.getSource() == this)) {
//2 click on Element: open or edit
         mouseAction2ClickElement(e);
         return;
      }
      if((e.getClickCount() > 1) && (e.getSource() != this)) {
//2 click on ERROR message list: show related element and edit
         mouseAction2ClickErrorMessage(e);
         return;
      }
   }

   @Override()
   public void mouseDragged(MouseEvent e) {
      if(e.getSource() == this) {
//drag action redraw
         mouseActionDragElement(e);
         return;
      }
   }

   @Override()
   public void mouseEntered(MouseEvent e) {
      //   nothing to do
   }

   @Override()
   public void mouseExited(MouseEvent e) {
      //   nothing to do
   }

   @Override()
   public void mouseMoved(MouseEvent e) {
      if(e.getSource() == this && this.NSDControl != null) {
         if(AbstractElement.isE_SHOWCOMMENTS() == true && ((Editor) this.NSDControl).popup.isVisible() == false) {
            final AbstractElement selEle = this.program.selectElementByCoord(e.getX(), e.getY(), false);
            if(selEle != null) {
               if(!selEle.getComment().getText().trim().equals("")) {
                  if(!this.lblPop.getText().equals("<html>" + BString.replace(BString.encodeToHtml(selEle.getComment().getText()), "\n", "<br>") + "</html>")) {
                     this.lblPop.setText("<html>" + BString.replace(BString.encodeToHtml(selEle.getComment().getText()), "\n", "<br>") + "</html>");
                  }
                  int maxWidth = 0;
                  int si = 0;
                  for(int i = 0; i < selEle.getComment().count(); i++) {
                     if(maxWidth < selEle.getComment().get(i).length()) {
                        maxWidth = selEle.getComment().get(i).length();
                        si = i;
                     }
                  }
                  this.lblPop.setPreferredSize(new Dimension(16 + this.lblPop.getFontMetrics(this.lblPop.getFont()).stringWidth(selEle.getComment().get(si)), commentsNumLines(this.lblPop.getText()) * getFontMetrics(this.lblPop.getFont()).getHeight()));
                  final int x = ((JComponent) e.getSource()).getLocationOnScreen().getLocation().x;
                  final int y = ((JComponent) e.getSource()).getLocationOnScreen().getLocation().y;
                  this.pop.setLocation(x + e.getX(), y + e.getY() + 16);
                  this.pop.setVisible(true);
               }
               else {
                  this.pop.setVisible(false);
               }
            }
            else {
               this.pop.setVisible(false);
            }
         }
         else {
            this.pop.setVisible(false);
         }
      }
   }

   @Override()
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      if(this.program.getSize() > 0) {
         paintNSD(g);
      }
   }

// ==========================================================  paint
   @Override()
   public int print(Graphics g, PageFormat pageFormat, int page) {
      if(page == 0) {
         final Graphics2D g2d = (Graphics2D) g;
         g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
         final double sX = (pageFormat.getImageableWidth() - 1) / this.program.getWidth();
         final double sY = (pageFormat.getImageableHeight() - 1) / this.program.getHeight();
         double sca = Math.min(sX, sY);
         if(sca > 1) {
            sca = 1;
         }
         g2d.scale(sca, sca);
         this.program.progDraw(g);
         return PAGE_EXISTS;
      }
      return NO_SUCH_PAGE;
   }

/**
 * lines in a HTLM formatted String
 * @param txt String
 * @return int
 */
   private int commentsNumLines(String txt) {
      if(txt.equals("")) {
         return 0;
      }
      int n = 1;
      int i = - 2;
      do {
         i += 2;
         i = txt.indexOf("<br", i);
         n++;
      }
      while(i > 0);
      return n;
   }

/**
 * The method create, builds all
 */
   @SuppressWarnings("unused")
   private void create() {
      AbstractElement.loadFromINI();
      RootElement.loadFromINI();
      Java3Code.loadFromINI();
//debug   System.out.println("add mouse listener");
      addMouseListener(this);
      addMouseMotionListener(this);
// file drop anonymous class creation: adds drop functionality
      new FileDrop(this, new FileDrop.Listener() {
         @Override()
         public void filesDropped(java.io.File[] files) { final boolean found = false;
         for(final File file : files) {
            final String filename = file.toString();
            if(filename.substring(filename.length() - 4, filename.length()).toLowerCase().equals(".nsd")) {
               doOpenNSD(filename);
               }
            else if(filename.substring(filename.length() - 5, filename.length()).toLowerCase().equals(".java")) {
               fileImportJAVA(filename); }
            }
         }
      });
// popup for comment
      final JPanel jp = new JPanel();
      jp.setOpaque(true);
      this.lblPop.setPreferredSize(new Dimension(30, 12));
      jp.add(this.lblPop);
      this.pop.add(jp);
   }

/**
 * The method fileExportChooser
 * @param title String
 * @param ext String
 * @param filter FileFilter
 * @return File
 */
   private File fileExportChooser(String title, String ext, FileFilter filter) {
      final JFileChooser dlgSave = new JFileChooser(title);
// set directory
      if(this.program.getFile() != null) {
         dlgSave.setCurrentDirectory(this.program.getFile());
      }
      else {
         dlgSave.setCurrentDirectory(this.currentDirectory);
      }
      final String nsdName = this.program.getDefaultFileName();
      dlgSave.setSelectedFile(new File(nsdName));
      dlgSave.addChoosableFileFilter(filter);
      final int result = dlgSave.showSaveDialog(this.NSDControl.getFrame());
      if(result == JFileChooser.APPROVE_OPTION) {
         String filename = dlgSave.getSelectedFile().getAbsoluteFile().toString();
         if(!filename.substring(filename.length() - 4, filename.length()).toLowerCase().equals(ext)) {
            filename += ext;
         }
         final File file = new File(filename);
         if(file.exists()) {
            final int response = JOptionPane.showConfirmDialog(null, "Overwrite existing file?", "Confirm Overwrite", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(response == JOptionPane.NO_OPTION) {
               return null;
            }
         }
         return file;
      }
      return null;
   }

/**
 * The method fileNameCheck
 * @param filter FileFilter
 * @param ext String
 * @return boolean
 */
   private boolean fileNameCheck(FileFilter filter, String ext) {
      boolean saveIt = true;
      if(this.program.getFilename().equals("")) {
         final JFileChooser dlgSave = new JFileChooser();
         dlgSave.setDialogTitle("Save file...");
// set directory
         if(this.program.getFile() != null) {
            dlgSave.setCurrentDirectory(this.program.getFile());
         }
         else {
            dlgSave.setCurrentDirectory(this.currentDirectory);
         }
// proposed name
         final String nsdName = this.program.getDefaultFileName();
         dlgSave.setSelectedFile(new File(nsdName));
         dlgSave.addChoosableFileFilter(filter);
         final int result = dlgSave.showSaveDialog(this);
         if(result == JFileChooser.APPROVE_OPTION) {
            this.program.setFilename(dlgSave.getSelectedFile().getAbsoluteFile().toString());
         }
         else {
            saveIt = false;
         }
      }
      int p = this.program.getFilename().lastIndexOf(".");
      if(p == - 1) {
         p = this.program.getFilename().length();
      }
      this.program.setFilename(this.program.getFilename().substring(0, p) + ext);
      return saveIt;
   }

/**
 * The method paintNSD
 * @param _g Graphics
 */
   private void paintNSD(Graphics _g) {
      final Canvas canvas = new Canvas((Graphics2D) _g);
      Rect rect;
      rect = new Rect(0, 0, getWidth(), getHeight());
      canvas.setColor(Color.LIGHT_GRAY);
      canvas.fillRect(rect);
      if(this.program.getSize() > 0) {
         this.program.progDraw(_g);
      }
      setPreferredSize(new Dimension(this.program.getWidth(), this.program.getHeight()));
      validate();
   }

/**
 * ANALYSER
 */
   protected void analyse() {
      if(AbstractElement.isE_ANALYSER() == true && this.errorlist != null) {
         final Vector < DetectedError > vec = this.program.analyze();
         final DefaultListModel < DetectedError > errors = (DefaultListModel < DetectedError >) this.errorlist.getModel();
         errors.clear();
         for(int i = 0; i < vec.size(); i++) {
            errors.addElement(vec.get(i));
         }
         this.errorlist.repaint();
         this.errorlist.validate();
      }
   }

/**
 * The method doAbout for about popup.
 */
   void doAbout() {
      final About about = new About(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      about.setLocation(p.x + (getVisibleRect().width - about.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - about.getHeight()) / 2 + getVisibleRect().y);
      about.setLang(this.NSDControl.getLang());
      about.setVisible(true);
   }

   HTMLViewer doHelpJS() {
      String lang = this.NSDControl.getLang();
      lang = lang.substring(0, lang.indexOf('.'));
      String filename = "../help/help_" + lang + ".html";
      final URL mySource = Ini.class.getProtectionDomain().getCodeSource().getLocation();
      String dirname = mySource.getPath();
// using jar
      if(dirname.contains(Ini.jarname)) {
         dirname = dirname.substring(0, dirname.indexOf(Ini.jarname));
      }
      URL url = null;
      try {
// added 08/04/2015 for development and final help place.
         File f = new File(dirname + filename);
         if ( !f.exists()){
             filename = "help/help_" + lang + ".html";
         }
      url = new URL("file://" + dirname + filename);
      }
      catch (MalformedURLException e) {
// TODO Auto-generated catch block
         e.printStackTrace();
      }
//debug System.out.print("Help "+ filename + " URL: " + url);
      return new HTMLViewer(url, "JSruct help");
   }

/**
 * The method doAddNewElement
 * @param _ele AbstractElement
 * @param _title String
 * @param _pre String
 * @param _after boolean
 */
   void doAddNewElement(AbstractElement _ele, String _title, String _pre, boolean _after) {
      if(getSelected() != null) {
         final EditData data = new EditData();
         data.title = _title;
         data.text.setText(_pre);
         showInputBox(data);
         if(data.result == true) {
            if(!(_ele instanceof Try || _ele instanceof Finally)) {
               _ele.setCode(data.text.getText());
            }
            _ele.setComment(data.comment.getText());
            final RootElement base = getSelected().getRoot();
            base.addUndo();
            if(_after == true) {
               base.addAfter(getSelected(), _ele);
            }
            else {
               base.addBefore(getSelected(), _ele);
            }
            _ele.setSelected(true);
            this.selected = _ele;
            if(getSelected().getParentElement() instanceof JClass) {
               _ele.setColor(base.getColor());
            }
            getRootSelected().setChangedNow(true);
            this.program.setChangedNow(true);
            paintNSD();
            analyse();
         }
      }
   }

/**
 * The method doAnalyserOptions
 */
   void doAnalyserOptions() {
      final AnalyserPreferences analyserPreferences = new AnalyserPreferences(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      analyserPreferences.setLocation(p.x + (getVisibleRect().width - analyserPreferences.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - analyserPreferences.getHeight()) / 2 + getVisibleRect().y);
// set fields
//      analyserPreferences.check1.setSelected(JMethod.check1);
//      analyserPreferences.check2.setSelected(JMethod.check2);
      analyserPreferences.check3.setSelected(RootElement.check3);
      analyserPreferences.check4.setSelected(RootElement.check4);
      analyserPreferences.check5.setSelected(RootElement.check5);
      analyserPreferences.check6.setSelected(RootElement.check6);
      analyserPreferences.check7.setSelected(RootElement.check7);
      analyserPreferences.check8.setSelected(RootElement.check8);
//      analyserPreferences.check9.setSelected(JMethod.check9);
      analyserPreferences.check10.setSelected(RootElement.check10);
      analyserPreferences.check11.setSelected(RootElement.check11);
      analyserPreferences.check12.setSelected(RootElement.check12);
      analyserPreferences.check13.setSelected(RootElement.check13);
      analyserPreferences.setLang(this.NSDControl.getLang());
      analyserPreferences.pack();
      analyserPreferences.setVisible(true);
// get fields
//      JMethod.check1 = analyserPreferences.check1.isSelected();
//      JMethod.check2 = analyserPreferences.check2.isSelected();
      RootElement.check3 = analyserPreferences.check3.isSelected();
      RootElement.check4 = analyserPreferences.check4.isSelected();
      RootElement.check5 = analyserPreferences.check5.isSelected();
      RootElement.check6 = analyserPreferences.check6.isSelected();
      RootElement.check7 = analyserPreferences.check7.isSelected();
      RootElement.check8 = analyserPreferences.check8.isSelected();
//      JMethod.check9 = analyserPreferences.check9.isSelected();
      RootElement.check10 = analyserPreferences.check10.isSelected();
      RootElement.check11 = analyserPreferences.check11.isSelected();
      RootElement.check12 = analyserPreferences.check12.isSelected();
      RootElement.check13 = analyserPreferences.check13.isSelected();
      analyse();
   }

/**
 * The method doCopyNSD
 */
   void doCopyNSD() {
      if(this.selected != null) {
         if(!(this.selected instanceof Catch || this.selected instanceof Finally)) {
            this.eCopy = this.selected.copy();
         }
      }
   }

/**
 * The method doCopyToClipboardEMF
 */
   void doCopyToClipboardEMF(boolean partial) {
      final Clipboard systemClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      try {
         final ByteArrayOutputStream myEMF = new ByteArrayOutputStream();
         RootElement target;
         if(!partial) {
            target = this.program;
         }
         else {
            if(this.getSelected() instanceof RootElement) {
               target = (RootElement) this.getSelected();
            }
            else {
               target = this.getSelected().getRoot();
            }
         }
         final EMFGraphics2D emf = new EMFGraphics2D(myEMF, new Dimension(target.getWidth() + 5, target.getHeight() + 2));
         emf.setFont(AbstractElement.getFont());
         emf.startExport();
         final lu.fisch.graphics.Canvas c = new lu.fisch.graphics.Canvas(emf);
         final lu.fisch.graphics.Rect myrect = target.prepareDraw(c);
         target.draw(c, myrect);
         emf.endExport();
         systemClipboard.setContents(new EMFSelection(myEMF), null);
      }
      catch (final Exception e) {
         e.printStackTrace();
      }
   }

/**
 * The method doCopyToClipboardPNG
 */
   void doCopyToClipboardPNG(boolean partial) {
      final Clipboard systemClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
// get diagram
      RootElement target;
      if(!partial) {
         target = this.program;
      }
      else {
         if(this.getSelected() instanceof RootElement) {
            target = (RootElement) this.getSelected();
         }
         else {
            target = this.getSelected().getRoot();
         }
      }
      final BufferedImage image = new BufferedImage(target.getWidth() + 1, target.getHeight() + 1, BufferedImage.TYPE_INT_ARGB);
      final Canvas canvas = new Canvas((Graphics2D) image.getGraphics());
// not works:        canvas.setBackground(Color.white);
      canvas.setFont(AbstractElement.getFont());
      final Rect myrec = target.prepareDraw(canvas);
      target.draw(canvas, myrec);
// put image to clipboard
      final ImageSelection imageSelection = new ImageSelection(image);
      systemClipboard.setContents(imageSelection, null);
   }

/**
 * The method doCutNSD
 */
   void doCutNSD() {
      if(this.selected != null) {
         if(!(this.selected instanceof Catch || this.selected instanceof Finally)) {
            this.eCopy = this.selected.copy();
            this.eCopy.setSelected(false);
            getRootSelected().addUndo();
            getRootSelected().removeElement(this.selected);
            getRootSelected().setChangedNow(true);
            this.program.setChangedNow(true);
            paintNSD();
            this.selected = null;
            analyse();
         }
      }
   }

/**
 * The method doDeleteNSD
 */
   void doDeleteNSD() {
      getRootSelected().addUndo();
      if(getSelected().getParent() == this.program) {
         this.program.removeElement(getSelected());
      }
      else {
         getSelected().getMySubqueue().removeElement(getSelected());
      }
      this.program.setChangedNow(true);
      paintNSD();
      analyse();
   }

/**
 * The method doEditNSD
 */
   void doEditNSD() {
      final AbstractElement abstractElement = getSelected();
      if(abstractElement != null) {
         if(abstractElement.getClass().getSimpleName().equals("Subqueue")) {
            final EditData data = new EditData();
            data.title = "Edit " + abstractElement.getName();
            showInputBox(data);
            if(data.result == true) {
               final AbstractElement ele = new Instruction(data.text.getText());
               ele.setComment(data.comment.getText());
               getRootSelected().addUndo();
               getRootSelected().setChangedNow(true);
               ((Subqueue) abstractElement).addElement(ele);
               ele.setSelected(true);
               this.program.setChangedNow(true);
               setSelected(ele);
               paintNSD();
            }
         }
         else {
            final EditData data = new EditData();
            data.title = "Edit " + abstractElement.getName();
            data.text.setText(abstractElement.getCode().getText());
            data.comment.setText(abstractElement.getComment().getText());
            showInputBox(data);
            if(data.result == true) {
               getRootSelected().addUndo();
               if(!(abstractElement instanceof Finally)) {
                  abstractElement.setCode(StringList.explode(data.text.getText(), "\n"));
               }
               abstractElement.setComment(data.comment.getText());
               getRootSelected().setChangedNow(true);
               this.program.setChangedNow(true);
               paintNSD();
            }
         }
         analyse();
      }
      else {
         final EditData data = new EditData();
         data.title = "Edit program data";
         data.text.setText(this.program.getCode().getText());
         if(this.program.getComment().count() == 0) {
            data.comment.setText("@file " + this.program.getPath());
         }
         else {
            data.comment.setText(this.program.getComment().getText());
         }
         showInputBox(data);
         if(data.result == true) {
            this.program.setCode(data.text.getText());
            this.program.setComment(data.comment.getText());
            this.program.setChangedNow(true);
         }
      }
   }

/**
 * The method doExportCode
 * @param _generatorClassName String
 */
   void doExportCode(String _generatorClassName) {
      try {
         @SuppressWarnings("unchecked")
         final Class < AbbstractGenerator > genClass = (Class < AbbstractGenerator >) Class.forName(_generatorClassName);
         final AbbstractGenerator gen = genClass.newInstance();
         gen.exportCode(this.program, this.currentDirectory, this.NSDControl.getFrame(), this.NSDControl.getOutCoding());
      }
      catch (final Exception e) {
         JOptionPane.showOptionDialog(this, "Error while using generator " + _generatorClassName + "\n" + e.getMessage(), "Error", JOptionPane.OK_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);
      }
   }

/**
 * The method doExportEMF
 */
   void doExportEMF() {
      this.program.selectElementByCoord(- 1, - 1, true);
      paintNSD();
      final File exportFile = fileExportChooser("Export diagram as EMF...", ".emf", new EMFFilter());
      if(exportFile == null) {
         return;
      }
      try {
         final EMFGraphics2D emf = new EMFGraphics2D(new FileOutputStream(exportFile), new Dimension(this.program.getWidth() + 12, this.program.getHeight() + 12));
         emf.startExport();
         final lu.fisch.graphics.Canvas c = new lu.fisch.graphics.Canvas(emf);
         final lu.fisch.graphics.Rect myrect = this.program.prepareDraw(c);
         myrect.left += 6;
         myrect.top += 6;
         this.program.draw(c, myrect);
         emf.endExport();
      }
      catch (final Exception e) {
         e.printStackTrace();
      }
   }

/**
 * The method doExportPDF
 */
   void doExportPDF() {
      this.program.selectElementByCoord(- 1, - 1, true);
      paintNSD();
      final File exportFile = fileExportChooser("Export diagram as PDF...", ".pdf", new PDFFilter());
      if(exportFile == null) {
         return;
      }
      try {
         final PDFGraphics2D svg = new PDFGraphics2D(new FileOutputStream(exportFile), new Dimension(this.program.getWidth() + 12, this.program.getHeight() + 12));
         svg.startExport();
         final lu.fisch.graphics.Canvas c = new lu.fisch.graphics.Canvas(svg);
         final lu.fisch.graphics.Rect myrect = this.program.prepareDraw(c);
         myrect.left += 6;
         myrect.top += 6;
         this.program.draw(c, myrect);
         svg.endExport();
      }
      catch (final Exception e) {
         e.printStackTrace();
      }
   }

/**
 * The method doExportPNG
 */
   void doExportPNG() {
      this.program.selectElementByCoord(- 1, - 1, true);
      paintNSD();
      final File exportFile = fileExportChooser("Export diagram as PNG...", ".png", new PNGFilter());
      if(exportFile == null) {
         return;
      }
      final BufferedImage bi = new BufferedImage(this.program.getWidth() + 1, this.program.getHeight() + 1, BufferedImage.TYPE_4BYTE_ABGR);
      printAll(bi.getGraphics());
      try {
         ImageIO.write(bi, "png", exportFile);
      }
      catch (final Exception e) {
         JOptionPane.showOptionDialog(this, "Error while saving the image!", "Error", JOptionPane.OK_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);
      }
   }

/**
 * The method doExportSVG
 */
   void doExportSVG() {
      this.program.selectElementByCoord(- 1, - 1, true);
      paintNSD();
      final File exportFile = fileExportChooser("Export diagram as SVG...", ".svg", new SVGFilter());
      if(exportFile == null) {
         return;
      }
      try {
         final SVGGraphics2D svg = new SVGGraphics2D(new FileOutputStream(exportFile), new Dimension(this.program.getWidth() + 12, this.program.getHeight() + 12));
         svg.startExport();
         final lu.fisch.graphics.Canvas c = new lu.fisch.graphics.Canvas(svg);
         final lu.fisch.graphics.Rect myrect = this.program.prepareDraw(c);
         myrect.left += 6;
         myrect.top += 6;
         this.program.draw(c, myrect);
         svg.endExport();
      }
      catch (final Exception e) {
         e.printStackTrace();
      }
   }

/**
 * The method doExportSWF
 */
   void doExportSWF() {
      this.program.selectElementByCoord(- 1, - 1, true);
      paintNSD();
      final File exportFile = fileExportChooser("Export diagram as SWF...", ".swf", new SWFFilter());
      if(exportFile == null) {
         return;
      }
      try {
         final SWFGraphics2D svg = new SWFGraphics2D(new FileOutputStream(exportFile), new Dimension(this.program.getWidth() + 12, this.program.getHeight() + 12));
         svg.startExport();
         final lu.fisch.graphics.Canvas c = new lu.fisch.graphics.Canvas(svg);
         final lu.fisch.graphics.Rect myrect = this.program.prepareDraw(c);
         myrect.left += 6;
         myrect.top += 6;
         this.program.draw(c, myrect);
         svg.endExport();
      }
      catch (final Exception e) {
         e.printStackTrace();
      }
   }

/**
 * The method doFontDown
 */
   void doFontDown() {
      if(AbstractElement.getFont().getSize() - 2 >= 4) {
// change font size
         AbstractElement.setFont(new Font(AbstractElement.getFont().getFamily(), Font.PLAIN, AbstractElement.getFont().getSize() - 2));
// redraw diagram
         paintNSD();
      }
   }

/**
 * The method doFontOptions
 */
   void doFontOptions() {
      final FontChooser fontChooser = new FontChooser(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      fontChooser.setLocation(p.x + (getVisibleRect().width - fontChooser.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - fontChooser.getHeight()) / 2 + getVisibleRect().y);
// set fields
      fontChooser.setFont(AbstractElement.getFont());
      fontChooser.setLang(this.NSDControl.getLang());
      fontChooser.setVisible(true);
// get fields
      AbstractElement.setFont(fontChooser.getCurrentFont());
// redraw diagram
      paintNSD();
   }

/**
 * The method doFontUp
 */
   void doFontUp() {
// change font size
      AbstractElement.setFont(new Font(AbstractElement.getFont().getFamily(), Font.PLAIN, AbstractElement.getFont().getSize() + 2));
// redraw diagram
      paintNSD();
   }

/**
 * The method doGotoSelected
 */
   void doGotoSelected() {
      if(this.selected != null && this.NSDControl != null) {
         this.NSDControl.pan(this.selected.getRect().left - 60, this.selected.getRect().top - 60);
         paintNSD();
      }
   }

/**
 * The method doImportJAVA
 */
   void doImportJAVA() {
      String filename = "";
      final JFileChooser dlgOpen = new JFileChooser();
      dlgOpen.setDialogTitle("Import Java Code...");
// set directory
      if(this.program.getFile() != null) {
         dlgOpen.setCurrentDirectory(this.program.getFile());
      }
      else {
         dlgOpen.setCurrentDirectory(this.currentDirectory);
      }
      dlgOpen.addChoosableFileFilter(new JavaFilter());
// ADDED 4/3/2015
      dlgOpen.setAcceptAllFileFilterUsed(false);
      final int result = dlgOpen.showOpenDialog(this.NSDControl.getFrame());
      if(result == JFileChooser.APPROVE_OPTION) {
         filename = dlgOpen.getSelectedFile().getAbsoluteFile().toString();
         this.currentDirectory = new File(filename);
         fileImportJAVA(filename);
      }
   }

/**
 * The method doMoveDownNSD
 */
   void doMoveDownNSD() {
      getRootSelected().addUndo();
      RootElement.moveDown(getSelected());
      getRootSelected().setChangedNow(true);
      this.program.setChangedNow(true);
      paintNSD();
      analyse();
   }

/**
 * The method doMoveUpNSD
 */
   void doMoveUpNSD() {
      getRootSelected().addUndo();
      RootElement.moveUp(getSelected());
      getRootSelected().setChangedNow(true);
      this.program.setChangedNow(true);
      paintNSD();
      analyse();
   }

/**
 * The method doNewClass
 */
   void doNewClass() {
      final RootElement cx = getRootSelected();
      cx.addUndo();
      final JClass jclass = new JClass(new JMethod());
      jclass.setClosed(true);
      cx.addElement(jclass);
      cx.setChangedNow(true);
      paintNSD();
      analyse();
   }

/**
 * The method doNewMethod
 */
   void doNewMethod() {
      final RootElement cx = getRootSelected();
      cx.addUndo();
      JMethod cm;
      if(cx instanceof JClass) {
         cm = new JMethod("void method()");
         cx.addElement(cm);
         cm.setClosed(true);
      }
      else {
         cm = new JMethod("static void method()");
         cm.setClosed(false);
         this.program.addElement(cm);
      }
      cx.setChangedNow(true);
      paintNSD();
      analyse();
   }

/**
 * The method doNewNSD
 */
   public void doNewNSD() {
// only save if something has been changed
      fileSaveNSD(true);
      final boolean HV = AbstractElement.isE_VARHIGHLIGHT();
      this.program = new CompilationUnit();
      final JClass jclass = new JClass(new JMethod());
      jclass.setClosed(true);
      this.program.addElement(jclass);
      AbstractElement.setE_VARHIGHLIGHT(HV);
      this.program.setChangedNow(false);
      paintNSD();
      analyse();
   }

/**
 * The method doOpenNSD
 */
   void doOpenNSD() {
// create dialog
      final JFileChooser dlgOpen = new JFileChooser();
      dlgOpen.setDialogTitle("Open file...");
// set directory
      if(this.program.getFile() != null) {
         dlgOpen.setCurrentDirectory(this.program.getFile());
      }
      else {
         dlgOpen.setCurrentDirectory(this.currentDirectory);
      }
// config dialogue
      dlgOpen.addChoosableFileFilter(new StructogramFilter());
// ADDED 4/3/2015
      dlgOpen.setAcceptAllFileFilterUsed(false);
// show & get result
      final int result = dlgOpen.showOpenDialog(this);
// react on result
      if(result == JFileChooser.APPROVE_OPTION) {
         doOpenNSD(dlgOpen.getSelectedFile().getAbsoluteFile().toString());
      }
   }

/**
 * The method doOpenSelected
 */
   void doOpenSelected() {
      final RootElement root = getRootSelected();
      if(root.isClosed()) {
         root.setClosed(false);
         paintNSD();
      }
   }

/**
 * The method doParserOptions
 */
   void doParserOptions() {
      final ParserPreferences parserPreferences = new ParserPreferences(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      parserPreferences.setLocation(p.x + (getVisibleRect().width - parserPreferences.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - parserPreferences.getHeight()) / 2 + getVisibleRect().y);
// set fields
      parserPreferences.edtAltPre.setText(Java3Code.preAlt);
      parserPreferences.edtAltPost.setText(Java3Code.postAlt);
      parserPreferences.edtCasePre.setText(Java3Code.preCase);
      parserPreferences.edtCasePost.setText(Java3Code.postCase);
      parserPreferences.edtForPre.setText(Java3Code.preFor);
      parserPreferences.edtForPost.setText(Java3Code.postFor);
      parserPreferences.edtWhilePre.setText(Java3Code.preWhile);
      parserPreferences.edtWhilePost.setText(Java3Code.postWhile);
      parserPreferences.edtRepeatPre.setText(Java3Code.preRepeat);
      parserPreferences.edtRepeatPost.setText(Java3Code.postRepeat);
      parserPreferences.edtInput.setText(Java3Code.input);
      parserPreferences.edtOutput.setText(Java3Code.output);
      parserPreferences.setLang(this.NSDControl.getLang());
      parserPreferences.pack();
      parserPreferences.setVisible(true);
// get fields
      Java3Code.preAlt = parserPreferences.edtAltPre.getText();
      Java3Code.postAlt = parserPreferences.edtAltPost.getText();
      Java3Code.preCase = parserPreferences.edtCasePre.getText();
      Java3Code.postCase = parserPreferences.edtCasePost.getText();
      Java3Code.preFor = parserPreferences.edtForPre.getText();
      Java3Code.postFor = parserPreferences.edtForPost.getText();
      Java3Code.preWhile = parserPreferences.edtWhilePre.getText();
      Java3Code.postWhile = parserPreferences.edtWhilePost.getText();
      Java3Code.preRepeat = parserPreferences.edtRepeatPre.getText();
      Java3Code.postRepeat = parserPreferences.edtRepeatPost.getText();
      Java3Code.input = parserPreferences.edtInput.getText();
      Java3Code.output = parserPreferences.edtOutput.getText();
   }

/**
 * The method doPasteNSD
 */
   void doPasteNSD() {
      if(this.selected != null && this.eCopy != null) {
         getRootSelected().addUndo();
         this.selected.setSelected(false);
         final AbstractElement nE = this.eCopy.copy();
         nE.setSelected(true);
         getRootSelected().addAfter(this.selected, nE);
         getRootSelected().setChangedNow(true);
         this.program.setChangedNow(true);
         this.selected = nE;
         paintNSD();
         analyse();
      }
   }

/**
 * The method doPrintNSD
 */
   void doPrintNSD() {
      final PrintPreview pp = new PrintPreview(this.NSDControl.getFrame(), this);
      pp.setLang(this.NSDControl.getLang());
      final Point p = getLocationOnScreen();
      pp.setLocation(p.x + (getVisibleRect().width - pp.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - pp.getHeight()) / 2 + getVisibleRect().y);
      pp.setVisible(true);
   }

/**
 * The method doRedoNSD
 */
   void doRedoNSD() {
      getRootSelected().redo();
      paintNSD();
      analyse();
   }

/**
 * The method doReplaceTXT
 */
   void doReplaceTXT() {
      final ReplaceDialog replace = new ReplaceDialog(this.NSDControl.getFrame());
      replace.edtOld.setText(this.oldx);
      replace.edtNew.setText(this.newy);
      final Point p = getLocationOnScreen();
// setlocation
      replace.setLocation(p.x + (getVisibleRect().width - replace.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - replace.getHeight()) / 2 + getVisibleRect().y);
      replace.setLang(this.NSDControl.getLang());
      replace.pack();
      replace.setVisible(true);
      if(replace.btnOK.hasFocus() && (replace.btnTxt.isSelected() || replace.btnComm.isSelected())) {
         this.oldx = replace.edtOld.getText();
         this.newy = replace.edtNew.getText();
         final int x = this.program.wordReplace(this.oldx, this.newy, replace.btnTxt.isSelected(), replace.btnComm.isSelected());
         try {
            JOptionPane.showMessageDialog(null,  "Replaced: " + x);
         }
         catch(Exception e_x){
            /* nothing to do */
         }
         this.program.setChangedNow(true);
         paintNSD();
         analyse();
      }
   }

/**
 * The method doSaveAs
 */
   void doSaveAs() {
      final JFileChooser dlgSave = new JFileChooser();
      dlgSave.setDialogTitle("Save file as...");
// set directory
      if(this.program.getFile() != null) {
         dlgSave.setCurrentDirectory(this.program.getFile());
      }
      else {
         dlgSave.setCurrentDirectory(this.currentDirectory);
      }
      final String nsdName = this.program.getDefaultFileName();
      dlgSave.setSelectedFile(new File(nsdName));
      dlgSave.addChoosableFileFilter(new StructogramFilter());
      final int result = dlgSave.showSaveDialog(this);
      if(result == JFileChooser.APPROVE_OPTION) {
         String uFile = dlgSave.getSelectedFile().getAbsoluteFile().toString();
         if(!uFile.substring(uFile.length() - 4).toLowerCase().equals(".nsd")) {
            uFile = uFile + ".nsd";
         }
         this.program.setFilename(uFile);
         final File f = new File(uFile);
         boolean writeNow = true;
         if(f.exists()) {
            writeNow = false;
            final int r = JOptionPane.showConfirmDialog(this, "A file with the specified name exists.\nDo you want to owerwrite it?", "Owerwrite?", JOptionPane.YES_NO_OPTION);
            if(r == JOptionPane.YES_OPTION) {
               writeNow = true;
            }
         }
         if(writeNow == false) {
            JOptionPane.showMessageDialog(this, "Your file has not been saved.Please repeat the save operation!");
         }
         else {
            try {
               final FileOutputStream fos = new FileOutputStream(this.program.getFilename());
               final Writer out = new OutputStreamWriter(fos, "UTF8");
               final NSDGenerator xmlgen = new NSDGenerator();
               out.write(xmlgen.generateCode(getProgram(), "\t"));
               out.close();
               this.program.setChangedNow(false);
               recentFileAdd(this.program.getFilename());
            }
            catch (final Exception e) {
               JOptionPane.showOptionDialog(this, "Error while saving the file!", "Error", JOptionPane.OK_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);
            }
         }
      }
   }

/**
 * The method doSelectColorsPalette
 */
   void doSelectColorsPalette() {
      final Colors colors = new Colors(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      colors.setLocation(p.x + (getVisibleRect().width - colors.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - colors.getHeight()) / 2 + getVisibleRect().y);
// set fields
      colors.color0.setBackground(AbstractElement.color0);
      colors.color1.setBackground(AbstractElement.color1);
      colors.color2.setBackground(AbstractElement.color2);
      colors.color3.setBackground(AbstractElement.color3);
      colors.color4.setBackground(AbstractElement.color4);
      colors.color5.setBackground(AbstractElement.color5);
      colors.color6.setBackground(AbstractElement.color6);
      colors.color7.setBackground(AbstractElement.color7);
      colors.color8.setBackground(AbstractElement.color8);
      colors.color9.setBackground(AbstractElement.color9);
      colors.setLang(this.NSDControl.getLang());
      colors.pack();
      colors.setVisible(true);
// get fields
      AbstractElement.color0 = colors.color0.getBackground();
      AbstractElement.color1 = colors.color1.getBackground();
      AbstractElement.color2 = colors.color2.getBackground();
      AbstractElement.color3 = colors.color3.getBackground();
      AbstractElement.color4 = colors.color4.getBackground();
      AbstractElement.color5 = colors.color5.getBackground();
      AbstractElement.color6 = colors.color6.getBackground();
      AbstractElement.color7 = colors.color7.getBackground();
      AbstractElement.color8 = colors.color8.getBackground();
      AbstractElement.color9 = colors.color9.getBackground();
      this.NSDControl.updateColors();
   }

/**
 * The method doSetColor
 * @param _color Color
 */
   void doSetColor(Color _color) {
      if(getSelected() != null) {
         getSelected().setColor(_color);
// getSelected().setSelected(false);
// selected=null;
         getRootSelected().setChangedNow(true);
         this.program.setChangedNow(true);
         paintNSD();
      }
   }

/**
 * The method doSetComments
 * @param _comments boolean
 */
   void doSetComments(boolean _comments) {
      AbstractElement.setE_SHOWCOMMENTS(_comments);
      this.NSDControl.doButtons();
      paintNSD();
   }

/**
 * The method doSetHightlightVars
 * @param _highlight boolean
 */
   void doSetHightlightVars(boolean _highlight) {
      AbstractElement.setE_VARHIGHLIGHT(_highlight);
      this.NSDControl.doButtons();
      paintNSD();
   }

/**
 * The method doStructuresOptions
 */
   void doStructuresOptions() {
      final Preferences preferences = new Preferences(this.NSDControl.getFrame());
      final Point p = getLocationOnScreen();
      preferences.setLocation(p.x + (getVisibleRect().width - preferences.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - preferences.getHeight()) / 2 + getVisibleRect().y);
// set fields
      preferences.edtAltT.setText(AbstractElement.preAltT);
      preferences.edtAltF.setText(AbstractElement.preAltF);
      preferences.edtAlt.setText(AbstractElement.preAlt);
      preferences.txtCase.setText(AbstractElement.preCase);
      preferences.edtFor.setText(AbstractElement.preFor);
      preferences.edtWhile.setText(AbstractElement.preWhile);
      preferences.edtRepeat.setText(AbstractElement.preRepeat);
      preferences.setLang(this.NSDControl.getLang());
      preferences.pack();
      preferences.setVisible(true);
// get fields
      AbstractElement.preAltT = preferences.edtAltT.getText();
      AbstractElement.preAltF = preferences.edtAltF.getText();
      AbstractElement.preAlt = preferences.edtAlt.getText();
      AbstractElement.preCase = preferences.txtCase.getText();
      AbstractElement.preFor = preferences.edtFor.getText();
      AbstractElement.preWhile = preferences.edtWhile.getText();
      AbstractElement.preRepeat = preferences.edtRepeat.getText();
   }

/**
 * The method doToggleAnalyser
 */
   void doToggleAnalyser() {
      setAnalyser(!AbstractElement.isE_ANALYSER());
      if(AbstractElement.isE_ANALYSER() == true) {
         paintNSD();
         analyse();
      }
   }

/**
 * The method doToggleClose
 */
   void doToggleClose() {
      RootElement root = null;
      if(this.selected != null && (this.selected instanceof JMethod || this.selected instanceof JClass)) {
         root = (RootElement) this.selected;
         root.setClosed(!root.isClosed());
//            root.setChangedNow(true);
//            if(root.getParent() instanceof Subqueue) {
//               ((RootElement) root.getParent().getParent()).setChangedNow(true);
//            }
         this.NSDControl.doButtons();
         paintNSD();
      }
   }

/**
 * The method doUndoNSD
 */
   void doUndoNSD() {
      getRootSelected().undo();
      paintNSD();
      analyse();
   }

/**
 * The method fileSaveNSD
 * @param _checkChanged boolean
 */
   void fileSaveNSD(boolean _checkChanged) {
// true: only save if something has been changed + ask
// false: save unconditional
//debug      System.out.println("saveNSD: changed == "+program.hasChanged );
      if(_checkChanged && !this.program.isChanged()) {
         return;
      }
      boolean saveIt = false;
      int res = 0;
      if(_checkChanged == true) {
         res = JOptionPane.showOptionDialog(null, "Do you want to save the current NSD-File?", "Question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
      }
      if(res == 0) {
         saveIt = fileNameCheck(new StructogramFilter(), ".nsd");
      }
      if(saveIt == true) {
         try {
//debug     System.out.println("saving to "+ this.program.getFilename() );
            final FileOutputStream fos = new FileOutputStream(this.program.getFilename());
            final Writer out = new OutputStreamWriter(fos, "UTF8");
            final NSDGenerator xmlgen = new NSDGenerator();
            out.write(xmlgen.generateCode(this.program, "\t"));
            out.close();
            this.program.setChangedNow(false);
            recentFileAdd(this.program.getFilename());
         }
         catch (final Exception e) {
            try {
               JOptionPane.showMessageDialog(null,  "Error while saving the file!\n" + e.getMessage());
            }
            catch(Exception e_x){
               /* nothing to do */
            }
         }
         this.program.setChangedNow(false);
      }
   }

/**
 * The method getProgram
 * @return CompilationUnit
 */
   CompilationUnit getProgram() {
      return this.program;
   }

/**
 * the root of selected element (JMethod or JClass), or program
 * @return RootElement
 */
   RootElement getRootSelected() {
      RootElement root = null;
      if(this.selected != null) {
         root = this.selected.getRoot();
      }
      if(root != null) {
         return root;
      }
      return this.program;
   }

/**
 * The method getSelected
 * @return AbstractElement
 */
   AbstractElement getSelected() {
      return this.selected;
   }

/**
 * The method isCommentsOn
 * @return boolean
 */
   boolean isCommentsOn() {
      return AbstractElement.isE_SHOWCOMMENTS();
   }

/**
 * The method nsdCanCutCopy
 * @return boolean
 */
   boolean nsdCanCutCopy() {
      boolean cond = this.selected != null;
      if(this.selected != null) {
         cond = cond && !this.selected.getClass().getSimpleName().equals("Root");
         cond = cond && !this.selected.getClass().getSimpleName().equals("Subqueue");
      }
      return cond;
   }

/**
 * The method nsdCanPaste
 * @return boolean
 */
   boolean nsdCanPaste() {
      boolean cond = this.eCopy != null && this.selected != null;
      if(this.selected != null) {
         cond = cond && !this.selected.getClass().getSimpleName().equals("Root");
      }
      return cond;
   }

/**
 * The method paintNSD
 */
   void paintNSD() {
      AbstractElement.setE_NULLCOLOR(AbstractElement.color9);
      this.program.preRedraw();
      paintNSD(getGraphics());
   }

/**
 * The method recentFileAdd
 * @param _filename String
 */
   void recentFileAdd(String _filename) {
      recentFileAdd(_filename, true);
   }

/**
 * The method recentFileAdd
 * @param _filename String
 * @param saveINI boolean
 */
   void recentFileAdd(String _filename, boolean saveINI) {
      if(this.recentFiles.contains(_filename)) {
         this.recentFiles.remove(_filename);
      }
      this.recentFiles.insertElementAt(_filename, 0);
      while(this.recentFiles.size() > 10) {
         this.recentFiles.removeElementAt(this.recentFiles.size() - 1);
      }
      this.NSDControl.doButtons();
      if(saveINI == true) {
         this.NSDControl.savePreferences();
      }
   }

/**
 * The method setAnalyser
 * @param _analyse boolean
 */
   public void setAnalyser(boolean _analyse) {
      AbstractElement.setE_ANALYSER(_analyse);
      this.NSDControl.doButtons();
   }

/**
 * The method setSelected
 * @param e AbstractElement
 */
   void setSelected(AbstractElement e) {
      this.selected = e;
   }

/**
 * The method showInputBox
 * @param _data EditData
 */
   void showInputBox(EditData _data) {
      if(this.NSDControl != null) {
         final InputBox inputbox = new InputBox(this.NSDControl.getFrame(), true);
         final Point p = getLocationOnScreen();
// position inputbox in the middle of this component
         inputbox.setLocation(p.x + (getVisibleRect().width - inputbox.getWidth()) / 2 + getVisibleRect().x, p.y + (getVisibleRect().height - inputbox.getHeight()) / 2 + getVisibleRect().y);
// set title
         inputbox.setTitle(_data.title);
// set field
         inputbox.txtText.setText(_data.text.getText());
         inputbox.txtComment.setText(_data.comment.getText());
         inputbox.OK = false;
         inputbox.setLang(this.NSDControl.getLang());
         inputbox.setVisible(true);
// get fields
         _data.text.setText(inputbox.txtText.getText());
         _data.comment.setText(inputbox.txtComment.getText());
         _data.result = inputbox.OK;
         inputbox.dispose();
      }
   }
}
