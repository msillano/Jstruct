/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class is responsible for setting up the entire menubar.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.30      First Issue
 *		Bob Fisch		2008.04.12		Adapted for AbbstractGenerator plugin
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************/
//

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.nio.charset.Charset;
import java.util.Vector;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Call;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;
import lu.fisch.structorizer.helpers.GENPlugin;
import lu.fisch.structorizer.parsers.GENParser;
import lu.fisch.utils.ErrorMessages;

/**
  *
 */
public class Menu extends JMenuBar implements NSDController {

	private static final long serialVersionUID = -1162592177838198894L;
	private Diagram diagram = null;
	NSDController NSDControl = null;

	// Menu "File"
	protected JMenu menuFile = new JMenu("File");
	// Submenus of "File"
	protected JMenuItem menuFileNew = new JMenuItem("New", IconLoader.ico001);
	protected JMenuItem menuFileSave = new JMenuItem("Save", IconLoader.ico003);
	protected JMenuItem menuFileSaveAs = new JMenuItem("Save As ...",
			IconLoader.ico003);
	protected JMenuItem menuFileOpen = new JMenuItem("Open ...",
			IconLoader.ico002);
	protected JMenuItem menuFileOpenRecent = new JMenu("Open Recent File");
	protected JMenu menuFileExport = new JMenu("Export");

	// Submenu of "File -> Export"
	protected JMenu menuFileExportPicture = new JMenu("Picture");
	protected JMenuItem menuFileExportPicturePNG = new JMenuItem("PNG ...",
			IconLoader.ico032);
	protected JMenuItem menuFileExportPictureEMF = new JMenuItem("EMF ...",
			IconLoader.ico032);
	protected JMenuItem menuFileExportPictureSWF = new JMenuItem("SWF ...",
			IconLoader.ico032);
	protected JMenuItem menuFileExportPicturePDF = new JMenuItem("PDF ...",
			IconLoader.ico032);
	protected JMenuItem menuFileExportPictureSVG = new JMenuItem("SVG ...",
			IconLoader.ico032);
	protected JMenu menuFileExportCode = new JMenu("Code");
	/*
	 * protected JMenuItem menuFileExportPascal = new
	 * JMenuItem("Pascal Code ...",IconLoader.ico004); protected JMenuItem
	 * menuFileExportOberon = new
	 * JMenuItem("Oberon Code ...",IconLoader.ico004); protected JMenuItem
	 * menuFileExportStruktex = new
	 * JMenuItem("StrukTeX Code ...",IconLoader.ico076); protected JMenuItem
	 * menuFileExportPerl = new JMenuItem("Perl Code ...",IconLoader.ico004);
	 * protected JMenuItem menuFileExportKSH = new
	 * JMenuItem("KSH Code ...",IconLoader.ico004);
	 */
	protected JMenu menuFileImport = new JMenu("Import");
	// Submenu of "File -> Import"
//	protected JMenuItem menuFileImportPascal = new JMenuItem("Pascal Code ...",
//			IconLoader.ico004);
	protected JMenuItem menuFileImportJava = new JMenuItem("Java Code ...",
			IconLoader.ico120);

	protected JMenuItem menuFilePrint = new JMenuItem("Print ...",
			IconLoader.ico041);
	protected JMenuItem menuFileQuit = new JMenuItem("Quit");

	// Menu "Edit"
	protected JMenu menuEdit = new JMenu("Edit");
	// Submenu of "Edit"
	protected JMenuItem menuEditUndo = new JMenuItem("Undo", IconLoader.ico039);
	protected JMenuItem menuEditRedo = new JMenuItem("Redo", IconLoader.ico038);
	protected JMenuItem menuEditCut = new JMenuItem("Cut", IconLoader.ico044);
	protected JMenuItem menuEditCopy = new JMenuItem("Copy", IconLoader.ico042);
	protected JMenuItem menuEditPaste = new JMenuItem("Paste",
			IconLoader.ico043);
	protected JMenuItem menuFReplace = new JMenuItem(
			"Find/Replace Text", IconLoader.ico083);

	protected JMenuItem menuEditCopyDiagramPNG = new JMenuItem(
			"Copy bitmap diagram to clipboard", IconLoader.ico032);
	protected JMenuItem menuEditCopyDiagramEMF = new JMenuItem(
			"Copy vector diagram to clipboard", IconLoader.ico032);

	protected JMenu menuView = new JMenu("View");

	// Menu "Diagram"
	protected JMenu menuDiagram = new JMenu("Diagram");
	// Submenus of "Diagram"
	protected JMenuItem menuDiagramNewMethod = new JMenuItem(
			"new Class", IconLoader.ico022);
	protected JMenuItem menuDiagramNewClass = new JMenuItem(
			"new Method", IconLoader.ico021);

	protected JMenu menuDiagramAdd = new JMenu("Add");
	// Submenu "Diagram -> Add -> Before"
	protected JMenu menuDiagramAddBefore = new JMenu("Before");
	// Submenus for adding Elements "Before"
	protected JMenuItem menuDiagramAddBeforeInst = new JMenuItem("Instruction",
			IconLoader.ico007);
	protected JMenuItem menuDiagramAddBeforeAlt = new JMenuItem("IF statement",
			IconLoader.ico008);
	protected JMenuItem menuDiagramAddBeforeCase = new JMenuItem(
			"CASE statement", IconLoader.ico047);
	protected JMenuItem menuDiagramAddBeforeFor = new JMenuItem("FOR loop",
			IconLoader.ico010);
	protected JMenuItem menuDiagramAddBeforeWhile = new JMenuItem("WHILE loop",
			IconLoader.ico010);
	protected JMenuItem menuDiagramAddBeforeRepeat = new JMenuItem("DO loop",
			IconLoader.ico011);
	protected JMenuItem menuDiagramAddBeforeCall = new JMenuItem("Call",
			IconLoader.ico049);
	protected JMenuItem menuDiagramAddBeforeTry = new JMenuItem("Try",
			IconLoader.ico009);
	/*
	 * // 2011.03.01 removed: protected JMenuItem menuDiagramAddBeforeForever =
	 * new JMenuItem("ENDLESS loop",IconLoader.ico009); protected JMenuItem
	 * menuDiagramAddBeforeJump = new JMenuItem("Jump",IconLoader.ico056);
	 */

	// Submenu "Diagram -> Add -> After"
	protected JMenu menuDiagramAddAfter = new JMenu("After");
	// Submenus for adding Elements "After"
	protected JMenuItem menuDiagramAddAfterInst = new JMenuItem("Instruction",
			IconLoader.ico012);
	protected JMenuItem menuDiagramAddAfterAlt = new JMenuItem("IF statement",
			IconLoader.ico013);
	protected JMenuItem menuDiagramAddAfterCase = new JMenuItem(
			"CASE statement", IconLoader.ico048);
	protected JMenuItem menuDiagramAddAfterFor = new JMenuItem("FOR loop",
			IconLoader.ico014);
	protected JMenuItem menuDiagramAddAfterWhile = new JMenuItem("WHILE loop",
			IconLoader.ico015);
	protected JMenuItem menuDiagramAddAfterRepeat = new JMenuItem("DO loop",
			IconLoader.ico016);
	protected JMenuItem menuDiagramAddAfterCall = new JMenuItem("Call",
			IconLoader.ico050);
	protected JMenuItem menuDiagramAddAfterTry = new JMenuItem("Try",
			IconLoader.ico014);
	/*
	 * // 2011.03.01 removed: protected JMenuItem menuDiagramAddAfterForever =
	 * new JMenuItem("ENDLESS loop",IconLoader.ico014); protected JMenuItem
	 * menuDiagramAddAfterJump = new JMenuItem("Jump",IconLoader.ico055);
	 */
	protected JMenuItem menuDiagramEdit = new JMenuItem("Edit",
			IconLoader.ico006);
	protected JMenuItem menuDiagramDelete = new JMenuItem("Delete",
			IconLoader.ico005);
	protected JMenuItem menuDiagramMoveUp = new JMenuItem("Move up",
			IconLoader.ico019);
	protected JMenuItem menuDiagramMoveDown = new JMenuItem("Move down",
			IconLoader.ico020);

//	protected JMenu menuDiagramType = new JMenu("New");
	protected JMenuItem menuDiagramShowDetails = new JMenuItem(
			"Show details", IconLoader.ico040);
	protected JCheckBoxMenuItem menuDiagramComment = new JCheckBoxMenuItem(
			"Show comments?", IconLoader.ico077);
	protected JCheckBoxMenuItem menuDiagramMarker = new JCheckBoxMenuItem(
			"Highlight variables?", IconLoader.ico079);
//	protected JCheckBoxMenuItem menuDiagramDIN = new JCheckBoxMenuItem("DIN?",
//			IconLoader.ico082);
	protected JCheckBoxMenuItem menuDiagramAnalyser = new JCheckBoxMenuItem(
			"Analyse structogram?", IconLoader.ico083);

	// Menu "Help"
	protected JMenu menuPreferences = new JMenu("Preferences");
	// Submenu of "Help"
	protected JMenuItem menuPreferencesFont = new JMenuItem("Font ...",
			IconLoader.ico023);
	protected JMenuItem menuPreferencesColors = new JMenuItem("Colors ...",
			IconLoader.ico031);
	protected JMenuItem menuPreferencesOptions = new JMenuItem(
			"Structures ...", IconLoader.ico040);
	protected JMenuItem menuPreferencesParser = new JMenuItem("Parser ...",
			IconLoader.ico004);
	protected JMenuItem menuPreferencesAnalyser = new JMenuItem("Analyser ...",
			IconLoader.ico083);
	protected JMenu menuPreferencesLanguage = new JMenu("Language");
	protected JMenuItem menuPreferencesLanguageEnglish = new JCheckBoxMenuItem(
			"English", IconLoader.ico046);
	protected JMenuItem menuPreferencesLanguageGerman = new JCheckBoxMenuItem(
			"German", IconLoader.ico080);
	protected JMenuItem menuPreferencesLanguageFrench = new JCheckBoxMenuItem(
			"French", IconLoader.ico045);
	protected JMenuItem menuPreferencesLanguageDutch = new JCheckBoxMenuItem(
			"Dutch", IconLoader.ico051);
	protected JMenuItem menuPreferencesLanguageLuxemburgish = new JCheckBoxMenuItem(
			"Luxemburgish", IconLoader.ico075);
	protected JMenuItem menuPreferencesLanguageSpanish = new JCheckBoxMenuItem(
			"Spanish", IconLoader.ico084);
	protected JMenuItem menuPreferencesLanguagePortugalBrazil = new JCheckBoxMenuItem(
			"Brazilian portuguese", IconLoader.ico085);
	protected JMenuItem menuPreferencesLanguageItalian = new JCheckBoxMenuItem(
			"Italian", IconLoader.ico086);
	protected JMenuItem menuPreferencesLanguageChinese = new JCheckBoxMenuItem(
			"Chinese", IconLoader.ico087);
	protected JMenuItem menuPreferencesLanguageCzech = new JCheckBoxMenuItem(
			"Czech", IconLoader.ico088);
	protected JMenu menuPreferencesLookAndFeel = new JMenu("Look & Feel");
// 	 US-ASCII Seven-bit ASCII, a.k.a. ISO646-US, a.k.a. the Basic Latin block of the Unicode character set
//	 ISO-8859-1   ISO Latin Alphabet No. 1, a.k.a. ISO-LATIN-1
//	 UTF-8 Eight-bit UCS Transformation Format
//	 UTF-16BE Sixteen-bit UCS Transformation Format, big-endian byte order
//	 UTF-16LE Sixteen-bit UCS Transformation Format, little-endian byte order
//	 UTF-16 Sixteen-bit UCS Transformation Format, byte order identified by an optional byte-order mark

	protected JMenu menuPreferencesOutCode = new JMenu("Java coding");

	protected JMenuItem menuPreferencesOutCodeDefault = new JCheckBoxMenuItem(
			"default ("+Charset.defaultCharset().displayName()+")", null);

	protected JMenuItem menuPreferencesOutCodeUSACII = new JCheckBoxMenuItem(
			"US-ASCII (ISO646-US)", null);
	protected JMenuItem menuPreferencesOutCodeLATIN = new JCheckBoxMenuItem(
			"ISO-8859-1 (ISO-LATIN-1)", null);
	protected JMenuItem menuPreferencesOutCodeUTF8 = new JCheckBoxMenuItem(
			"UTF-8", null);
	protected JMenuItem menuPreferencesOutCodeUTF16 = new JCheckBoxMenuItem(
			"UTF-16", null);

//java style  10/05/2015

    protected JMenu menuPreferencesOutStyle = new JMenu("Java export style");

    protected JMenuItem menuPreferencesOutStylePublic = new JCheckBoxMenuItem(
            "Add Javadoc to public items", null);

    protected JMenuItem menuPreferencesOutStyleExtra = new JCheckBoxMenuItem(
            "Add extra infos to top item", null);

    protected JMenuItem menuPreferencesOutStyleImage = new JCheckBoxMenuItem(
            "Add image reference", null);
    protected JMenuItem menuPreferencesOutStyleVersion = new JCheckBoxMenuItem(
            "Update build number", null);
    protected JMenuItem menuPreferencesOutStyleComments = new JCheckBoxMenuItem(
            "Put comments before code", null);


	protected JMenuItem menuPreferencesSave = new JMenuItem(
	"Save all preferences");

	// Menu "Help"
	protected JMenu menuHelp = new JMenu("Help");
	// Submenu of "Help"
	protected JMenuItem menuHelpJStruct = new JMenuItem("User help ...",
			IconLoader.ico102);
	protected JMenuItem menuHelpAbout = new JMenuItem("About ...",
			IconLoader.ico017);

// Alias Error messages for analyser
// here for lang update
     static JLabel error03   = ErrorMessages.error03;
     static JLabel error04   = ErrorMessages.error04;
	 static JLabel error05   = ErrorMessages.error05;
	 static JLabel error06_1 = ErrorMessages.error06_1;
	 static JLabel error06_2 = ErrorMessages.error06_2;
	 static JLabel error06_3 = ErrorMessages.error06_3;
	 static JLabel error06_4 = ErrorMessages.error06_4;
	 static JLabel error07_1 = ErrorMessages.error07_1;
	 static JLabel error07_2 = ErrorMessages.error07_2;
	 static JLabel error07_3 = ErrorMessages.error07_3;
	 static JLabel error08   = ErrorMessages.error08;
	 static JLabel error10_1 = ErrorMessages.error10_1;
	 static JLabel error11   = ErrorMessages.error11;
	 static JLabel error12   = ErrorMessages.error12;
	 static JLabel error13_1 = ErrorMessages.error13_1;
	 static JLabel error13_2 = ErrorMessages.error13_2;
	 static JLabel error13_3 = ErrorMessages.error13_3;

	 void create() {
		final JMenuBar menubar = this;

		// Setting up Menu "File" with all submenus and shortcuts and actions
		menubar.add(this.menuFile);
		this.menuFile.setMnemonic(KeyEvent.VK_F);

		this.menuFile.add(this.menuFileNew);
		this.menuFileNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuFileNew.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doNewNSD();
				doButtons();
			}
		});

		this.menuFile.add(this.menuFileSave);
		this.menuFileSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuFileSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().fileSaveNSD(false);
				doButtons();
			}
		});

		this.menuFile.add(this.menuFileSaveAs);
		this.menuFileSaveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				(java.awt.event.InputEvent.SHIFT_MASK | Toolkit
						.getDefaultToolkit().getMenuShortcutKeyMask())));
		this.menuFileSaveAs.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doSaveAs();
				doButtons();
			}
		});

		this.menuFile.add(this.menuFileOpen);
		this.menuFileOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuFileOpen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doOpenNSD();
				doButtons();
			}
		});

		this.menuFile.add(this.menuFileOpenRecent);
		this.menuFileOpenRecent.setIcon(IconLoader.ico002);

		this.menuFile.addSeparator();

		this.menuFile.add(this.menuFileImport);
		/*
				menuFileImport.add(menuFileImportPascal);
				menuFileImportPascal.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						diagram.importPAS();
						doButtons();
					}
				});
		 */
		this.menuFileImport.add(this.menuFileImportJava);
		this.menuFileImport.setIcon(IconLoader.ico120);
		this.menuFileImportJava.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doImportJAVA();
				doButtons();
			}
		});

		this.menuFile.add(this.menuFileExport);

		this.menuFileExport.add(this.menuFileExportPicture);
		this.menuFileExportPicture.setIcon(IconLoader.ico032);

		this.menuFileExportPicture.add(this.menuFileExportPicturePNG);
		this.menuFileExportPicturePNG.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_E, Toolkit.getDefaultToolkit()
				.getMenuShortcutKeyMask()));
		this.menuFileExportPicturePNG.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doExportPNG();
				doButtons();
			}
		});

		this.menuFileExportPicture.add(this.menuFileExportPictureEMF);
		this.menuFileExportPictureEMF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doExportEMF();
				doButtons();
			}
		});

		this.menuFileExportPicture.add(this.menuFileExportPictureSWF);
		this.menuFileExportPictureSWF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doExportSWF();
				doButtons();
			}
		});

		this.menuFileExportPicture.add(this.menuFileExportPicturePDF);
		this.menuFileExportPicturePDF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doExportPDF();
				doButtons();
			}
		});

		this.menuFileExportPicture.add(this.menuFileExportPictureSVG);
		this.menuFileExportPictureSVG.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doExportSVG();
				doButtons();
			}
		});

		this.menuFileExport.add(this.menuFileExportCode);
		this.menuFileExportCode.setIcon(IconLoader.ico120);

		// read generators from file
		// and add them to the menu
		final BufferedInputStream buff = new BufferedInputStream(getClass()
				.getResourceAsStream("generators.xml"));
		final GENParser genp = new GENParser();
		final Vector<GENPlugin> plugins = genp.parse(buff);
		for (int i = 0; i < plugins.size(); i++) {
			final GENPlugin plugin =  plugins.get(i);
			final JMenuItem pluginItem = new JMenuItem(plugin.title,
					IconLoader.ico004);
			this.menuFileExportCode.add(pluginItem);
			final String className = plugin.className;
			pluginItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent event) {
					getDiagram().doExportCode(className);
					doButtons();
				}
			});
		}
		/*
		 * menuFileExport.add(menuFileExportPascal);
		 * menuFileExportPascal.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent event) {
		 * diagram.export("lu.fisch.structorizer.generators.PasGenerator");
		 * doButtons(); } } );
		 *
		 * menuFileExport.add(menuFileExportOberon);
		 * menuFileExportOberon.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent event) { diagram.exportMOD();
		 * doButtons(); } } );
		 *
		 * menuFileExport.add(menuFileExportStruktex);
		 * menuFileExportStruktex.addActionListener(new ActionListener() {
		 * public void actionPerformed(ActionEvent event) { diagram.exportTEX();
		 * doButtons(); } } );
		 *
		 * menuFileExport.add(menuFileExportPerl);
		 * menuFileExportPerl.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent event) { diagram.exportPerl();
		 * doButtons(); } } );
		 *
		 * menuFileExport.add(menuFileExportKSH);
		 * menuFileExportKSH.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent event) { diagram.exportKSH();
		 * doButtons(); } } );
		 */
		this.menuFile.addSeparator();

		this.menuFile.add(this.menuFilePrint);
		this.menuFilePrint.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuFilePrint.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doPrintNSD();
				doButtons();
			}
		});

		this.menuFile.addSeparator();

		this.menuFile.add(this.menuFileQuit);
		this.menuFileQuit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuFileQuit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				// here ok to exit
//				getDiagram().dispatchEvent(new WindowEvent(getFrame(), WindowEvent.WINDOW_CLOSING));
			System.exit(0);
			}
		});

		// Setting up Menu "Edit" with all submenus and shortcuts and actions
		menubar.add(this.menuEdit);
		this.menuEdit.setMnemonic(KeyEvent.VK_E);

		this.menuEdit.add(this.menuEditUndo);
		this.menuEditUndo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuEditUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doUndoNSD();
				doButtons();
			}
		});

		this.menuEdit.add(this.menuEditRedo);
		this.menuEditRedo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				(java.awt.event.InputEvent.SHIFT_MASK | Toolkit
						.getDefaultToolkit().getMenuShortcutKeyMask())));
		this.menuEditRedo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doRedoNSD();
				doButtons();
			}
		});

		this.menuEdit.addSeparator();

		this.menuEdit.add(this.menuEditCut);
		this.menuEditCut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuEditCut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doCutNSD();
				doButtons();
			}
		});

		this.menuEdit.add(this.menuEditCopy);
		// Toolkit.getDefaultToolkit().get
		// MenuShortcut ms = new MenuShortcut
		this.menuEditCopy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuEditCopy.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doCopyNSD();
				doButtons();
			}
		});

		this.menuEdit.add(this.menuEditPaste);
		this.menuEditPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		this.menuEditPaste.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doPasteNSD();
				doButtons();
			}
		});

		this.menuEdit.addSeparator();

		this.menuEdit.add(this.menuFReplace);
		this.menuFReplace.setFocusable(false);
		this.menuFReplace.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doReplaceTXT();
				doButtons();
			}
		});
		this.menuEdit.addSeparator();

		this.menuEdit.add(this.menuEditCopyDiagramPNG);
		this.menuEditCopyDiagramPNG.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_D, Toolkit.getDefaultToolkit()
				.getMenuShortcutKeyMask()));
		this.menuEditCopyDiagramPNG.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doCopyToClipboardPNG(false);
				doButtons();
			}
		});

		if (!System.getProperty("os.name").toLowerCase().startsWith("mac os x")) {
			this.menuEdit.add(this.menuEditCopyDiagramEMF);
			this.menuEditCopyDiagramEMF.setAccelerator(KeyStroke.getKeyStroke(
					KeyEvent.VK_F, Toolkit.getDefaultToolkit()
					.getMenuShortcutKeyMask()));
			this.menuEditCopyDiagramEMF.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent event) {
					getDiagram().doCopyToClipboardEMF(false);
					doButtons();
				}
			});
		}

		// Setting up Menu "View" with all submenus and shortcuts and actions
		// menubar.add(menuView);

		// Setting up Menu "Diagram" with all submenus and shortcuts and actions
		menubar.add(this.menuDiagram);
		this.menuDiagram.setMnemonic(KeyEvent.VK_D);

		this.menuDiagram.add(this.menuDiagramNewMethod);
		this.menuDiagramNewMethod.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doNewMethod();
				doButtons();
			}
		});

		this.menuDiagram.add(this.menuDiagramNewClass);
		this.menuDiagramNewClass.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doNewClass();
				doButtons();
			}
		});


		this.menuDiagram.add(this.menuDiagramAdd);
		this.menuDiagramAdd.setIcon(IconLoader.ico018);
		this.menuDiagramAdd.add(this.menuDiagramAddBefore);
		this.menuDiagramAddBefore.setIcon(IconLoader.ico019);

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeInst);
		this.menuDiagramAddBeforeInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Instruction(),
						"Add new instruction ...", "", false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeCall);
		this.menuDiagramAddBeforeCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Call(), "Add new substructure ...",
						"", false);
				doButtons();
			}
		});


		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeAlt);
		this.menuDiagramAddBeforeAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeCase);
		this.menuDiagramAddBeforeCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeFor);
		this.menuDiagramAddBeforeFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeWhile);
		this.menuDiagramAddBeforeWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeRepeat);
		this.menuDiagramAddBeforeRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, false);
				doButtons();
			}
		});

		this.menuDiagramAddBefore.add(this.menuDiagramAddBeforeTry);
		this.menuDiagramAddBeforeTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, false);
				doButtons();
			}
		});
		/*
		 * 2011.03.01 removed:
		 * menuDiagramAddBefore.add(menuDiagramAddBeforeForever);
		 * menuDiagramAddBeforeForever.addActionListener(new ActionListener() {
		 * public void actionPerformed(ActionEvent event) {
		 * diagram.addNewElement(new
		 * Forever(),"Add new ENDLESS loop ...","",false); doButtons(); } } );
		 */
		/*
		 * 2011.03.01 removed:
		 * menuDiagramAddBefore.add(menuDiagramAddBeforeJump);
		 * menuDiagramAddBeforeJump.addActionListener(new ActionListener() {
		 * public void actionPerformed(ActionEvent event) {
		 * diagram.addNewElement(new Jump(),"Add new jump ...","",false);
		 * doButtons(); } } );
		 */
		this.menuDiagramAdd.add(this.menuDiagramAddAfter);
		this.menuDiagramAddAfter.setIcon(IconLoader.ico020);

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterInst);
		this.menuDiagramAddAfterInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Instruction(),
						"Add new instruction ...", "", true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterInst.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F5, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterCall);
		this.menuDiagramAddAfterCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Call(), "Add new substructure ...",
						"", true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterCall.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F11, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterAlt);
		this.menuDiagramAddAfterAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterAlt.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F6, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterCase);
		this.menuDiagramAddAfterCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterCase.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F10, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterFor);
		this.menuDiagramAddAfterFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterFor.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F7, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterWhile);
		this.menuDiagramAddAfterWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterWhile.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F8, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterRepeat);
		this.menuDiagramAddAfterRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, true);
				doButtons();
			}
		});

		this.menuDiagramAddAfterRepeat.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F9, 0));

		this.menuDiagramAddAfter.add(this.menuDiagramAddAfterTry);
		this.menuDiagramAddAfterTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, true);
				doButtons();
			}
		});
		this.menuDiagramAddAfterTry.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F10, 0));

		/*
		 * 2011.03.01 removed:
		 * menuDiagramAddAfter.add(menuDiagramAddAfterForever);
		 * menuDiagramAddAfterForever.addActionListener(new ActionListener() {
		 * public void actionPerformed(ActionEvent event) {
		 * diagram.addNewElement(new
		 * Forever(),"Add new ENDLESS loop ...","",true); doButtons(); } } );
		 */
		/*
		 * 2011.03.01 removed: menuDiagramAddAfter.add(menuDiagramAddAfterJump);
		 * menuDiagramAddAfterJump.addActionListener(new ActionListener() {
		 * public void actionPerformed(ActionEvent event) {
		 * diagram.addNewElement(new Jump(),"Add new jump ...","",true);
		 * doButtons(); } } );
		 * menuDiagramAddAfterJump.setAccelerator(KeyStroke.getKeyStroke
		 * (KeyEvent.VK_F12,0));
		 */
		this.menuDiagram.add(this.menuDiagramEdit);
		this.menuDiagramEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doEditNSD();
				doButtons();
			}
		});

		this.menuDiagram.add(this.menuDiagramDelete);
		this.menuDiagramDelete.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_DELETE, 0));
		this.menuDiagramDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doDeleteNSD();
				doButtons();
			}
		});

		this.menuDiagram.addSeparator();

		this.menuDiagram.add(this.menuDiagramMoveUp);
		this.menuDiagramMoveUp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doMoveUpNSD();
				doButtons();
			}
		});

		this.menuDiagram.add(this.menuDiagramMoveDown);
		this.menuDiagramMoveDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doMoveDownNSD();
				doButtons();
			}
		});

		this.menuDiagram.addSeparator();

//		this.menuDiagram.add(this.menuDiagramType);


		this.menuDiagram.add(this.menuDiagramShowDetails);
		this.menuDiagramShowDetails.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doToggleClose();
				doButtons();
			}
		});
		this.menuDiagramShowDetails.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1,
				0));

		this.menuDiagram.add(this.menuDiagramComment);
		this.menuDiagramComment.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doSetComments(Menu.this.menuDiagramComment.isSelected());
				doButtons();
			}
		});
		this.menuDiagramComment.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2,
				0));

		this.menuDiagram.add(this.menuDiagramMarker);
		this.menuDiagramMarker.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doSetHightlightVars(Menu.this.menuDiagramMarker.isSelected());
				doButtons();
			}
		});
		this.menuDiagramMarker.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3,
				0));
		/*
		menuDiagram.add(menuDiagramDIN);
		menuDiagramDIN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.toggleDIN();
				doButtons();
			}
		});
		 */
		this.menuDiagram.add(this.menuDiagramAnalyser);
		this.menuDiagramAnalyser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doToggleAnalyser();
				doButtons();
			}
		});
		this.menuDiagramAnalyser.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F4, 0));

		// Setting up Menu "Preferences" with all submenus and shortcuts and
		// actions
		menubar.add(this.menuPreferences);
		this.menuPreferences.setMnemonic(KeyEvent.VK_P);

		this.menuPreferences.add(this.menuPreferencesFont);
		this.menuPreferencesFont.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doFontOptions();
				doButtons();
			}
		});

		this.menuPreferences.add(this.menuPreferencesColors);
		this.menuPreferencesColors.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doSelectColorsPalette();
				doButtons();
			}
		});

		this.menuPreferences.add(this.menuPreferencesOptions);
		this.menuPreferencesOptions.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doStructuresOptions();
				doButtons();
			}
		});

		this.menuPreferences.add(this.menuPreferencesParser);
		this.menuPreferencesParser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doParserOptions();
				doButtons();
			}
		});

		this.menuPreferences.add(this.menuPreferencesAnalyser);
		this.menuPreferencesAnalyser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAnalyserOptions();
				doButtons();
			}
		});

		this.menuPreferences.add(this.menuPreferencesLanguage);
		this.menuPreferencesLanguage.setIcon(IconLoader.ico081);

		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageEnglish);
		this.menuPreferencesLanguageEnglish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("en.txt");
				doButtons();
			}
		});
/*
		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageGerman);
		this.menuPreferencesLanguageGerman.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("de.txt");
				doButtons();
			}
		});
*/
		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageFrench);
		this.menuPreferencesLanguageFrench.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("fr.txt");
				doButtons();
			}
		});
/*
		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageDutch);
		this.menuPreferencesLanguageDutch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("nl.txt");
				doButtons();
			}
		});

		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageLuxemburgish);
		this.menuPreferencesLanguageLuxemburgish
		.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("lu.txt");
				doButtons();
			}
		});

		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageSpanish);
		this.menuPreferencesLanguageSpanish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("es.txt");
				doButtons();
			}
		});

		this.menuPreferencesLanguage.add(this.menuPreferencesLanguagePortugalBrazil);
		this.menuPreferencesLanguagePortugalBrazil
		.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("pt_br.txt");
				doButtons();
			}
		});
*/
		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageItalian);
		this.menuPreferencesLanguageItalian.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("it.txt");
				doButtons();
			}
		});
/*
		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageChinese);
		this.menuPreferencesLanguageChinese.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("cn.txt");
				doButtons();
			}
		});

		this.menuPreferencesLanguage.add(this.menuPreferencesLanguageCzech);
		this.menuPreferencesLanguageCzech.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setLang("cz.txt");
				doButtons();
			}
		});
*/
		// create Look & Feel Menu
		this.menuPreferences.add(this.menuPreferencesLookAndFeel);
		this.menuPreferencesLookAndFeel.setIcon(IconLoader.ico078);
		final UIManager.LookAndFeelInfo plafs[] = UIManager
		.getInstalledLookAndFeels();
		for (int j = 0; j < plafs.length; ++j) {
			final JCheckBoxMenuItem mi = new JCheckBoxMenuItem(plafs[j].getName());
			mi.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent event) {
					Menu.this.NSDControl.setLookAndFeel(((JCheckBoxMenuItem) event
							.getSource()).getText());
					doButtons();
				}
			});
			this.menuPreferencesLookAndFeel.add(mi);

			if (mi.getText().equals(UIManager.getLookAndFeel().getName())) {
				mi.setSelected(true);
			}
		}


		this.menuPreferences.add(this.menuPreferencesOutCode);
		this.menuPreferencesOutCode.setIcon(IconLoader.ico120);

		this.menuPreferencesOutCode.add(this.menuPreferencesOutCodeDefault);
		this.menuPreferencesOutCodeDefault.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setOutCoding(Charset.defaultCharset().displayName());
				doButtons();
			}
		});

		this.menuPreferencesOutCode.add(this.menuPreferencesOutCodeUSACII);
		this.menuPreferencesOutCodeUSACII.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setOutCoding("US-ASCII");
				doButtons();
			}
		});

		this.menuPreferencesOutCode.add(this.menuPreferencesOutCodeLATIN);
		this.menuPreferencesOutCodeLATIN.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setOutCoding("ISO-8859-1");
				doButtons();
			}
		});
		this.menuPreferencesOutCode.add(this.menuPreferencesOutCodeUTF8);
		this.menuPreferencesOutCodeUTF8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setOutCoding("UTF-8");
				doButtons();
			}
		});
		this.menuPreferencesOutCode.add(this.menuPreferencesOutCodeUTF16);
		this.menuPreferencesOutCodeUTF16.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				setOutCoding("UTF-16");
				doButtons();
			}
		});


//java style  10/05/2015


        this.menuPreferences.add(this.menuPreferencesOutStyle);
        this.menuPreferencesOutStyle.setIcon(IconLoader.ico120);

        this.menuPreferencesOutStyle.add(this.menuPreferencesOutStyleComments);
        this.menuPreferencesOutStyleComments.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
               AbstractElement.PROGRAMDOCONTOP = ! AbstractElement.PROGRAMDOCONTOP;
               doButtons();
            }
        });

      this.menuPreferencesOutStyle.add(this.menuPreferencesOutStyleExtra);
        this.menuPreferencesOutStyleExtra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
               AbstractElement.ADDJAVADOCEXTRA = ! AbstractElement.ADDJAVADOCEXTRA;
                doButtons();
            }
        });


        this.menuPreferencesOutStyle.add(this.menuPreferencesOutStylePublic);
        this.menuPreferencesOutStylePublic.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
               AbstractElement.ADDJAVADOCPUBLIC = ! AbstractElement.ADDJAVADOCPUBLIC;
                doButtons();
            }
        });

        this.menuPreferencesOutStyle.add(this.menuPreferencesOutStyleVersion);
        this.menuPreferencesOutStyleImage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
               AbstractElement.SETSOURCEVERSION = ! AbstractElement.SETSOURCEVERSION;
                doButtons();
            }
        });

          this.menuPreferencesOutStyle.add(this.menuPreferencesOutStyleImage);
        this.menuPreferencesOutStyleImage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
               AbstractElement.ADDJAVADOCIMAGE = ! AbstractElement.ADDJAVADOCIMAGE;
                doButtons();
            }
        });



		this.menuPreferences.addSeparator();

		this.menuPreferences.add(this.menuPreferencesSave);
		this.menuPreferencesSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Menu.this.NSDControl.savePreferences();
			}
		});

		// Setting up Menu "Help" with all submenus and shortcuts and actions
		menubar.add(this.menuHelp);
		this.menuDiagram.setMnemonic(KeyEvent.VK_A);


		this.menuHelp.add(this.menuHelpJStruct);
		this.menuHelpJStruct.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doHelpJS();
			}
		});

		this.menuHelpJStruct.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
//		this.menuHelpUpdate.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1,
//				Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));

		this.menuHelp.add(this.menuHelpAbout);
		this.menuHelpAbout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				getDiagram().doAbout();
			}
		});
//		this.menuHelpAbout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));

	}

	@Override
	public void setLookAndFeel(String _laf) {
		// nothing to do
	}

	@Override
	public String getLookAndFeel() {
		return null;
	}

	@Override
	public void doButtons() {
		if (this.NSDControl != null) {
			this.NSDControl.doButtons();
		}
	}

	@Override
	public void setLangLocal(String _langfile) {
		LangDialog.setLang(this, this.NSDControl.getLang());
		getDiagram().analyse();
	}

	@Override
	public void setLang(String _langfile) {
		this.NSDControl.setLang(_langfile);
	}

	@Override
	public String getLang() {
		return this.NSDControl.getLang();
	}


	@Override
	public String getOutCoding() {
		return this.NSDControl.getOutCoding();
	}


	@Override
	public void setOutCoding(String outCoding) {
		this.NSDControl.setOutCoding(outCoding);
	}

	@Override
	public void doButtonsLocal() {
		if (getDiagram() != null) {
			/*
			 * // remove all submenus from "view" menuView.removeAll(); // add
			 * submenus to "view" for(int i=0;i<diagram.toolbars.size();i++) {
			 * final MyToolbar tb = diagram.toolbars.get(i);
			 *
			 * JCheckBoxMenuItem menuToolbar = new
			 * JCheckBoxMenuItem(tb.getName(),IconLoader.ico023);
			 * menuToolbar.addActionListener(new ActionListener() { public void
			 * actionPerformed(ActionEvent event) {
			 * tb.setVisible(!tb.isVisible()); doButtons(); } } );
			 *
			 * if (tb.isVisible()) { menuToolbar.setSelected(true); }
			 * menuView.add(menuToolbar); //System.out.println(entry.getKey() +
			 * "-->" + entry.getValue()); }
			 */

			// conditions

			final boolean conditionAny = this.diagram.getSelected() != null && !(this.diagram.getSelected() instanceof CompilationUnit) ;
			final boolean condition = conditionAny
			&& !(getDiagram().getSelected() instanceof JClass) && !(getDiagram()
					.getSelected() instanceof JMethod) && !(getDiagram().getSelected().getParent() instanceof JClass) ;
			//

			//
			final boolean conditionClosable = conditionAny && (getDiagram().getSelected() instanceof JMethod || getDiagram()
					.getSelected() instanceof JClass) && ((RootElement)getDiagram().getSelected()).allowsClose();
			//
			int i = -1;
			boolean conditionCanMoveUp = false;
			boolean conditionCanMoveDown = false;
			if (conditionAny) {
				if (getDiagram().getSelected().getParent() != null) {
					// make sure parent is a subqueue, which is not the case if
					// somebody clicks on a subqueue!
					if (getDiagram().getSelected().getParent().getClass().getSimpleName()
							.equals("Subqueue")) {
						i = ((Subqueue) getDiagram().getSelected().getParent())
						.getIndexOf(getDiagram().getSelected());
						conditionCanMoveUp = i - 1 >= 0;
						conditionCanMoveDown = i + 1 < ((Subqueue) getDiagram()
								.getSelected().getParent()).getSize();
					}
				}
			}

			// undo & redo
			/*
						menuEditUndo.setEnabled(diagram.getRootSelected().canUndo());
						menuEditRedo.setEnabled(diagram.getRootSelected().canRedo());
			 */

// Parse
            this.menuFileImportJava.setEnabled(getDiagram().getParseCapability());

// save
            this.menuFileSave.setEnabled(getDiagram().getProgram().isChanged());

// class
			this.menuDiagramNewClass.setSelected(true);
// method
			this.menuDiagramNewMethod.setSelected(conditionAny);

			this.menuDiagramComment.setSelected(AbstractElement.isE_SHOWCOMMENTS());
			this.menuDiagramAnalyser.setSelected(AbstractElement.isE_ANALYSER());

// elements
			this.menuDiagramAddBeforeInst.setEnabled(condition);
			this.menuDiagramAddBeforeAlt.setEnabled(condition);
			this.menuDiagramAddBeforeCase.setEnabled(condition);
			this.menuDiagramAddBeforeFor.setEnabled(condition);
			this.menuDiagramAddBeforeWhile.setEnabled(condition);
			this.menuDiagramAddBeforeRepeat.setEnabled(condition);
			/*
			 * 2011.03.01 removed:
			 * menuDiagramAddBeforeForever.setEnabled(condition);
			 * 2011.03.01 added: try
			 */
			this.menuDiagramAddBeforeTry.setEnabled(condition);
			this.menuDiagramAddBeforeCall.setEnabled(condition);
			/*
			 * 2011.03.01 removed:
			 * menuDiagramAddBeforeJump.setEnabled(condition);
			 */
			this.menuDiagramAddAfterInst.setEnabled(condition);
			this.menuDiagramAddAfterAlt.setEnabled(condition);
			this.menuDiagramAddAfterCase.setEnabled(condition);
			this.menuDiagramAddAfterFor.setEnabled(condition);
			this.menuDiagramAddAfterWhile.setEnabled(condition);
			this.menuDiagramAddAfterRepeat.setEnabled(condition);
			/*
			 * 2011.03.01 removed:
			 * menuDiagramAddAfterForever.setEnabled(condition);
			 * 2011.03.01 added: try
			 */
			this.menuDiagramAddAfterCall.setEnabled(condition);
			this.menuDiagramAddAfterTry.setEnabled(condition);
			/*
			 * 2011.03.01 removed:
			 * menuDiagramAddAfterJump.setEnabled(condition);
			 */

			// editing
			this.menuDiagramEdit.setEnabled(conditionAny);
			this.menuDiagramDelete.setEnabled(getDiagram().nsdCanCutCopy());
			this.menuDiagramMoveUp.setEnabled(conditionCanMoveUp);
			this.menuDiagramMoveDown.setEnabled(conditionCanMoveDown);

			// copy & paste
			this.menuEditCopy.setEnabled(getDiagram().nsdCanCutCopy());
			this.menuEditCut.setEnabled(getDiagram().nsdCanCutCopy());
			this.menuEditPaste.setEnabled(getDiagram().nsdCanPaste());

			// nice
			this.menuDiagramShowDetails.setSelected(conditionClosable);

			// comments?
			this.menuDiagramComment.setSelected(getDiagram().isCommentsOn());

			// variable hightlighting
			this.menuDiagramMarker.setSelected(AbstractElement.isE_VARHIGHLIGHT());
			/*
			// din
			menuDiagramDIN.setSelected(AbstractElement.E_DIN);
			if (AbstractElement.E_DIN == true) {
				menuDiagramAddBeforeFor.setIcon(IconLoader.ico010);
				menuDiagramAddAfterFor.setIcon(IconLoader.ico015);
			} else {
				menuDiagramAddBeforeFor.setIcon(IconLoader.ico010);
				menuDiagramAddAfterFor.setIcon(IconLoader.ico014);
			}
			 */
			this.menuPreferencesLanguageEnglish.setSelected(getLang().equals(
			"en.txt"));

			this.menuPreferencesOutCodeDefault.setSelected(getOutCoding().equals(
			Charset.defaultCharset().displayName()));

			this.menuPreferencesOutCodeUSACII.setSelected(getOutCoding().equals(
			"US-ASCII"));

			this.menuPreferencesOutCodeLATIN.setSelected(getOutCoding().equals(
			"ISO-8859-1"));

			this.menuPreferencesOutCodeUTF8.setSelected(getOutCoding().equals(
			"UTF-8"));

			this.menuPreferencesOutCodeUTF16.setSelected(getOutCoding().equals(
			"UTF-16"));
//java style  10/05/2015
    this.menuPreferencesOutStyleComments.setSelected(AbstractElement.PROGRAMDOCONTOP);
    this.menuPreferencesOutStylePublic.setSelected(AbstractElement.ADDJAVADOCPUBLIC);
    this.menuPreferencesOutStyleVersion.setSelected(AbstractElement.SETSOURCEVERSION);
    this.menuPreferencesOutStyleExtra.setSelected(AbstractElement.ADDJAVADOCEXTRA);
    this.menuPreferencesOutStyleImage.setEnabled(AbstractElement.ADDJAVADOCEXTRA);
    this.menuPreferencesOutStyleImage.setSelected(AbstractElement.ADDJAVADOCIMAGE);



			// Look and Feel submenu
			// System.out.println("Having: "+UIManager.getLookAndFeel().getName());
			for (i = 0; i < this.menuPreferencesLookAndFeel.getMenuComponentCount(); i++) {
				final JCheckBoxMenuItem mi = (JCheckBoxMenuItem) this.menuPreferencesLookAndFeel
				.getMenuComponent(i);

				// System.out.println("Listing: "+mi.getText());
				if (mi.getText().equals(this.NSDControl.getLookAndFeel())) {
					mi.setSelected(true);
					// System.out.println("Found: "+mi.getText());
				} else {
					mi.setSelected(false);
				}
			}




			// Langauges
			this.menuPreferencesLanguageEnglish.setSelected(getLang().equals(
			"en.txt"));
			this.menuPreferencesLanguageGerman.setSelected(getLang()
					.equals("de.txt"));
			this.menuPreferencesLanguageFrench.setSelected(getLang()
					.equals("fr.txt"));
			this.menuPreferencesLanguageDutch
			.setSelected(getLang().equals("nl.txt"));
			this.menuPreferencesLanguageLuxemburgish.setSelected(getLang().equals(
			"lu.txt"));
			this.menuPreferencesLanguageSpanish.setSelected(getLang().equals(
			"es.txt"));
			this.menuPreferencesLanguagePortugalBrazil.setSelected(getLang().equals(
			"pt_br.txt"));
			this.menuPreferencesLanguageItalian.setSelected(getLang().equals(
			"it.txt"));
			this.menuPreferencesLanguageChinese.setSelected(getLang().equals(
			"cn.txt"));
			this.menuPreferencesLanguageCzech
			.setSelected(getLang().equals("cz.txt"));

			// Recentl file
			this.menuFileOpenRecent.removeAll();
			for (int j = 0; j < getDiagram().recentFiles.size(); ++j) {
				final JMenuItem mi = new JMenuItem(
					 getDiagram().recentFiles.get(j), IconLoader.ico074);
				final String nextFile =  getDiagram().recentFiles.get(j);
				mi.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent event) {
						getDiagram().doOpenNSD(nextFile);
						doButtons();
					}
				});
				this.menuFileOpenRecent.add(mi);
			}

		}
	}

	@Override
	public void updateColors() {
		// nothing to do
	}

	@Override
	public void pan (int x, int y){
		// only for Editor
	}

 public	 Menu(Diagram _diagram, NSDController _NSDControl) {
		super();
		setDiagram(_diagram);
		this.NSDControl = _NSDControl;
		create();
	}

	@Override
	public void savePreferences() {
		// nothing to do
	}

	@Override
	public JFrame getFrame() {
		return this.NSDControl.getFrame();
	}

	/**
	 * @param diagram
	 */
	public void setDiagram(Diagram diagram) {
		this.diagram = diagram;
	}

	/**
	 * @return Diagram
	 */
	public Diagram getDiagram() {
		return this.diagram;
	}
}
