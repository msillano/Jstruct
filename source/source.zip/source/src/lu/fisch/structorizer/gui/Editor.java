/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class represents the basic diagram editor.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.28      First Issue
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		/
 *
 ******************************************************************************************************/
//

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToggleButton;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.Alternative;
import lu.fisch.structorizer.elements.Call;
import lu.fisch.structorizer.elements.CompilationUnit;
import lu.fisch.structorizer.elements.DetectedError;
import lu.fisch.structorizer.elements.For;
import lu.fisch.structorizer.elements.Instruction;
import lu.fisch.structorizer.elements.JClass;
import lu.fisch.structorizer.elements.JMethod;
import lu.fisch.structorizer.elements.Repeat;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.elements.Subqueue;
import lu.fisch.structorizer.elements.Switch;
import lu.fisch.structorizer.elements.Try;
import lu.fisch.structorizer.elements.While;

import com.kobrix.notebook.gui.AKDockLayout;

/**
 *
 */
public class Editor extends JPanel implements NSDController, ComponentListener {

	/**
	 *
	 */
	private static final long serialVersionUID = 5117135717757722593L;

	// Controller
	NSDController NSDControll = null;

	// Toolbars
	protected MyToolbar toolbar = null;

	// Splitpane
	JSplitPane sp;

	// list
	DefaultListModel<DetectedError> errors = new DefaultListModel<DetectedError>();
	protected JList<DetectedError> errorlist = new JList<DetectedError>(this.errors);


	/**
	 *  Panels
	 */
	public Diagram diagram = new Diagram(this);

	// scrollarea
	protected JScrollPane scrollarea = new JScrollPane(this.diagram);
	protected JScrollPane scrolllist = new JScrollPane(this.errorlist);

	// Buttons
	// I/O
	protected JButton btnNew = new JButton(IconLoader.ico001);
	protected JButton btnOpen = new JButton(IconLoader.ico002);
	protected JButton btnSave = new JButton(IconLoader.ico003);
	protected JButton btnFReplace = new JButton(IconLoader.ico083);
	// InsertBefore
	protected JButton btnBeforeInst = new JButton(IconLoader.ico007);
	protected JButton btnBeforeAlt = new JButton(IconLoader.ico008);
	protected JButton btnBeforeFor = new JButton(IconLoader.ico010);
	protected JButton btnBeforeWhile = new JButton(IconLoader.ico010);
	protected JButton btnBeforeRepeat = new JButton(IconLoader.ico011);
	protected JButton btnBeforeCall = new JButton(IconLoader.ico049);
	protected JButton btnBeforeTry = new JButton(IconLoader.ico009);
//	protected JButton btnBeforeJump = new JButton(IconLoader.ico056);
	protected JButton btnBeforeCase = new JButton(IconLoader.ico047);
//	protected JButton btnBeforeForever = new JButton(IconLoader.ico009);
	// InsertAfter
	protected JButton btnAfterInst = new JButton(IconLoader.ico012);
	protected JButton btnAfterAlt = new JButton(IconLoader.ico013);
	protected JButton btnAfterFor = new JButton(IconLoader.ico014);
	protected JButton btnAfterWhile = new JButton(IconLoader.ico015);
	protected JButton btnAfterRepeat = new JButton(IconLoader.ico016);
	protected JButton btnAfterTry = new JButton(IconLoader.ico014);
	protected JButton btnAfterCall = new JButton(IconLoader.ico050);
	// 2011.03.01 removed:
	//	protected JButton btnAfterJump = new JButton(IconLoader.ico055);
	protected JButton btnAfterCase = new JButton(IconLoader.ico048);
//	protected JButton btnAfterForever = new JButton(IconLoader.ico014);
	// undo & redo
	protected JButton btnUndo = new JButton(IconLoader.ico039);
	protected JButton btnRedo = new JButton(IconLoader.ico038);
	// copy & paste
	protected JButton btnCut = new JButton(IconLoader.ico044);
	protected JButton btnCopy = new JButton(IconLoader.ico042);
	protected JButton btnPaste = new JButton(IconLoader.ico043);
	// style
	protected JToggleButton btnShowDetail = new JToggleButton(IconLoader.ico040);
	protected JToggleButton btnNewClass = new JToggleButton(IconLoader.ico021);
	protected JToggleButton btnNewMethod = new JToggleButton(IconLoader.ico022);
//	protected JButton btnAddFunction = new JButton(IconLoader.ico025);
	// editing
	protected JButton btnEdit = new JButton(IconLoader.ico006);
	protected JButton btnDelete = new JButton(IconLoader.ico005);
	protected JButton btnMoveUp = new JButton(IconLoader.ico019);
	protected JButton btnMoveDown = new JButton(IconLoader.ico020);
	// printing
	protected JButton btnPrint = new JButton(IconLoader.ico041);
	// font
	protected JButton btnFontUp = new JButton(IconLoader.ico033);
	protected JButton btnFontDown = new JButton(IconLoader.ico034);
	// copyright
	protected JButton btnAbout = new JButton(IconLoader.ico017);
	// 2011.03.01 removed:
	/*
	protected JButton btnMake = new JButton(IconLoader.ico004);
	protected JButton btnTurtle = new JButton(IconLoader.turtle);
	 */
	// colors
	protected ColorButton btnColor0 = new ColorButton(AbstractElement.color0);
	protected ColorButton btnColor1 = new ColorButton(AbstractElement.color1);
	protected ColorButton btnColor2 = new ColorButton(AbstractElement.color2);
	protected ColorButton btnColor3 = new ColorButton(AbstractElement.color3);
	protected ColorButton btnColor4 = new ColorButton(AbstractElement.color4);
	protected ColorButton btnColor5 = new ColorButton(AbstractElement.color5);
	protected ColorButton btnColor6 = new ColorButton(AbstractElement.color6);
	protected ColorButton btnColor7 = new ColorButton(AbstractElement.color7);
	protected ColorButton btnColor8 = new ColorButton(AbstractElement.color8);
	protected ColorButton btnColor9 = new ColorButton(AbstractElement.color9);

	// Popup menu
	protected JPopupMenu popup = new JPopupMenu();
	protected JMenuItem popupCut = new JMenuItem("Cut", IconLoader.ico044);
	protected JMenuItem popupCopy = new JMenuItem("Copy", IconLoader.ico042);
	protected JMenuItem popupPaste = new JMenuItem("Paste", IconLoader.ico043);
	protected JMenu popupAdd = new JMenu("Add");
	// Submenu of "Add"
	protected JMenu popupAddBefore = new JMenu("Before");
	// Submenus of "Add -> Before"
	protected JMenuItem popupAddBeforeInst = new JMenuItem("Instruction",
			IconLoader.ico007);
	protected JMenuItem popupAddBeforeCall = new JMenuItem("Call",
			IconLoader.ico049);
	protected JMenuItem popupAddBeforeAlt = new JMenuItem("IF statement",
			IconLoader.ico008);
	protected JMenuItem popupAddBeforeCase = new JMenuItem("CASE statement",
			IconLoader.ico047);
	protected JMenuItem popupAddBeforeFor = new JMenuItem("FOR loop",
			IconLoader.ico010);
	protected JMenuItem popupAddBeforeWhile = new JMenuItem("WHILE loop",
			IconLoader.ico010);
	protected JMenuItem popupAddBeforeRepeat = new JMenuItem("DO loop",
			IconLoader.ico011);
	protected JMenuItem popupAddBeforeTry = new JMenuItem("TRY block",
			IconLoader.ico009);
	// 2011.03.01 removed:
	// protected JMenuItem popupAddBeforeForever = new
	// JMenuItem("ENDLESS loop",IconLoader.ico009);
	// protected JMenuItem popupAddBeforeJump = new
	// JMenuItem("Jump",IconLoader.ico056);

	protected JMenu popupAddAfter = new JMenu("After");
	// Submenus of "Add -> After"
	protected JMenuItem popupAddAfterInst = new JMenuItem("Instruction",
			IconLoader.ico012);
	protected JMenuItem popupAddAfterCall = new JMenuItem("Call",
			IconLoader.ico050);
	protected JMenuItem popupAddAfterAlt = new JMenuItem("IF statement",
			IconLoader.ico013);
	protected JMenuItem popupAddAfterCase = new JMenuItem("CASE statement",
			IconLoader.ico048);
	protected JMenuItem popupAddAfterFor = new JMenuItem("FOR loop",
			IconLoader.ico015);
	protected JMenuItem popupAddAfterWhile = new JMenuItem("WHILE loop",
			IconLoader.ico015);
	protected JMenuItem popupAddAfterRepeat = new JMenuItem("DO loop",
			IconLoader.ico016);
	protected JMenuItem popupAddAfterTry = new JMenuItem("TRY block",
			IconLoader.ico014);
	// protected JMenuItem popupAddAfterJump = new
	// JMenuItem("Jump",IconLoader.ico055);
	// protected JMenuItem popupAddAfterForever = new
	// JMenuItem("ENDLESS loop",IconLoader.ico014);
	// protected JMenuItem popupAddFunction = new JMenuItem("Function", IconLoader.ico025);

	protected JMenuItem popupEdit = new JMenuItem("Edit", IconLoader.ico006);
	protected JMenuItem popupDelete = new JMenuItem("Delete", IconLoader.ico005);
	protected JMenuItem popupMoveUp = new JMenuItem("Move up",
			IconLoader.ico019);
	protected JMenuItem popupMoveDown = new JMenuItem("Move down",
			IconLoader.ico020);

	protected JMenuItem popupCopyDiagramPNG = new JMenuItem(
			"Copy selected as PNG image", IconLoader.ico032);
	protected JMenuItem popupCopyDiagramEMF = new JMenuItem(
			"Copy selected as EMF image", IconLoader.ico032);



	private MyToolbar newToolBar(String name) {
		this.toolbar = new MyToolbar();
		this.toolbar.setName(name);
		this.diagram.toolbars.add(this.toolbar);
		this.add(this.toolbar, BorderLayout.NORTH);
		this.toolbar.setFloatable(true);
		this.toolbar.setRollover(true);
		// toolbar.addSeparator();
		return this.toolbar;
	}
	// 2011.03.03 m.s.

	@Override
	public void pan (int x, int y){

// debug  System.out.println("pan x:"+x+" y:"+y);

		this.scrollarea.getHorizontalScrollBar().setValue(x);
		this.scrollarea.getVerticalScrollBar().setValue(y);
	}

	private void create() {

		// Setting up "this" ;-)
		addComponentListener(this);
		setDoubleBuffered(false);

		// Setting up the popup-menu with all submenus ad shortcuts and actions
		this.popup.add(this.popupCut);
		this.popupCut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCutNSD();
				doButtons();
			}
		});

		this.popup.add(this.popupCopy);
		this.popupCopy.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCopyNSD();
				doButtons();
			}
		});

		this.popup.add(this.popupPaste);
		this.popupPaste.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doPasteNSD();
				doButtons();
			}
		});
//debug		System.out.println( "E-create-more");

		this.popup.addSeparator();

		this.popup.add(this.popupAdd);
		this.popupAdd.setIcon(IconLoader.ico018);

		this.popupAdd.add(this.popupAddBefore);
		this.popupAddBefore.setIcon(IconLoader.ico019);

		this.popupAddBefore.add(this.popupAddBeforeInst);
		this.popupAddBeforeInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Instruction(),
						"Add new instruction ...", "", false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeCall);
		this.popupAddBeforeCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Call(), "Add new call ...", "", false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeAlt);
		this.popupAddBeforeAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeCase);
		this.popupAddBeforeCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeFor);
		this.popupAddBeforeFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeWhile);
		this.popupAddBeforeWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, false);
				doButtons();
			}
		});
		// 2011.03.01 removed:

		// popupAddBefore.add(popupAddBeforeForever);
		// popupAddBeforeForever.addActionListener(new ActionListener() { public
		// void actionPerformed(ActionEvent event) { diagram.addNewElement(new
		// Forever(),"Add new ENDLESS loop ...","",false); doButtons(); } } );

		this.popupAddBefore.add(this.popupAddBeforeRepeat);
		this.popupAddBeforeRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, false);
				doButtons();
			}
		});

		this.popupAddBefore.add(this.popupAddBeforeTry);
		this.popupAddBeforeTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, false);
				doButtons();
			}
		});


		// popupAddBefore.add(popupAddBeforeJump);
		// popupAddBeforeJump.addActionListener(new ActionListener() { public
		// void actionPerformed(ActionEvent event) { diagram.addNewElement(new
		// Jump(),"Add new jump ...","",false); doButtons(); } } );

		this.popupAdd.add(this.popupAddAfter);
		this.popupAddAfter.setIcon(IconLoader.ico020);

		this.popupAddAfter.add(this.popupAddAfterInst);
		this.popupAddAfterInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Instruction(),
						"Add new instruction ...", "", true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterCall);
		this.popupAddAfterCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Call(), "Add new call ...", "", true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterAlt);
		this.popupAddAfterAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterCase);
		this.popupAddAfterCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterFor);
		this.popupAddAfterFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterWhile);
		this.popupAddAfterWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, true);
				doButtons();
			}
		});
		// 2011.03.01 removed:

		// popupAddAfter.add(popupAddAfterForever);
		// popupAddAfterForever.addActionListener(new ActionListener() { public
		// void actionPerformed(ActionEvent event) { diagram.addNewElement(new
		// Forever(),"Add new ENDLESS loop ...","",true); doButtons(); } } );

		this.popupAddAfter.add(this.popupAddAfterRepeat);
		this.popupAddAfterRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, true);
				doButtons();
			}
		});

		this.popupAddAfter.add(this.popupAddAfterTry);
		this.popupAddAfterTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, true);
				doButtons();
			}
		});
		/*
		popupAdd.add(popupAddFunction);
		popupAddFunction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.newFunction();
				doButtons();
			}
		});

		 */
		// 2011.03.01 removed:
		// popupAddAfter.add(popupAddAfterJump);
		// popupAddAfterJump.addActionListener(new ActionListener() { public
		// void actionPerformed(ActionEvent event) { diagram.addNewElement(new
		// Jump(),"Add new jump ...","",true); doButtons(); } } );

		this.popup.add(this.popupEdit);
		this.popupEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doEditNSD();
				doButtons();
			}
		});

		this.popup.add(this.popupDelete);
		this.popupDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doDeleteNSD();
				doButtons();
			}
		});

		this.popup.addSeparator();

		this.popup.add(this.popupMoveUp);
		this.popupMoveUp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doMoveUpNSD();
				doButtons();
			}
		});

		this.popup.add(this.popupMoveDown);
		this.popupMoveDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doMoveDownNSD();
				doButtons();
			}
		});

		this.popup.addSeparator();

		this.popup.add(this.popupCopyDiagramEMF);
		this.popupCopyDiagramEMF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCopyToClipboardEMF(true);
				doButtons();
			}
		});

		this.popup.add(this.popupCopyDiagramPNG);
		this.popupCopyDiagramPNG.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCopyToClipboardPNG(true);
				doButtons();
			}
		});


		// add toolbars
		// toolbar.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		setLayout(new AKDockLayout());
		this.toolbar = newToolBar("New, open, save");

		// Setting up the toolbar with all buttons and actions
		// I/O
		// toolbar.addSeparator();
		this.toolbar.add(this.btnNew);
		this.btnNew.setFocusable(false);
		this.btnNew.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doNewNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnOpen);
		this.btnOpen.setFocusable(false);
		this.btnOpen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doOpenNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnSave);
		this.btnSave.setFocusable(false);
		this.btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.fileSaveNSD(false);
				doButtons();
			}
		});

		this.toolbar = newToolBar("Print");

		// printing
		// toolbar.addSeparator();
		this.toolbar.add(this.btnPrint);
		this.btnPrint.setFocusable(false);
		this.btnPrint.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doPrintNSD();
				doButtons();
			}
		});

		this.toolbar = newToolBar("Undo, redo");

		// undo & redo
		// toolbar.addSeparator();
		this.toolbar.add(this.btnUndo);
		this.btnUndo.setFocusable(false);
		this.btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doUndoNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnRedo);
		this.btnRedo.setFocusable(false);
		this.btnRedo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doRedoNSD();
				doButtons();
			}
		});

		this.toolbar = newToolBar("Copy, cut, paste");

		// copy & paste
		// toolbar.addSeparator();
		this.toolbar.add(this.btnCut);
		this.btnCut.setFocusable(false);
		this.btnCut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCutNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnCopy);
		this.btnCopy.setFocusable(false);
		this.btnCopy.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doCopyNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnPaste);
		this.btnPaste.setFocusable(false);
		this.btnPaste.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doPasteNSD();
				doButtons();
			}
		});

		this.toolbar = newToolBar("Find/Replace Text");

		this.toolbar.add(this.btnFReplace);
		this.btnFReplace.setFocusable(false);
		this.btnFReplace.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doReplaceTXT();
				doButtons();
			}
		});


		this.toolbar = newToolBar("Edit, delete, move");

		// editing
		// toolbar.addSeparator();
		this.toolbar.add(this.btnEdit);
		this.btnEdit.setFocusable(false);
		this.btnEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doEditNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnDelete);
		this.btnDelete.setFocusable(false);
		this.btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doDeleteNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnMoveUp);
		this.btnMoveUp.setFocusable(false);
		this.btnMoveUp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doMoveUpNSD();
				doButtons();
			}
		});
		this.toolbar.add(this.btnMoveDown);
		this.btnMoveDown.setFocusable(false);
		this.btnMoveDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doMoveDownNSD();
				doButtons();
			}
		});

		this.toolbar = newToolBar("Method, program");

		// style
		// toolbar.addSeparator();
		this.toolbar.add(this.btnNewClass);
		this.btnNewClass.setFocusable(false);
		this.btnNewClass.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doNewClass();
				doButtons();
			}
		});
		this.toolbar.add(this.btnNewMethod);
		this.btnNewMethod.setFocusable(false);
		this.btnNewMethod.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doNewMethod();
				doButtons();
			}
		});
		// 2011.03.01 added
		/*
		toolbar.add(btnAddFunction);
		btnAddFunction.setFocusable(false);
		btnAddFunction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.newFunction();
				doButtons();
			}
		});
		 */
		this.toolbar = newToolBar("Nice");

		// toolbar.addSeparator();
		this.toolbar.add(this.btnShowDetail);
		this.btnShowDetail.setFocusable(false);
		this.btnShowDetail.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doToggleClose();
				doButtons();
			}
		});

		this.toolbar = newToolBar("Add before ...");
		this.toolbar.setOrientation(SwingConstants.VERTICAL);
		this.add(this.toolbar,BorderLayout.EAST);

		// IsertBefore
		// toolbar.addSeparator();
		this.toolbar.add(this.btnBeforeInst);
		this.btnBeforeInst.setFocusable(false);
		this.btnBeforeInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Instruction(),
						"Add new instruction ...", "", false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeCall);
		this.btnBeforeCall.setFocusable(false);
		this.btnBeforeCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Call(), "Add new call ...", "", false);
				doButtons();
			}
		});

		this.toolbar.add(this.btnBeforeAlt);
		this.btnBeforeAlt.setFocusable(false);
		this.btnBeforeAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeCase);
		this.btnBeforeCase.setFocusable(false);
		this.btnBeforeCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeFor);
		this.btnBeforeFor.setFocusable(false);
		this.btnBeforeFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeWhile);
		this.btnBeforeWhile.setFocusable(false);
		this.btnBeforeWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeRepeat);
		this.btnBeforeRepeat.setFocusable(false);
		this.btnBeforeRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, false);
				doButtons();
			}
		});
		this.toolbar.add(this.btnBeforeTry);
		this.btnBeforeTry.setFocusable(false);
		this.btnBeforeTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, false);
				doButtons();
			}
		});
		// 2011.03.01 removed:
		/*
		toolbar.add(btnBeforeForever);
		btnBeforeForever.setFocusable(false);
		btnBeforeForever.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.addNewElement(new Forever(),
						"Add new ENDLESS loop ...", "", false);
				doButtons();
			}
		});
		 */
		/*
		toolbar.add(btnBeforeJump);
		btnBeforeJump.setFocusable(false);
		btnBeforeJump.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.addNewElement(new Jump(), "Add new jump ...", "", false);
				doButtons();
			}
		});
		 */
		this.toolbar = newToolBar("Add after ...");
		 this.toolbar.setOrientation(SwingConstants.VERTICAL);
		 this.add(this.toolbar,BorderLayout.EAST);

		// IsertAfter
		// toolbar.addSeparator();
		this.toolbar.add(this.btnAfterInst);
		this.btnAfterInst.setFocusable(false);
		this.btnAfterInst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Instruction(),
						"Add new instruction ...", "", true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterCall);
		this.btnAfterCall.setFocusable(false);
		this.btnAfterCall.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Call(), "Add new call ...", "", true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterAlt);
		this.btnAfterAlt.setFocusable(false);
		this.btnAfterAlt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Alternative(),
						"Add new IF statement ...", AbstractElement.preAlt, true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterCase);
		this.btnAfterCase.setFocusable(false);
		this.btnAfterCase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Switch(), "Add new CASE statement ...",
						AbstractElement.preCase, true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterFor);
		this.btnAfterFor.setFocusable(false);
		this.btnAfterFor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new For(), "Add new FOR loop ...",
						AbstractElement.preFor, true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterWhile);
		this.btnAfterWhile.setFocusable(false);
		this.btnAfterWhile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new While(), "Add new WHILE loop ...",
						AbstractElement.preWhile, true);
				doButtons();
			}
		});
		this.toolbar.add(this.btnAfterRepeat);
		this.btnAfterRepeat.setFocusable(false);
		this.btnAfterRepeat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Repeat(), "Add new DO loop ...",
						AbstractElement.preRepeat, true);
				doButtons();
			}
		});

		this.toolbar.add(this.btnAfterTry);
		this.btnAfterTry.setFocusable(false);
		this.btnAfterTry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAddNewElement(new Try(), "Add new TRY block ...",
						AbstractElement.preTry, true);
				doButtons();
			}
		});


		// 2011.03.01 removed:
		/*
		toolbar.add(btnAfterForever);
		btnAfterForever.setFocusable(false);
		btnAfterForever.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.addNewElement(new Forever(),
						"Add new ENDLESS loop ...", "", true);
				doButtons();
			}
		});
		 */
		// 2011.03.01 removed:
		/*
		 toolbar.add(btnAfterJump);
		btnAfterJump.setFocusable(false);
		btnAfterJump.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.addNewElement(new Jump(), "Add new jump ...", "", true);
				doButtons();
			}
		});
		 */
		this.toolbar = newToolBar("Colors ...");

		// Colors
		// toolbar.addSeparator();
		this.toolbar.add(this.btnColor0);
		this.toolbar.add(this.btnColor1);
		this.toolbar.add(this.btnColor2);
		this.toolbar.add(this.btnColor3);
		this.toolbar.add(this.btnColor4);
		this.toolbar.add(this.btnColor5);
		this.toolbar.add(this.btnColor6);
		this.toolbar.add(this.btnColor7);
		this.toolbar.add(this.btnColor8);
		this.toolbar.add(this.btnColor9);
		this.btnColor0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor0.getColor());
				doButtons();
			}
		});
		this.btnColor1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor1.getColor());
				doButtons();
			}
		});
		this.btnColor2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor2.getColor());
				doButtons();
			}
		});
		this.btnColor3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor3.getColor());
				doButtons();
			}
		});
		this.btnColor4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor4.getColor());
				doButtons();
			}
		});
		this.btnColor5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor5.getColor());
				doButtons();
			}
		});
		this.btnColor6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor6.getColor());
				doButtons();
			}
		});
		this.btnColor7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor7.getColor());
				doButtons();
			}
		});
		this.btnColor8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor8.getColor());
				doButtons();
			}
		});
		this.btnColor9.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doSetColor(Editor.this.btnColor9.getColor());
				doButtons();
			}
		});
		this.btnColor0.setFocusable(false);
		this.btnColor1.setFocusable(false);
		this.btnColor2.setFocusable(false);
		this.btnColor3.setFocusable(false);
		this.btnColor4.setFocusable(false);
		this.btnColor5.setFocusable(false);
		this.btnColor6.setFocusable(false);
		this.btnColor7.setFocusable(false);
		this.btnColor8.setFocusable(false);
		this.btnColor9.setFocusable(false);

		this.toolbar = newToolBar("About");
/*
		// About
		// toolbar.addSeparator();
		this.toolbar.add(this.btnAbout);
		this.btnAbout.setFocusable(false);
		this.btnAbout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doAbout();
			}
		});
*/
		// 2011.03.01 removed:

		/*
		toolbar = newToolBar("Turtle, interprete");

		// Turtle
		// toolbar.addSeparator();
		toolbar.add(btnTurtle);
		btnTurtle.setFocusable(false);
		btnTurtle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.goTurtle();
			}
		});
		toolbar.add(btnMake);
		btnMake.setFocusable(false);
		btnMake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				diagram.goRun();
			}
		});
		 */
		this.toolbar = newToolBar("Font ...");

		// Font
		// toolbar.addSeparator();
		this.toolbar.add(this.btnFontUp);
		this.btnFontUp.setFocusable(false);
		this.btnFontUp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doFontUp();
				doButtons();
			}
		});
		this.toolbar.add(this.btnFontDown);
		this.btnFontDown.setFocusable(false);
		this.btnFontDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				Editor.this.diagram.doFontDown();
				doButtons();
			}
		});

		this.sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		this.add(this.sp, BorderLayout.CENTER);
		this.sp.setBorder(BorderFactory.createEmptyBorder());
		this.sp.setResizeWeight(0.99);
		this.sp.setDividerSize(5);

		// add panels
		// get container object
		// Container container = this;
		// container.add(scrollarea,AKDockLayout.CENTER);

		this.sp.add(this.scrollarea);
		this.scrollarea.getViewport().putClientProperty("EnableWindowBlit",
				Boolean.TRUE);
		this.scrollarea.setWheelScrollingEnabled(true);
		this.scrollarea.setDoubleBuffered(true);
		this.scrollarea.setBorder(BorderFactory.createEmptyBorder());
		this.scrollarea.setViewportView(this.diagram);
		// scrollarea.getViewport().setBackingStoreEnabled(true);

		// container.add(scrolllist,AKDockLayout.SOUTH);
		this.sp.add(this.scrolllist);
		this.scrolllist.setWheelScrollingEnabled(true);
		this.scrolllist.setDoubleBuffered(true);
		this.scrolllist.setBorder(BorderFactory.createEmptyBorder());
		this.scrolllist.setViewportView(this.errorlist);
		this.scrolllist.setPreferredSize(new Dimension(0, 50));

		this.errorlist.setLayoutOrientation(JList.VERTICAL);
		this.errorlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		this.errorlist.addMouseListener(this.diagram);

		// diagram.setOpaque(true);
		this.diagram.addMouseListener(new PopupListener());

		// doButtons();
		// container.validate();
	}

	@Override
	public void doButtons() {
		if (this.NSDControll != null) {
			this.NSDControll.doButtons();
		}
	}

	@Override
	public void doButtonsLocal() {
		this.scrollarea.setViewportView(this.diagram);

		// conditions
		final boolean conditionAny = this.diagram.getSelected() != null && !(this.diagram.getSelected() instanceof CompilationUnit) ;
		final boolean condition = conditionAny
		&& !(this.diagram.getSelected() instanceof JClass)
		&& !(this.diagram.getSelected() instanceof JMethod)
		&& !(this.diagram.getSelected().getParent() instanceof JClass);
		/*
		boolean conditionClosable = (conditionAny && ((diagram.getSelected() instanceof JMethod) || (diagram
				.getSelected() instanceof JClass)) && !(diagram
						.getSelected().parent instanceof CompilationUnit));
		 */
		final boolean conditionClosable = conditionAny && (this.diagram.getSelected() instanceof JMethod || this.diagram
				.getSelected() instanceof JClass) && ((RootElement)this.diagram.getSelected()).allowsClose();
		//
		final boolean conditionNew = this.diagram.getSelected()== null ||
	    	this.diagram.getSelected() instanceof JClass ||
		    this.diagram.getSelected() instanceof CompilationUnit;
		//
		int i = -1;
		boolean conditionCanMoveUp = false;
		boolean conditionCanMoveDown = false;
		if (this.diagram.getSelected() != null) {
			if (this.diagram.getSelected().getParent() != null) {
				// make shure parent is a subqueue, which is not the case if
				// somebody clicks on a subqueue!
				if (this.diagram.getSelected().getParent().getClass().getSimpleName()
						.equals("Subqueue")) {
					i = ((Subqueue) this.diagram.getSelected().getParent())
					.getIndexOf(this.diagram.getSelected());
					conditionCanMoveUp = i - 1 >= 0;
					conditionCanMoveDown = i + 1 < ((Subqueue) this.diagram
							.getSelected().getParent()).getSize();
				}
			}
		}

// save
        this.btnSave.setEnabled(this.diagram.getProgram().isChanged());

// TODO verify
		// undo & redo
		if (this.diagram.getSelected() != null)
			if (this.diagram.getRootSelected() != null)
			{
				this.btnUndo.setEnabled(this.diagram.getRootSelected().canUndo());
				this.btnRedo.setEnabled(this.diagram.getRootSelected().canRedo());
			}
			else{
				this.btnUndo.setEnabled(false);
				this.btnRedo.setEnabled(false);
			}
		// elements
		this.btnBeforeInst.setEnabled(condition);
		this.btnBeforeAlt.setEnabled(condition);
		this.btnBeforeCase.setEnabled(condition);
		this.btnBeforeFor.setEnabled(condition);
		this.btnBeforeWhile.setEnabled(condition);
		this.btnBeforeRepeat.setEnabled(condition);
		this.btnBeforeTry.setEnabled(condition);
		// 2011.03.01 removed:
//		btnBeforeForever.setEnabled(condition);
		this.btnBeforeCall.setEnabled(condition);
//		btnBeforeJump.setEnabled(condition);
		this.btnAfterInst.setEnabled(condition);
		this.btnAfterAlt.setEnabled(condition);
		this.btnAfterCase.setEnabled(condition);
		this.btnAfterFor.setEnabled(condition);
		this.btnAfterWhile.setEnabled(condition);
		this.btnAfterRepeat.setEnabled(condition);
		this.btnAfterTry.setEnabled(condition);
//		btnAfterForever.setEnabled(condition);
		this.btnAfterCall.setEnabled(condition);
//		btnAfterJump.setEnabled(condition);
		this.popupAddBeforeInst.setEnabled(condition);
		this.popupAddBeforeAlt.setEnabled(condition);
		this.popupAddBeforeCase.setEnabled(condition);
		this.popupAddBeforeFor.setEnabled(condition);
		this.popupAddBeforeWhile.setEnabled(condition);
		this.popupAddBeforeRepeat.setEnabled(condition);
		this.popupAddBeforeTry.setEnabled(condition);
		// 2011.03.01 removed:
		// popupAddBeforeForever.setEnabled(condition);
		this.popupAddBeforeCall.setEnabled(condition);
		// popupAddBeforeJump.setEnabled(condition);
		this.popupAddAfterInst.setEnabled(condition);
		this.popupAddAfterAlt.setEnabled(condition);
		this.popupAddAfterCase.setEnabled(condition);
		this.popupAddAfterFor.setEnabled(condition);
		this.popupAddAfterWhile.setEnabled(condition);
		this.popupAddAfterRepeat.setEnabled(condition);
		this.popupAddAfterTry.setEnabled(condition);
		// popupAddAfterForever.setEnabled(condition);
		this.popupAddAfterCall.setEnabled(condition);
		// popupAddAfterJump.setEnabled(condition);

		// colors
		this.btnColor0.setEnabled(conditionAny);
		this.btnColor1.setEnabled(conditionAny);
		this.btnColor2.setEnabled(conditionAny);
		this.btnColor3.setEnabled(conditionAny);
		this.btnColor4.setEnabled(conditionAny);
		this.btnColor5.setEnabled(conditionAny);
		this.btnColor6.setEnabled(conditionAny);
		this.btnColor7.setEnabled(conditionAny);
		this.btnColor8.setEnabled(conditionAny);
		this.btnColor9.setEnabled(conditionAny);

		// editing
		this.btnEdit.setEnabled(conditionAny);
		this.btnDelete.setEnabled(this.diagram.nsdCanCutCopy());
		this.btnMoveUp.setEnabled(conditionCanMoveUp);
		this.btnMoveDown.setEnabled(conditionCanMoveDown);
		this.popupEdit.setEnabled(conditionAny);
		this.popupDelete.setEnabled(condition);
		this.popupMoveUp.setEnabled(conditionCanMoveUp);
		this.popupMoveDown.setEnabled(conditionCanMoveDown);

		// copy & paste
		this.btnCopy.setEnabled(this.diagram.nsdCanCutCopy());
		this.btnCut.setEnabled(this.diagram.nsdCanCutCopy());
		this.btnPaste.setEnabled(this.diagram.nsdCanPaste());
		this.popupCopy.setEnabled(this.diagram.nsdCanCutCopy());
		this.popupCut.setEnabled(this.diagram.nsdCanCutCopy());
		this.popupPaste.setEnabled(this.diagram.nsdCanPaste());

		// style
		this.btnShowDetail.setSelected(conditionClosable);
		//
		this.btnNewClass.setEnabled(conditionNew);
		this.btnNewMethod.setEnabled(conditionNew);

		// DIN
//		if (AbstractElement.E_DIN == true) {
		this.btnBeforeFor.setIcon(IconLoader.ico010);
		this.btnAfterFor.setIcon(IconLoader.ico015);
		this.popupAddBeforeFor.setIcon(IconLoader.ico010);
		this.popupAddAfterFor.setIcon(IconLoader.ico015);
		/*		} else {
			btnBeforeFor.setIcon(IconLoader.ico009);
			btnAfterFor.setIcon(IconLoader.ico014);
			popupAddBeforeFor.setIcon(IconLoader.ico009);
			popupAddAfterFor.setIcon(IconLoader.ico014);
		}
		 */
		// scrollarea.revalidate();
		// scrollarea.setViewportView(diagram);

		// analyser

		if (AbstractElement.isE_ANALYSER() == true) {
			if (this.sp.getDividerSize() == 0) {
				this.sp.remove(this.scrolllist);
				this.sp.add(this.scrolllist);
			}
			this.scrolllist.setVisible(true);
			this.scrolllist.setViewportView(this.errorlist);
			this.sp.setDividerSize(5);
			this.scrolllist.revalidate();
		} else {
			this.sp.remove(this.scrolllist);
			this.sp.setDividerSize(0);
		}

		//
		/*
		 * for(int j=0;j<diagram.toolbars.size();j++) { MyToolbar tb =
		 * diagram.toolbars.get(j);
		 *
		 * this.remove(tb); if(tb.isVisible()) this.add(tb,AKDockLayout.NORTH);
		 * //else this.remove(tb); }
		 */

	}

	@Override
	public void updateColors() {
		this.btnColor0.setColor(AbstractElement.color0);
		this.btnColor1.setColor(AbstractElement.color1);
		this.btnColor2.setColor(AbstractElement.color2);
		this.btnColor3.setColor(AbstractElement.color3);
		this.btnColor4.setColor(AbstractElement.color4);
		this.btnColor5.setColor(AbstractElement.color5);
		this.btnColor6.setColor(AbstractElement.color6);
		this.btnColor7.setColor(AbstractElement.color7);
		this.btnColor8.setColor(AbstractElement.color8);
		this.btnColor9.setColor(AbstractElement.color9);
	}

	@Override
	public void setLangLocal(String _langfile) {
		LangDialog.setLang(this, this.NSDControll.getLang());
	}

	@Override
	public void setLang(String _langfile) {
		this.NSDControll.setLang(_langfile);
	}

	@Override
	public String getLang() {
		return this.NSDControll.getLang();
	}

	@Override
	public String getOutCoding() {
		return this.NSDControll.getOutCoding();
	}


	@Override
	public void setOutCoding(String outCoding) {
		this.NSDControll.setOutCoding(outCoding);
	}




  public  Editor() {
		super();
		this.NSDControll = null;
		create();
	}

  public  Editor(NSDController _NSDControll) {
		super();
		this.NSDControll = _NSDControll;
		create();
	}

	@Override
	public JFrame getFrame() {
		return this.NSDControll.getFrame();
	}

	// PopupListener Methods
	class PopupListener extends MouseAdapter {

		@Override
		public void mouseReleased(MouseEvent e) {
			if (e.isPopupTrigger()) {
//test     System.out.println("Pop-UP Mouse Relased event");
					showPopup(e);
			}
		}

		private void showPopup(MouseEvent e) {
// context menu popup, but not for the background (program element)
                final AbstractElement ele = Editor.this.diagram.getProgram().selectElementByCoord(e.getX(), e.getY(), true);
                if(ele != null && ele != Editor.this.diagram.getProgram()) {
                	    if (Editor.this.diagram.getSelected() != ele){
                	    	Editor.this.diagram.mouseActionSelectElement(e);
                	    }
			        	Editor.this.popup.show(e.getComponent(), e.getX(), e.getY());
                }

		}
	}

	// ComponentListener Methods
	@Override
	public void componentHidden(ComponentEvent e) {
		// nothing to do
	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// componentResized(e);
	}

	@Override
	public void componentResized(ComponentEvent e) {
		/*
		 * int maxWidth = 0; for(int i=0;i<toolbar.getComponentCount();i++) {
		 * maxWidth+=toolbar.getComponent(i).getWidth(); }
		 *
		 * if(toolbar.getWidth()!=0) { int prefI = maxWidth/toolbar.getWidth();
		 * if (maxWidth % toolbar.getWidth() > 0 ) { prefI++; }
		 *
		 * //System.out.println(prefI);
		 *
		 * toolbar.setPreferredSize(new Dimension(toolbar.getWidth(),
		 * Math.round(prefI)*26+6 )); } toolbar.validate(); /*
		 */
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// componentResized(e);
	}

	@Override
	public void setLookAndFeel(String _laf) {
		// nothing to do
    }

	@Override
	public String getLookAndFeel() {
		return null;
	}

	@Override
	public void savePreferences() {
		this.NSDControll.savePreferences();
	}

}
