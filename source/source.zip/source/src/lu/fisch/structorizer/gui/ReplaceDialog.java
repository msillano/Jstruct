package lu.fisch.structorizer.gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 *
 */
public class ReplaceDialog extends LangDialog {

	private static final long serialVersionUID = 7220823318905914155L;
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JLabel lblOld;
	protected JLabel lblNew;
	protected JTextField edtOld;
	protected JTextField edtNew;
	protected JPanel buttonBar;
	protected JButton btnOK;
	protected JCheckBox btnTxt;
	protected JCheckBox btnComm;


	/**
	 * @param owner
	 */
	public ReplaceDialog(Frame owner) {
		super(owner);
		setModal(true);
		initComponents();
	}

	private void initComponents() {
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();

		this.lblOld = new JLabel();
		this.lblNew = new JLabel();
		this.edtOld = new JTextField();
		this.edtNew = new JTextField();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();
		this.btnTxt = new JCheckBox();
		this.btnComm = new JCheckBox();

		//======== this ========
		setModal(true);
		// set windows size
		setResizable(false);
		setTitle("Find-replace words");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new GridLayout(4, 2, 8, 8));
//			contentPanel.add(lblNothing);

				//---- lblOld ----
				this.lblOld.setText("Find");
				this.contentPanel.add(this.lblOld);
				this.contentPanel.add(this.edtOld);

				//---- lblNew ----
				this.lblNew.setText("Replace");
				this.contentPanel.add(this.lblNew);
				this.contentPanel.add(this.edtNew);
				// ------ Check
				this.btnTxt.setText("Code");
				this.btnComm.setText("Coments");
				this.contentPanel.add(this.btnTxt);
				this.contentPanel.add(this.btnComm);


			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

				//---- okButton ----
				this.btnOK.setText("OK");
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());

		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) { /* */ }
			@Override
			public void keyTyped(KeyEvent kevt)  { /* */ }
		};
		this.edtOld.addKeyListener(keyListener);
		this.edtNew.addKeyListener(keyListener);
		this.btnOK.addKeyListener(keyListener);

		// add the ACTION-listeners
		final ActionListener actionListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				setVisible(false);
			}
		};
		this.btnOK.addActionListener(actionListener);
	}
}
