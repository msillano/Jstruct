/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This class launches the analyse process and shows items
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2008.04.18      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:
 *
 ******************************************************************************************************///

import lu.fisch.structorizer.elements.*;

import java.util.*;


import javax.swing.*;

public class Analyser extends Thread
{
	private JMethod root = null;
	private JList errorlist = null;
	private DefaultListModel<DetectedError> errors = null;

	private static boolean running = false;

@SuppressWarnings("unchecked")
	public Analyser(JMethod _root, JList _errorlist)
	{
		super();

//debug System.out.println("Setup ...");
		root=_root;
		errorlist=_errorlist;
		errors =  (DefaultListModel<DetectedError>) _errorlist.getModel();
	}

	public void run()
	{
		// make shure the analyser is not yet running
		if(running==false)
		{
			running=true;
//debug  System.out.println("Working ...");
			Vector<DetectedError> vec = new Vector<DetectedError>();
//			Vector<DetectedError> vec = root.analyse(vec);
		    vec = root.analyze(vec);
			errors.clear();

			for(int i=0;i<vec.size();i++)
			{
//				errors.addElement((DetectedError) vec.get(i));
				errors.addElement((DetectedError) vec.get(i));

			}

			errorlist.repaint();
			errorlist.validate();
			running=false;
		}
//debug       else System.out.println("RUNNING");
	}
}
