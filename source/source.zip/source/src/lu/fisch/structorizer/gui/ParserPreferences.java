/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the parser preferences dialog window.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2008.01.03      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		I used JFormDesigner to desin this window graphically.
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;



/**
 * @author Robert Fisch
 */
public class ParserPreferences extends LangDialog {


	/**
	 * 
	 */
	private static final long serialVersionUID = -3642634148683691377L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JLabel lblNothing;
	protected JLabel lblPre;
	protected JLabel lblPost;
	protected JLabel lblNothing2;
	protected JLabel lblNothing3;
	protected JLabel lblInput;
	protected JLabel lblOutput;
	protected JLabel lblAlt;
	protected JTextField edtAltPre;
	protected JTextField edtAltPost;
	protected JTextField edtInput;
	protected JTextField edtOutput;
	protected JLabel lblCase;
	protected JTextField edtCasePre;
	protected JTextField edtCasePost;
	protected JLabel lblFor;
	protected JTextField edtForPre;
	protected JTextField edtForPost;
	protected JLabel lblWhile;
	protected JTextField edtWhilePre;
	protected JTextField edtWhilePost;
	protected JLabel lblRepeat;
	protected JTextField edtRepeatPre;
	protected JTextField edtRepeatPost;
	protected JPanel buttonBar;
	protected JButton btnOK;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	/*public ParserPreferences()
	{
		super();
		setModal(true);
		initComponents();
	}*/

	/**
	 * @param owner
	 */
	public ParserPreferences(Frame owner) {
		super(owner);
		setModal(true);
		initComponents();
	}

	/*public ParserPreferences(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.lblNothing = new JLabel();
		this.lblNothing2 = new JLabel();
		this.lblNothing3 = new JLabel();
		this.lblPre = new JLabel();
		this.lblPost = new JLabel();
		this.lblInput = new JLabel();
		this.lblOutput = new JLabel();
		this.lblAlt = new JLabel();
		this.edtAltPre = new JTextField();
		this.edtAltPost = new JTextField();
		this.lblCase = new JLabel();
		this.edtCasePre = new JTextField();
		this.edtCasePost = new JTextField();
		this.lblFor = new JLabel();
		this.edtForPre = new JTextField();
		this.edtForPost = new JTextField();
		this.lblWhile = new JLabel();
		this.edtWhilePre = new JTextField();
		this.edtWhilePost = new JTextField();
		this.lblRepeat = new JLabel();
		this.edtRepeatPre = new JTextField();
		this.edtRepeatPost = new JTextField();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();
		this.edtInput = new JTextField();
		this.edtOutput = new JTextField();

		//======== this ========
		setModal(true);
		setResizable(false);
		setTitle("Parser Preferences");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			/*dialogPane.setBorder(new javax.swing.border.CompoundBorder(
				new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
					"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
					javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
					java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new GridLayout(8, 3, 8, 8));
				this.contentPanel.add(this.lblNothing);

				//---- lblPre ----
				this.lblPre.setText("Pre");
				this.contentPanel.add(this.lblPre);

				//---- lblPost ----
				this.lblPost.setText("Post");
				this.contentPanel.add(this.lblPost);

				//---- lblAlt ----
				this.lblAlt.setText("IF statement");
				this.contentPanel.add(this.lblAlt);
				this.contentPanel.add(this.edtAltPre);
				this.contentPanel.add(this.edtAltPost);

				//---- lblCase ----
				this.lblCase.setText("CASE statement");
				this.contentPanel.add(this.lblCase);
				this.contentPanel.add(this.edtCasePre);
				this.contentPanel.add(this.edtCasePost);

				//---- lblFor ----
				this.lblFor.setText("FOR loop");
				this.contentPanel.add(this.lblFor);
				this.contentPanel.add(this.edtForPre);
				this.contentPanel.add(this.edtForPost);

				//---- lblWhile ----
				this.lblWhile.setText("WHILE loop");
				this.contentPanel.add(this.lblWhile);
				this.contentPanel.add(this.edtWhilePre);
				this.contentPanel.add(this.edtWhilePost);

				//---- lblRepeat ----
				this.lblRepeat.setText("DO loop");
				this.contentPanel.add(this.lblRepeat);
				this.contentPanel.add(this.edtRepeatPre);
				this.contentPanel.add(this.edtRepeatPost);

				this.contentPanel.add(this.lblNothing2);
				this.lblInput.setText("Input");
				this.contentPanel.add(this.lblInput);
				this.lblOutput.setText("Output");
				this.contentPanel.add(this.lblOutput);

				this.contentPanel.add(this.lblNothing3);
				this.contentPanel.add(this.edtInput);
				this.contentPanel.add(this.edtOutput);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

				//---- okButton ----
				this.btnOK.setText("OK");
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// BOB thinks

		// add the LIST-listeners
		// add the KEY-listeners
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				// nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
				// nothing to do
			}
		};
		this.edtAltPre.addKeyListener(keyListener);
		this.edtAltPost.addKeyListener(keyListener);
		this.edtCasePre.addKeyListener(keyListener);
		this.edtCasePost.addKeyListener(keyListener);
		this.edtForPre.addKeyListener(keyListener);
		this.edtForPost.addKeyListener(keyListener);
		this.edtWhilePre.addKeyListener(keyListener);
		this.edtWhilePost.addKeyListener(keyListener);
		this.edtRepeatPre.addKeyListener(keyListener);
		this.edtRepeatPost.addKeyListener(keyListener);
		this.edtInput.addKeyListener(keyListener);
		this.edtOutput.addKeyListener(keyListener);
		this.btnOK.addKeyListener(keyListener);

		// add the ACTION-listeners
		final ActionListener actionListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				setVisible(false);
			}
		};
		this.btnOK.addActionListener(actionListener);
	}

}
