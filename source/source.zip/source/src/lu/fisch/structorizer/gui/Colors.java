/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the color preferences dialog.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.31      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		I used JFormDesigner to desin this window graphically.
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

/*
 * Created by JFormDesigner on Mon Dec 31 20:03:51 CET 2007
 */



/**
 * @author Robert Fisch
 */
public class Colors extends LangDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 142813415067135631L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JLabel lblColor0;
	protected JPanel color0;
	protected JLabel lblColor1;
	protected JPanel color1;
	protected JLabel lblColor2;
	protected JPanel color2;
	protected JLabel lblColor3;
	protected JPanel color3;
	protected JLabel lblColor4;
	protected JPanel color4;
	protected JLabel lblColor5;
	protected JPanel color5;
	protected JLabel lblColor6;
	protected JPanel color6;
	protected JLabel lblColor7;
	protected JPanel color7;
	protected JLabel lblColor8;
	protected JPanel color8;
	protected JLabel lblColor9;
	protected JPanel color9;
	protected JPanel buttonBar;
	protected JButton btnOK;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	private Frame frame = null;

	/*public Colors()
	{
		super();
		setModal(true);
		initComponents();
	}*/

	 Colors(Frame owner)
	{
		super(owner);
		this.frame = owner;
		setModal(true);
		initComponents();
	}

	/*public Colors(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.lblColor0 = new JLabel();
		this.color0 = new JPanel();
		this.lblColor1 = new JLabel();
		this.color1 = new JPanel();
		this.lblColor2 = new JLabel();
		this.color2 = new JPanel();
		this.lblColor3 = new JLabel();
		this.color3 = new JPanel();
		this.lblColor4 = new JLabel();
		this.color4 = new JPanel();
		this.lblColor5 = new JLabel();
		this.color5 = new JPanel();
		this.lblColor6 = new JLabel();
		this.color6 = new JPanel();
		this.lblColor7 = new JLabel();
		this.color7 = new JPanel();
		this.lblColor8 = new JLabel();
		this.color8 = new JPanel();
		this.lblColor9 = new JLabel();
		this.color9 = new JPanel();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();

		//======== this ========
		setResizable(false);
		setTitle("Color Preferences");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			/*
			dialogPane.setBorder(new javax.swing.border.CompoundBorder(
				new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
					"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
					javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
					java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new GridLayout(10, 2, 8, 8));

				//---- lblColor0 ----
				this.lblColor0.setText("Color 0");
				this.contentPanel.add(this.lblColor0);

				//======== color0 ========
				{
					this.color0.setBackground(Color.white);
					this.color0.setBorder(new LineBorder(Color.black));
					this.color0.setPreferredSize(new Dimension(100, 7));
					this.color0.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color0);

				//---- lblColor1 ----
				this.lblColor1.setText("Color 1");
				this.contentPanel.add(this.lblColor1);

				//======== color1 ========
				{
					this.color1.setBackground(new Color(255, 204, 204));
					this.color1.setBorder(new LineBorder(Color.black));
					this.color1.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color1);

				//---- lblColor2 ----
				this.lblColor2.setText("Color 2");
				this.contentPanel.add(this.lblColor2);

				//======== color2 ========
				{
					this.color2.setBackground(new Color(255, 255, 153));
					this.color2.setBorder(new LineBorder(Color.black));
					this.color2.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color2);

				//---- lblColor3 ----
				this.lblColor3.setText("Color 3");
				this.contentPanel.add(this.lblColor3);

				//======== color3 ========
				{
					this.color3.setBackground(new Color(153, 255, 153));
					this.color3.setBorder(new LineBorder(Color.black));
					this.color3.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color3);

				//---- lblColor4 ----
				this.lblColor4.setText("Color 4");
				this.contentPanel.add(this.lblColor4);

				//======== color4 ========
				{
					this.color4.setBackground(new Color(153, 204, 255));
					this.color4.setBorder(new LineBorder(Color.black));
					this.color4.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color4);

				//---- lblColor5 ----
				this.lblColor5.setText("Color 5");
				this.contentPanel.add(this.lblColor5);

				//======== color5 ========
				{
					this.color5.setBackground(new Color(153, 153, 255));
					this.color5.setBorder(new LineBorder(Color.black));
					this.color5.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color5);

				//---- lblColor6 ----
				this.lblColor6.setText("Color 6");
				this.contentPanel.add(this.lblColor6);

				//======== color6 ========
				{
					this.color6.setBackground(new Color(255, 153, 255));
					this.color6.setBorder(new LineBorder(Color.black));
					this.color6.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color6);

				//---- lblColor7 ----
				this.lblColor7.setText("Color 7");
				this.contentPanel.add(this.lblColor7);

				//======== color7 ========
				{
					this.color7.setBackground(new Color(204, 204, 204));
					this.color7.setBorder(new LineBorder(Color.black));
					this.color7.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color7);

				//---- lblColor8 ----
				this.lblColor8.setText("Color 8");
				this.contentPanel.add(this.lblColor8);

				//======== color8 ========
				{
					this.color8.setBackground(new Color(255, 153, 102));
					this.color8.setBorder(new LineBorder(Color.black));
					this.color8.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color8);

				//---- lblColor9 ----
				this.lblColor9.setText("Color 9");
				this.contentPanel.add(this.lblColor9);

				//======== color9 ========
				{
					this.color9.setBackground(new Color(153, 102, 255));
					this.color9.setBorder(new LineBorder(Color.black));
					this.color9.setLayout(new BorderLayout());
				}
				this.contentPanel.add(this.color9);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

				//---- btnOK ----
				this.btnOK.setText("OK");
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// Bob-thinks
		// add the KEY-listeners
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				// nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
				// nothing to do
			}
		};
		this.btnOK.addKeyListener(keyListener);

		// add the ACTION-listeners
		final ActionListener actionListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				setVisible(false);
			}
		};
		this.btnOK.addActionListener(actionListener);

		final Frame fframe = this.frame;
		final MouseListener mouseListener = new MouseListener()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				final ColorChooser chooser = new ColorChooser(fframe);
				final Point p = getLocationOnScreen();
				chooser.setLocation(p.x+(getWidth()-chooser.getWidth())/2,
						p.y+(getHeight()-chooser.getHeight())/2);

				chooser.setColor(((JPanel) e.getSource()).getBackground());
				chooser.setLang(Colors.this.langFile);

				if(chooser.execute()==true)
				{
					((JPanel) e.getSource()).setBackground(chooser.getColor());
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// nothing to do
				}
			@Override
			public void mouseEntered(MouseEvent e) {
				// nothing to do
				}
			@Override
			public void mouseReleased(MouseEvent e) {
				// nothing to do
				}
			@Override
			public void mousePressed(MouseEvent e) {
				// nothing to do
				}
		};
		this.color0.addMouseListener(mouseListener);
		this.color1.addMouseListener(mouseListener);
		this.color2.addMouseListener(mouseListener);
		this.color3.addMouseListener(mouseListener);
		this.color4.addMouseListener(mouseListener);
		this.color5.addMouseListener(mouseListener);
		this.color6.addMouseListener(mouseListener);
		this.color7.addMouseListener(mouseListener);
		this.color8.addMouseListener(mouseListener);
		this.color9.addMouseListener(mouseListener);
	}


}
