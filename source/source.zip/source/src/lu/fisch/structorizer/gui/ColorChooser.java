/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the color chooser dialog.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.31      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		I used JFormDesigner to desin this window graphically.
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
/*
 * Created by JFormDesigner on Mon Dec 31 20:27:26 CET 2007
 */



/**
 * @author Robert Fisch
 */
public class ColorChooser extends LangDialog
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4539001908858831459L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JColorChooser chooser;
	protected JPanel buttonBar;
	protected JButton btnOK;
	protected JButton btnCancel;
	// JFormDesigner - End of variables declaration  //GEN-END:variables


	private boolean RESULT = false;

	 Color getColor()
	{
		return this.chooser.getColor();
	}

	 void setColor(Color _color)
	{
		this.chooser.setColor(_color);
	}
	
	 void setRESULT(boolean rESULT) {
		this.RESULT = rESULT;
	}

	 boolean isRESULT() {
		return this.RESULT;
	}

	 boolean execute()
	{
		this.setRESULT(false);
		setVisible(true);
		return this.isRESULT();
	}

	/*public ColorChooser()
	{
		super();
		setModal(true);
		initComponents();
	}*/

	 ColorChooser(Frame owner)
	{
		super(owner);
		setModal(true);
		initComponents();
	}

	/*public ColorChooser(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	void modalButtonActionPerformed(ActionEvent e)
	{
		if (e.getSource()==this.btnOK) {this.setRESULT(true);}
		else {this.setRESULT(false);}
		setVisible(false);
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.chooser = new JColorChooser();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();
		this.btnCancel = new JButton();

		//======== this ========
		setModal(true);
		setResizable(false);
		setTitle("Colors");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));

			// JFormDesigner evaluation mark
			/*
			dialogPane.setBorder(new javax.swing.border.CompoundBorder(
				new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
					"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
					javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
					java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */

			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new BorderLayout(8, 8));
				this.contentPanel.add(this.chooser, BorderLayout.CENTER);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 85, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0, 0.0};

				//---- okButton ----
				this.btnOK.setText("OK");
				this.btnOK.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						modalButtonActionPerformed(e);
					}
				});
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 5), 0, 0));

				//---- cancelButton ----
				this.btnCancel.setText("Cancel");
				this.btnCancel.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						modalButtonActionPerformed(e);
					}
				});
				this.buttonBar.add(this.btnCancel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// Bob-thinks
		// add the KEY-listeners
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
					ColorChooser.this.setRESULT(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
					ColorChooser.this.setRESULT(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				//nothing to do
			}
			@Override
			public void keyTyped(KeyEvent kevt) {
				// nothing to do
			}
		};
		this.btnCancel.addKeyListener(keyListener);
		this.btnOK.addKeyListener(keyListener);
		addKeyListener(keyListener);
		this.chooser.addKeyListener(keyListener);


	}


}
