/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    This is the general preferences window.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.31      First Issue
 *      Marco Sillano   2011.03.06      Modified for JStruct
 *
 ******************************************************************************************************
 *
 *      Comment:		I used JFormDesigner to desin this window graphically.
 *
 ******************************************************************************************************///

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
/*
 * Created by JFormDesigner on Mon Dec 31 09:04:29 CET 2007
 */



/**
 * @author Robert Fisch
 */
public class Preferences extends LangDialog implements ActionListener, KeyListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6546435375925727256L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel dialogPane;
	protected JPanel contentPanel;
	protected JPanel pnlLeft;
	protected JPanel pnlAlt;
	protected JPanel pnlCases;
	protected JPanel pnlAltLeft;
	protected JLabel lblAltT;
	protected JTextField edtAltT;
	protected JPanel pnlAltRight;
	protected JLabel lblAltF;
	protected JTextField edtAltF;
	protected JPanel pnlContent;
	protected JLabel lblAltContent;
	protected JTextField edtAlt;
	protected JPanel pnlCase;
	protected JLabel lblCase;
	protected JScrollPane scrollPane1;
	protected JTextArea txtCase;
	protected JPanel pnlRight;
	protected JPanel pnlFor;
	protected JLabel lblFor;
	protected JTextField edtFor;
	protected JPanel pnlRepeat;
	protected JLabel lblRepeat;
	protected JTextField edtRepeat;
	protected JPanel pnlWhile;
	protected JLabel lblWhile;
	protected JTextField edtWhile;
	protected JPanel buttonBar;
	protected JButton btnOK;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	/*public Preferences() {
		super();
		setModal(true);
		initComponents();
	}*/

	/**
	 * @param owner
	 */
	public Preferences(Frame owner) {
		super(owner);
		setModal(true);
		initComponents();
	}

	/*public Preferences(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.dialogPane = new JPanel();
		this.contentPanel = new JPanel();
		this.pnlLeft = new JPanel();
		this.pnlAlt = new JPanel();
		this.pnlCases = new JPanel();
		this.pnlAltLeft = new JPanel();
		this.lblAltT = new JLabel();
		this.edtAltT = new JTextField();
		this.pnlAltRight = new JPanel();
		this.lblAltF = new JLabel();
		this.edtAltF = new JTextField();
		this.pnlContent = new JPanel();
		this.lblAltContent = new JLabel();
		this.edtAlt = new JTextField();
		this.pnlCase = new JPanel();
		this.lblCase = new JLabel();
		this.scrollPane1 = new JScrollPane();
		this.txtCase = new JTextArea();
		this.pnlRight = new JPanel();
		this.pnlFor = new JPanel();
		this.lblFor = new JLabel();
		this.edtFor = new JTextField();
		this.pnlRepeat = new JPanel();
		this.lblRepeat = new JLabel();
		this.edtRepeat = new JTextField();
		this.pnlWhile = new JPanel();
		this.lblWhile = new JLabel();
		this.edtWhile = new JTextField();
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();

		//======== this ========
		setTitle("Structures Preferences");
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		//======== dialogPane ========
		{
			this.dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
			this.dialogPane.setPreferredSize(new Dimension(429, 320));
			this.dialogPane.setRequestFocusEnabled(false);

			// JFormDesigner evaluation mark
			/*dialogPane.setBorder(new javax.swing.border.CompoundBorder(
				new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
					"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
					javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
					java.awt.Color.red), dialogPane.getBorder())); dialogPane.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
			 */
			this.dialogPane.setLayout(new BorderLayout());

			//======== contentPanel ========
			{
				this.contentPanel.setLayout(new BorderLayout(5, 5));

				//======== pnlLeft ========
				{
					this.pnlLeft.setMaximumSize(new Dimension(2147483647, 2147483647));
					this.pnlLeft.setPreferredSize(new Dimension(200, 185));
					this.pnlLeft.setFocusCycleRoot(true);
					this.pnlLeft.setLayout(new BorderLayout(8, 8));

					//======== pnlAlt ========
					{
						this.pnlAlt.setBorder(new TitledBorder("IF statement"));
						this.pnlAlt.setLayout(new BorderLayout(8, 8));

						//======== pnlCases ========
						{
							this.pnlCases.setLayout(new BorderLayout(8, 8));

							//======== pnlAltLeft ========
							{
								this.pnlAltLeft.setPreferredSize(new Dimension(95, 44));
								this.pnlAltLeft.setLayout(new BorderLayout(8, 7));

								//---- lblAltTF ----
								this.lblAltT.setText("Label TRUE");
								this.pnlAltLeft.add(this.lblAltT, BorderLayout.NORTH);
								this.pnlAltLeft.add(this.edtAltT, BorderLayout.CENTER);
							}
							this.pnlCases.add(this.pnlAltLeft, BorderLayout.WEST);

							//======== pnlAltRight ========
							{
								this.pnlAltRight.setPreferredSize(new Dimension(95, 44));
								this.pnlAltRight.setLayout(new BorderLayout(8, 8));

								//---- lblAltF ----
								this.lblAltF.setText("Label FALSE");
								this.lblAltF.setHorizontalAlignment(SwingConstants.RIGHT);
								this.pnlAltRight.add(this.lblAltF, BorderLayout.NORTH);
								this.pnlAltRight.add(this.edtAltF, BorderLayout.CENTER);
							}
							this.pnlCases.add(this.pnlAltRight, BorderLayout.CENTER);
						}
						this.pnlAlt.add(this.pnlCases, BorderLayout.NORTH);

						//======== pnlContent ========
						{
							this.pnlContent.setLayout(new BorderLayout());

							//---- lblAltContent ----
							this.lblAltContent.setText("Default content");
							this.pnlContent.add(this.lblAltContent, BorderLayout.NORTH);
							this.pnlContent.add(this.edtAlt, BorderLayout.CENTER);
						}
						this.pnlAlt.add(this.pnlContent, BorderLayout.CENTER);
					}
					this.pnlLeft.add(this.pnlAlt, BorderLayout.NORTH);

					//======== pnlCase ========
					{
						this.pnlCase.setBorder(new TitledBorder("CASE statement"));
						this.pnlCase.setLayout(new BorderLayout());

						//---- lblCase ----
						this.lblCase.setText("Default content");
						this.pnlCase.add(this.lblCase, BorderLayout.NORTH);

						//======== scrollPane1 ========
						{
							this.scrollPane1.setViewportView(this.txtCase);
						}
						this.pnlCase.add(this.scrollPane1, BorderLayout.CENTER);
					}
					this.pnlLeft.add(this.pnlCase, BorderLayout.CENTER);
				}
				this.contentPanel.add(this.pnlLeft, BorderLayout.CENTER);

				//======== pnlRight ========
				{
					this.pnlRight.setMaximumSize(new Dimension(2147483647, 2147483647));
					this.pnlRight.setPreferredSize(new Dimension(200, 226));
					this.pnlRight.setLayout(new BorderLayout(8, 8));

					//======== pnlFor ========
					{
						this.pnlFor.setBorder(new TitledBorder("FOR loop"));
						this.pnlFor.setLayout(new BorderLayout(8, 8));

						//---- lblFor ----
						this.lblFor.setText("Default content");
						this.pnlFor.add(this.lblFor, BorderLayout.NORTH);
						this.pnlFor.add(this.edtFor, BorderLayout.CENTER);
					}
					this.pnlRight.add(this.pnlFor, BorderLayout.NORTH);

					//======== pnlRepeat ========
					{
						this.pnlRepeat.setBorder(new TitledBorder("DO loop"));
						this.pnlRepeat.setLayout(new BorderLayout(8, 8));

						//---- lblRepeat ----
						this.lblRepeat.setText("Default content");
						this.pnlRepeat.add(this.lblRepeat, BorderLayout.NORTH);
						this.pnlRepeat.add(this.edtRepeat, BorderLayout.CENTER);
					}
					this.pnlRight.add(this.pnlRepeat, BorderLayout.SOUTH);

					//======== pnlWhile ========
					{
						this.pnlWhile.setBorder(new TitledBorder("WHILE loop"));
						this.pnlWhile.setAutoscrolls(true);
						this.pnlWhile.setLayout(new BorderLayout(8, 8));

						//---- lblWhile ----
						this.lblWhile.setText("Default content");
						this.pnlWhile.add(this.lblWhile, BorderLayout.NORTH);
						this.pnlWhile.add(this.edtWhile, BorderLayout.CENTER);
					}
					this.pnlRight.add(this.pnlWhile, BorderLayout.CENTER);
				}
				this.contentPanel.add(this.pnlRight, BorderLayout.EAST);
			}
			this.dialogPane.add(this.contentPanel, BorderLayout.CENTER);

			//======== buttonBar ========
			{
				this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
				this.buttonBar.setLayout(new GridBagLayout());
				((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
				((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

				//---- okButton ----
				this.btnOK.setText("OK");
				this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
			}
			this.dialogPane.add(this.buttonBar, BorderLayout.SOUTH);
		}
		contentPane.add(this.dialogPane, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// Bob things
		this.btnOK.addActionListener(this);
		this.btnOK.addKeyListener(this);
		this.edtAltT.addKeyListener(this);
		this.edtAltF.addKeyListener(this);
		this.edtAlt.addKeyListener(this);
		this.txtCase.addKeyListener(this);
		this.edtFor.addKeyListener(this);
		this.edtWhile.addKeyListener(this);
		this.edtRepeat.addKeyListener(this);
		addKeyListener(this);
	}


	// listen to actions
	@Override
	public void actionPerformed(ActionEvent event)
	{
		setVisible(false);
	}

	@Override
	public void keyTyped(KeyEvent kevt)
	{				
		// nothing to do
	}

	@Override
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
		{
			setVisible(false);
		}
		else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
		{
			setVisible(false);
		}
	}

	@Override
	public void keyReleased(KeyEvent ke)
	{			
		// nothing to do
	}

}
