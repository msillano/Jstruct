/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.structorizer.gui;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Descrip
 *      tion:    This is the font chooser dialog.
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.31      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:		While setting up this class, I had a deep look at the following package:
 *
 * 		*********************************************************
 *		* Package: ZoeloeSoft.projects.JFontChooser
 *		* Id: JFontChooser.java
 * 		* Date: 23:39 19/04/2004
 *	 	* Creator: Tim Eeckhaut
 *		* Alias: zoeloeboeloe
 * 		* Company: ZoeloeSoft
 *	 	* Website: http://users.pandora.be/ZoeloeSoft
 *		*********************************************************
 *
 ******************************************************************************************************///


import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

/*
 * Created by JFormDesigner on Mon Dec 31 12:44:23 CET 2007
 */



/**
 * @author Robert Fisch
 */
public class FontChooser extends LangDialog
{

	private static final long serialVersionUID = 8795303570377221615L;
	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Robert Fisch
	protected JPanel pnlChooser;
	protected JPanel contentPanel;
	protected JLabel lblTest;
	protected JPanel pnlName;
	protected JLabel lblName;
	protected JScrollPane scrollPane1;
	protected JList<String> lsNames;
	protected JPanel pnlSize;
	protected JLabel lblSize;
	protected JScrollPane scrollPane2;
	protected JList<String> lsSizes;
	protected JPanel buttonBar;
	protected JButton btnOK;
	// JFormDesigner - End of variables declaration  //GEN-END:variables

	private final String[] sizes = new String[] { "2","4","6","8","10","12","14","16","18","20","22","24","30","36","48","72" };

	/*
	public FontChooser() {
		super();
		setModal(true);
		initComponents();
	}*/

	/**
	 * @param owner
	 */
	public FontChooser(Frame owner) {
		super(owner);
		setModal(true);
		initComponents();
	}

	/*public FontChooser(Dialog owner) {
		super(owner);
		initComponents();
	}*/

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Robert Fisch
		this.pnlChooser = new JPanel();
		this.contentPanel = new JPanel();
		this.lblTest = new JLabel();
		this.pnlName = new JPanel();
		this.lblName = new JLabel();
		this.scrollPane1 = new JScrollPane();
		this.lsNames = new JList<String>(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
		this.pnlSize = new JPanel();
		this.lblSize = new JLabel();
		this.scrollPane2 = new JScrollPane();
		this.lsSizes = new JList<String>(this.sizes);
		this.buttonBar = new JPanel();
		this.btnOK = new JButton();

		//======== fontChooser ========
		{
			setResizable(false);
			setTitle("Font");
			final Container fontChooserContentPane = getContentPane();
			fontChooserContentPane.setLayout(new BorderLayout());

			//======== FontChooser ========
			{
				this.pnlChooser.setBorder(new EmptyBorder(12, 12, 12, 12));

				// JFormDesigner evaluation mark
				/*FontChooser.setBorder(new javax.swing.border.CompoundBorder(
					new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
						"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
						javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
						java.awt.Color.red), FontChooser.getBorder())); FontChooser.addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});
				 */
				this.pnlChooser.setLayout(new BorderLayout());

				//======== contentPanel ========
				{
					this.contentPanel.setLayout(new BorderLayout(8, 8));

					//---- lblTest ----
					this.lblTest.setText("Test: JStruct (Symboltest: [\u2190 - \u2205])");
					this.contentPanel.add(this.lblTest, BorderLayout.SOUTH);

					//======== pnlName ========
					{
						this.pnlName.setPreferredSize(new Dimension(250, 150));
						this.pnlName.setLayout(new BorderLayout(8, 8));

						//---- lblName ----
						this.lblName.setText("Name");
						this.pnlName.add(this.lblName, BorderLayout.NORTH);

						//======== scrollPane1 ========
						{
							this.scrollPane1.setViewportView(this.lsNames);
						}
						this.pnlName.add(this.scrollPane1, BorderLayout.CENTER);
					}
					this.contentPanel.add(this.pnlName, BorderLayout.WEST);

					//======== pnlSize ========
					{
						this.pnlSize.setPreferredSize(new Dimension(100, 150));
						this.pnlSize.setLayout(new BorderLayout(8, 8));

						//---- lblSize ----
						this.lblSize.setText("Size");
						this.pnlSize.add(this.lblSize, BorderLayout.NORTH);

						//======== scrollPane2 ========
						{
							this.scrollPane2.setViewportView(this.lsSizes);
						}
						this.pnlSize.add(this.scrollPane2, BorderLayout.CENTER);
					}
					this.contentPanel.add(this.pnlSize, BorderLayout.CENTER);
				}
				this.pnlChooser.add(this.contentPanel, BorderLayout.CENTER);

				//======== buttonBar ========
				{
					this.buttonBar.setBorder(new EmptyBorder(12, 0, 0, 0));
					this.buttonBar.setLayout(new GridBagLayout());
					((GridBagLayout)this.buttonBar.getLayout()).columnWidths = new int[] {0, 80};
					((GridBagLayout)this.buttonBar.getLayout()).columnWeights = new double[] {1.0, 0.0};

					//---- btnOK ----
					this.btnOK.setText("OK");
					this.buttonBar.add(this.btnOK, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
							GridBagConstraints.CENTER, GridBagConstraints.BOTH,
							new Insets(0, 0, 0, 0), 0, 0));
				}
				this.pnlChooser.add(this.buttonBar, BorderLayout.SOUTH);
			}
			fontChooserContentPane.add(this.pnlChooser, BorderLayout.CENTER);

			pack();
			setLocationRelativeTo(getOwner());
		}
		// JFormDesigner - End of component initialization  //GEN-END:initComponents

		// BOB thinks

		// add the LIST-listeners
		final ListSelectionListener listListener = new ListSelectionListener()
		{
			@Override
			public void valueChanged(ListSelectionEvent e)
			{
				FontChooser.this.lblTest.setFont(getCurrentFont());
			}
		};
		this.lsSizes.addListSelectionListener(listListener);
		this.lsNames.addListSelectionListener(listListener);

		// add the KEY-listeners
		final KeyListener keyListener = new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					setVisible(false);
				}
				else if(e.getKeyCode() == KeyEvent.VK_ENTER && (e.isShiftDown() || e.isControlDown()))
				{
					setVisible(false);
				}
			}

			@Override
			public void keyReleased(KeyEvent ke) {
				// nothing to do 
			}
			@Override
			public void keyTyped(KeyEvent kevt) {	  
			    // nothing to do 
            }
		};
		this.lsSizes.addKeyListener(keyListener);
		this.lsNames.addKeyListener(keyListener);
		this.btnOK.addKeyListener(keyListener);

		// add the ACTION-listeners
		final ActionListener actionListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				setVisible(false);
			}
		};
		this.btnOK.addActionListener(actionListener);
	}

	/**
	 * @return  font
	 */
	public Font getCurrentFont()
	{
		Font font = new Font("Helvetica", Font.PLAIN, 12);


		try
		{
			final String fontFamily = this.lsNames.getSelectedValue();
			final int fontSize = Integer.parseInt(this.lsSizes.getSelectedValue());

			final int fontType = Font.PLAIN;

			//if (cbBold.isSelected()) fontType += Font.BOLD;
			//if (cbItalic.isSelected()) fontType += Font.ITALIC;

			font= new Font(fontFamily, fontType, fontSize);
		}
		catch (final Exception e)
		{
			// nothing to do 
		}

		return font;
	}

	@Override
	public void setFont(Font _font)
	{
	    Font font;	 
		if (_font == null) font = this.lblTest.getFont();
		else font = _font;

		this.lsNames.setSelectedValue(font.getName(), true);
		this.lsNames.ensureIndexIsVisible(this.lsNames.getSelectedIndex());
		this.lsSizes.setSelectedValue("" + font.getSize(), true);
		this.lsSizes.ensureIndexIsVisible(this.lsSizes.getSelectedIndex());

		//cbBold.setSelected(font.isBold());
		//cbItalic.setSelected(font.isItalic());
	}


}
