//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\Repeat.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
package lu.fisch.structorizer.elements;
import java.util.Vector;
import java.awt.Color;
import java.awt.FontMetrics;
import lu.fisch.graphics.*;
import lu.fisch.utils.*;
/**
 * While block, for <code>while-do</code> statement. <BR>
 * The do statement executes a Statement and an Expression repeatedly until the value
 * of the Expression is false.
 * <table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-Alternative.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-alternative.png" width="200" alt="" border="0"></td>
 *  DoStatement:
 *Statement while ( Expression ) ;
 * <td>  <i>DoStatement: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;</i><code>do</code><i> Statement </i><code>while (</code><i> Expression </i><code>) ;</code><i><BR>
 * </i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd>The labels  "YES", "NOT" and the default code value ("&lt;condition>") can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.<br/>
 *<dd>The optional pre-keyword and post-keyword (default "if" and "?") can be changed in menu  options/parser <img src="../../../../resources/004_Make.png" border="1" width="16" height="16" alt="">.
 *<dd>In menu the Alternative icon is <img src="../../../../resources/060_conv_if.png" border="1" width="16" height="16" alt=""><BR><BR>
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an Alternative block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;pre-keyword>] &lt;condition>|(&lt;condition>) [&lt;post-keyword>]</pre>
 *Comments are not allowed in Alternative code.    <BR><BR>
 *
 *<dt><span class="strong">Analyze:</span></dt><i><ul><li>WARNING: empty True-block.
 *<li>WARNING: assignment in condition (maybe '=' instead of '==' ?)
 *</ul></i>
 *
 * <BR>Source build by JStruct.<BR>
 *
 * @version 1.01.01  build 22  (2012.03.14-17:59:57) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class While extends AbstractElement {

	private Subqueue whileSubqueue = new Subqueue();

	private Rect r = new Rect();

	/**
	 * The default constructor 
	 */
	public While()
	{
		super();
		this.whileSubqueue.setParent(this);
	}

	/**
	 * The constructor from String
	 * @param _strings String used as code
	 */
	public While(String _strings)
	{
		super(_strings);
		this.whileSubqueue.setParent(this);
		setCode(_strings);
	}

	/**
	 * The constructor for StringList code
	 * @param _strings StringList used as code
	 */
	public While(StringList _strings)
	{
		super(_strings);
		this.whileSubqueue.setParent(this);
		setCode(_strings);
	}
	@Override
	public String getName(){
    	return "While-do Iteration";
    }


	/**
	 * @return the whileSubqueue
	 */
	public Subqueue getWhileSubqueue() {
		return this.whileSubqueue;
	}

	@Override
	public Rect prepareDraw(Canvas _canvas)
	{
		this.rect.top=0;
		this.rect.left=0;
		this.rect.right=E_PADDING;

		final FontMetrics fm = _canvas.getFontMetrics(font);
		for(int i=0;i<this.code.count();i++)
			this.rect.right = Math.max(this.rect.right, _canvas.stringWidth(this.code.get(i))+E_PADDING);
		this.rect.bottom=E_PADDING +this.code.count()*fm.getHeight();
// subqueue
		this.r=this.whileSubqueue.prepareDraw(_canvas);
		this.rect.right=Math.max(this.rect.right,this.r.right+E_PADDING);
		this.rect.bottom+=this.r.bottom;
		return this.rect;
	}

	@Override
	public void draw(Canvas _canvas, Rect _top_left)
	{
		Rect myrect = new Rect();
		Color drawColor = getColor();
		final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
		if (this.selected==true)
		{
			if(this.waited==true) { drawColor=AbstractElement.E_WAITCOLOR; }
			else { drawColor=AbstractElement.E_DRAWCOLOR; }
		}
		final Canvas canvas = _canvas;
		canvas.setBackground(drawColor);
		canvas.setColor(drawColor);
		this.rect=_top_left.copy();
		// draw shape
		myrect=_top_left.copy();
		canvas.setColor(Color.BLACK);
		myrect.bottom=_top_left.top+fm.getHeight()*this.code.count()+E_PADDING;
		canvas.drawRect(myrect);
		myrect=_top_left.copy();
		myrect.right=myrect.left+AbstractElement.E_PADDING;
		canvas.drawRect(myrect);
		// fill shape
		canvas.setColor(drawColor);
		myrect.left=myrect.left+1;
		myrect.top=myrect.top+1;
//		myrect.bottom=myrect.bottom;
//		myrect.right=myrect.right;
		canvas.fillRect(myrect);
		myrect=_top_left.copy();
		myrect.bottom=_top_left.top+fm.getHeight()*this.code.count()+E_PADDING;
		myrect.left=myrect.left+1;
		myrect.top=myrect.top+1;
//		myrect.bottom=myrect.bottom;
//		myrect.right=myrect.right;
		canvas.fillRect(myrect);

		// draw comment
		if(AbstractElement.isE_SHOWCOMMENTS()==true && !this.comment.getText().trim().equals(""))
		{
			canvas.setBackground(E_COMMENTCOLOR);
			canvas.setColor(E_COMMENTCOLOR);

			final Rect someRect = _top_left.copy();

			someRect.left+=2;
			someRect.top+=2;
			someRect.right=someRect.left+4;
			someRect.bottom-=1;

			canvas.fillRect(someRect);
		}


		myrect=_top_left.copy();
		// draw code
		for(int i=0;i<this.code.count();i++)
		{
			final String text1 = this.code.get(i);
			canvas.setColor(Color.BLACK);
			writeOutVariables(canvas,
					_top_left.left+(E_PADDING / 2),
					_top_left.top+(E_PADDING / 2)+(i+1)*fm.getHeight(),
					text1 );
		}

		// draw children
		myrect=_top_left.copy();
		myrect.left=myrect.left+AbstractElement.E_PADDING-1;
		myrect.top=_top_left.top+fm.getHeight()*this.code.count()+ E_PADDING - 1;
		this.whileSubqueue.draw(_canvas,myrect);
	}

	@Override
	public AbstractElement selectElementByCoord(int _x, int _y, boolean update)
	{
		AbstractElement selMe = super.selectElementByCoord(_x,_y, update);
		final AbstractElement sel = this.whileSubqueue.selectElementByCoord(_x,_y, update);
		if(sel!=null)
		{
			if (update)
				this.selected=false;
			selMe = sel;
		}

		return selMe;
	}

	@Override
	public void setSelected(boolean _sel)
	{
		this.selected=_sel;
		//finallySubqueue.setSelected(_sel);
	}

	@Override
	public AbstractElement copy()
	{
		final AbstractElement ele = new While(getCode().copy());
		ele.setComment(getComment().copy());
		ele.setColor(getColor());
		((While) ele).whileSubqueue= this.whileSubqueue.copy();
		((While) ele).whileSubqueue.setParent(ele);
		return ele;
	}

	// only for Elements with SubQueue
	@Override
	public boolean isEmpty(){
		return this.whileSubqueue.isEmpty();
	}


	@Override
	public Java3Code getFullText() {
        final Java3Code text1 = super.getFullText();
		return text1.add(this.whileSubqueue.getFullText());
	}


	// added 2011.03.06 m.s.
	@Override
	public String toString(String indent){
		final String res = super.toString(indent);
		return res + this.whileSubqueue.toString(indent + "   ");
	}
	
	// added 2011.03.06 m.s.
	@Override
	// recursive call
    public StringList parseVarNames() {
		return this.whileSubqueue.parseVarNames();
	}
	
	// added 2011.03.06 m.s.
	@Override
	public int wordReplace(String old, String by, boolean doTxt, boolean doComm){
		int x =  super.wordReplace(old, by, doTxt, doComm);
			x += this.whileSubqueue.wordReplace(old, by, doTxt, doComm);
	return x;
	}

	// added 2011.03.06 m.s.
	@Override
	public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
// CHECK: assignment in condition (#8)
        Java3Code condition = new Java3Code(this.code);
        if(condition.codeReduce(true).contains(" = ")) {
            final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error08, ""), this);
            RootElement.addError(_errors, e, 8);
         }
		return this.whileSubqueue.analyze(_errors);
	}
}
