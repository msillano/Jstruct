//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\Catch.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;
import lu.fisch.utils.ErrorMessages;

/**
 * Catch block, for <code>try-catch-finally</code> statement. <BR>
 * A try statement executes a block. If a value is thrown and the try statement has
 * one or more catch clauses that can catch it, then control will be transferred to the
 * first such catch clause.
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-try-catch.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-case.png" width="200" alt="" border="0"></td>
 *  <td>  <i>Catches: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;CatchClause<br>
 *    &nbsp;&nbsp;&nbsp;&nbsp;Catches CatchClause<BR><br>
 *    CatchClause:<BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>catch (</code><i>  CatchFormalParameter </i><code>)</code><i> Block<BR><br>
 *    CatchFormalParameter:<BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; [VariableModifiers] CatchType VariableDeclaratorId<BR><br>
 *    CatchType: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;ClassType<br>
 *    &nbsp;&nbsp;&nbsp;&nbsp;ClassType | CatchType<BR>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd> Designed like the Switch block, this block exists only inside a try block.
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in a Catch block can only "catch" or a list:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;catch
 *&nbsp;&nbsp;&nbsp;&nbsp;([VariableModifiers] &lt;CatchType> &lt;VariableDeclaratorId>)*
 *&nbsp;&nbsp;&nbsp;&nbsp;[%]
 *</pre><br>
 *note: catch block can also be empty: it acts as placeholder, does not export code.<br>
 *Comments are not allowed in Catch code.    <BR>
 *
 * <br />Source build by JStruct [charset UTF-8].<br />
 *
 * @version 1.02.00  build 8  (2015.03.26-11:39:18) to java 1.8
 * @version <dd> 1.01.01  build 22  (2012.03.10-16:14:17) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Catch
extends AbstractElement {

   /* class global variables */
   private Vector<Subqueue> catchQueues = new Vector<Subqueue>();
   private int fullWidth = 0;
   private int maxHeight = 0;

/**
 * The constructor from String code
 * @param _strings String used as code
 */
   public Catch(String _strings) {
      super();
      setCode(_strings);
   }

   @Override()
    public Vector < DetectedError > analyze(Vector < DetectedError > _errors) {
      Vector < DetectedError > errCatch = _errors;
      for(final AbstractElement acase : this.catchQueues) {
         errCatch = acase.analyze(errCatch);
      }
      if(this.getCode().count() < 3) {
         final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error03, ""), this);
         RootElement.addError(errCatch, e, 3);
      }
      return errCatch;
   }

   @Override()
    public AbstractElement copy() {
      final AbstractElement ele = new Catch(getCode().getText());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      ((Catch) ele).catchQueues.clear();
      for(int i = 0; i < this.catchQueues.size(); i++) {
         final Subqueue ss = this.catchQueues.get(i).copy();
         ss.setParent(ele);
         ((Catch) ele).catchQueues.add(ss);
      }
      return ele;
   }

   @Override()
    public void draw(Canvas _canvas, Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      if(this.selected == true) {
         if(this.waited == true) {
            drawColor = AbstractElement.E_WAITCOLOR;
         }
         else {
            drawColor = AbstractElement.E_DRAWCOLOR;
         }
      }
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
      this.rect = _top_left.copy();
// fill shape
      canvas.setColor(drawColor);
      myrect = _top_left.copy();
      myrect.left += 1;
      myrect.top += 1;
      myrect.bottom -= 1;
      myrect.bottom = _top_left.top + 2 * fm.getHeight() + 2 * E_PADDING;
// myrect.right-=1;
      canvas.fillRect(myrect);
// draw shape
      myrect = _top_left.copy();
      myrect.bottom = _top_left.top + 2 * fm.getHeight() + 2 * E_PADDING;
      final int y = myrect.top + E_PADDING;
      final int a = myrect.left + ((myrect.right - myrect.left) / 2);
      final int b = myrect.top;
      final int c = myrect.left + this.fullWidth - 1;
      final int d = myrect.bottom - 1;
      final int x = (((y - b) * (c - a) + a * (d - b)) / (d - b));
// draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         final Rect someRect = myrect.copy();
         someRect.left += 2;
         someRect.top += 2;
         someRect.right = someRect.left + 4;
         someRect.bottom -= 2;
         canvas.fillRect(someRect);
      }
// draw lines
      canvas.setColor(Color.BLACK);
      int lineWidth = 0;
// if the last line is '%', do not draw an else part
      int count = this.code.count() - 2;
      Rect rtt = null;
      for(int i = 0; i < count; i++) {
         rtt = this.catchQueues.get(i).prepareDraw(_canvas);
         lineWidth = lineWidth + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2));
      }
      if(this.code.get(this.code.count() - 1).equals("%")) {
         lineWidth = _top_left.right;
      }
      final int ax = myrect.left;
      final int ay = myrect.top;
      int bx = myrect.left + lineWidth;
      final int by = myrect.bottom - 1 - fm.getHeight() - (E_PADDING / 2);
      if(this.code.get(this.code.count() - 1).equals("%")) {
         bx = myrect.right;
      }
      canvas.moveTo(ax, ay);
      canvas.lineTo(bx, by);
      if(!this.code.get(this.code.count() - 1).equals("%")) {
         canvas.lineTo(bx, myrect.bottom - 1);
         canvas.lineTo(bx, by);
         canvas.lineTo(myrect.right, myrect.top);
      }
      final String varcase = this.code.get(0);
      canvas.setColor(Color.BLACK);
      if(this.code.get(this.code.count() - 1).equals("%")) {
         writeOutVariables(canvas, myrect.right - E_PADDING - _canvas.stringWidth(varcase), myrect.top + (E_PADDING / 3) + fm.getHeight(), varcase);
      }
      else {
//               x- (_canvas.stringWidth(varcase)
//                     / this.text.count()),
         writeOutVariables(canvas, x - _canvas.stringWidth(varcase), myrect.top + (E_PADDING / 3) + fm.getHeight(), varcase);
      }
//               x - (_canvas.stringWidth(varcase) / 2),
// draw children
      myrect = _top_left.copy();
      myrect.top = _top_left.top + fm.getHeight() * 2 + 2 * E_PADDING - 1;
      if(this.catchQueues.size() != 0) {
         count = this.catchQueues.size() - 1;
         if(this.code.get(this.code.count() - 1).equals("%")) {
            count -= 1;
         }
         for(int i = 0; i <= count; i++) {
            rtt = this.catchQueues.get(i).prepareDraw(_canvas);
            if(i == count) {
               myrect.right = _top_left.right;
            }
            else {
               myrect.right = myrect.left + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2)) + 1;
            }
// draw child
            this.catchQueues.get(i).draw(_canvas, myrect);
// draw code
            writeOutVariables(canvas, myrect.right + ((myrect.left - myrect.right) / 2) - (_canvas.stringWidth(this.code.get(i + 1)) / 2), myrect.top - (E_PADDING / 4), this.code.get(i + 1));
// +fm.getHeight(),
// draw bottom up line
            if(i != this.catchQueues.size() - 2 && i != count) {
               canvas.moveTo(myrect.right - 1, myrect.top);
               final int mx = myrect.right - 1;
               final int sx = mx;
               final int sy = ((sx * (by - ay) - ax * by + ay * bx) / (bx - ax));
               canvas.lineTo(sx, sy + 1);
            }
            myrect.left = myrect.right - 1;
         }
      }
      canvas.setColor(Color.BLACK);
      canvas.drawRect(_top_left);
   }

   @Override()
    public Java3Code getFullText() {
      final Java3Code text1 = super.getFullText();
      for(final AbstractElement acase : this.catchQueues) {
         text1.add(acase.getFullText());
      }
      return text1;
   }

/**
 * getter for options Vector
 * @return the catchQueues
 */
   public Vector < Subqueue > getCatchSubqueue() {
      return this.catchQueues;
   }

   @Override()
    public boolean isEmpty() {
      return this.catchQueues.isEmpty();
   }

   @Override()
    public StringList parseVarNames() {
      final StringList vars = new StringList();
      for(int i = 0; i < this.catchQueues.size(); i++) {
         final String ss = getCode().get(i + 1);
         final String[] parts = ss.trim().split(" ");
         if(parts.length > 1) {
            vars.addIfNew(parts[parts.length - 1]);
         }
      }
      for(final AbstractElement acase : this.catchQueues) {
         vars.addIfNew(acase.parseVarNames());
      }
      return vars;
   }

   @Override()
    public Rect prepareDraw(Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      final FontMetrics fm = _canvas.getFontMetrics(font);
      this.rect.right = E_PADDING;
      for(int i = 0; i < this.code.count(); i++) {
         if(this.rect.right < _canvas.stringWidth(this.code.get(i)) + E_PADDING) {
            this.rect.right = _canvas.stringWidth(this.code.get(i)) + E_PADDING;
         }
      }
      this.rect.bottom = 2 * E_PADDING + 2 * fm.getHeight();
      int count = 0;
      Rect rtt = null;
      this.fullWidth = 0;
      this.maxHeight = 0;
      if(this.catchQueues.size() != 0) {
         count = this.code.count() - 1;
         if(this.code.get(count).equals("%")) {
            count -= 1;
         }
         for(int i = 0; i < count; i++) {
            rtt = this.catchQueues.get(i).prepareDraw(_canvas);
            this.fullWidth = this.fullWidth + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2));
            if(this.maxHeight < rtt.bottom) {
               this.maxHeight = rtt.bottom;
            }
         }
      }
      this.rect.right = Math.max(this.rect.right, this.fullWidth);
      this.rect.bottom = this.rect.bottom + this.maxHeight;
      return this.rect;
   }

   @Override()
    public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
      AbstractElement selCh = null;
      for(int i = 0; i < this.catchQueues.size(); i++) {
         final AbstractElement pre = this.catchQueues.get(i).selectElementByCoord(_x, _y, update);
         if(pre != null) {
            selCh = pre;
         }
      }
      if(selCh != null) {
         if(update) {
            this.selected = false;
         }
         selMe = selCh;
      }
      return selMe;
   }

   @Override()
    public void setCode(String _text) {
      Subqueue s = null;
      this.code.setText(_text);
      if(this.catchQueues == null) {
         this.catchQueues = new Vector < Subqueue > ();
      }
      if(this.code.count() > 1) {
         while(this.code.count() - 1 > this.catchQueues.size()) {
            s = new Subqueue();
            s.setParent(this);
            this.catchQueues.add(s);
         }
         while(this.code.count() - 1 < this.catchQueues.size()) {
            this.catchQueues.removeElementAt(this.catchQueues.size() - 1);
         }
      }
   }

   @Override()
    public void setCode(StringList _textList) {
      Subqueue s = null;
      this.code = _textList;
      this.code.set(0, "catch");
// no default for  Catch
      if(this.code.contains("default", false)) {
         this.code.codeReplace("default", "%");
      }
      if(!this.code.contains("%", true)) {
         this.code.add("%");
      }
      if(this.catchQueues == null) {
         this.catchQueues = new Vector < Subqueue > ();
      }
      if(this.code.count() > 1) {
         while(this.code.count() - 1 > this.catchQueues.size()) {
            s = new Subqueue();
            s.setParent(this);
            this.catchQueues.add(s);
         }
         while(this.code.count() - 1 < this.catchQueues.size()) {
            this.catchQueues.removeElementAt(this.catchQueues.size() - 1);
         }
      }
   }

   @Override()
    public String toString(String indent) {
      String res = "";
      for(int i = 0; i < this.catchQueues.size(); i++) {
         res += indent + "catch:\n";
         res += this.catchQueues.get(i).toString(indent + "   ");
      }
      return res;
   }

   @Override()
    public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
      int x = super.wordReplace(old, by, doTxt, doComm);
      for(int i = 0; i < this.catchQueues.size(); i++) {
         x += this.catchQueues.get(i).wordReplace(old, by, doTxt, doComm);
      }
      return x;
   }

}
