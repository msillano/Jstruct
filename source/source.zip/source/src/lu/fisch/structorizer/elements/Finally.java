//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\Finally.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Finally block, for <code>try-catch-finally</code> statement.
 * <BR> If the try statement has a finally clause, then another
 * block of code is executed, no matter whether the try block completes normally or
 * abruptly, and no matter whether a catch clause is first given control.
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-try-catch.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-try.png" width="200" alt="" border="0"></td>
 *  <td>  <i>Finally: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>finally </code><i>  Block<BR><br>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd> This block exists only inside a try block.</dd>
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>
 *The Finally block is a container for standard code blocks.<br>
 *note: Finally block can also be empty: it acts as placeholder, does not export code.<br>
 *</dd><br>
 *
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.01  build 24  (2015.04.09-15:00:08) Updated to java 1.8
 * @version <dd>1.01.01  build 24  (2012.03.12-20:18:18) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Finally
extends AbstractElement {

   /* class global variables */
   private Subqueue finallySubqueue = new Subqueue();
   private Rect r = new Rect();

/**
 * The constructor for String code
 * @param _strings String
 */
   public Finally(String _strings) {
      super(_strings);
      this.getFinallySubqueue().setParent(this);
      setCode(_strings);
   }

/**
 * The constructor for StringList code
 * @param _strings StringList
 */
   public Finally(StringList _strings) {
      super(_strings);
      this.getFinallySubqueue().setParent(this);
      setCode(_strings);
   }

/**
 * The getter for children Elements
 * @return the finallySubqueue
 */
   public Subqueue getFinallySubqueue() {
      return this.finallySubqueue;
   }

   @Override()
   public Vector <DetectedError> analyze(Vector <DetectedError> _errors) {
      return this.getFinallySubqueue().analyze(_errors);
   }

   @Override()
   public AbstractElement copy() {
      final AbstractElement ele = new Finally(getCode().copy());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      ((Finally) ele).finallySubqueue = this.getFinallySubqueue().copy();
      ((Finally) ele).getFinallySubqueue().setParent(ele);
      return ele;
   }

   @Override()
   public void draw(Canvas _canvas, Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(font);
      if(isEmpty()) {
         drawColor = AbstractElement.E_NULLCOLOR;
      }
      if(this.selected == true) {
         drawColor = AbstractElement.E_DRAWCOLOR;
      }
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
//  draw background
      myrect = _top_left.copy();
      canvas.fillRect(myrect);
//  draw shape
      this.rect = _top_left.copy();
      canvas.setColor(Color.BLACK);
      canvas.drawRect(_top_left);
      myrect = _top_left.copy();
      myrect.bottom = _top_left.top + fm.getHeight() + E_PADDING;
      canvas.drawRect(myrect);
      myrect.bottom = _top_left.bottom;
      myrect.top = myrect.bottom - E_PADDING;
      canvas.drawRect(myrect);
      myrect = _top_left.copy();
      myrect.right = myrect.left + E_PADDING;
      canvas.drawRect(myrect);
//  fill shape
      canvas.setColor(drawColor);
      myrect.left = myrect.left + 1;
      myrect.top = myrect.top + 1;
      myrect.right = myrect.right - 1;
      canvas.fillRect(myrect);
      myrect = _top_left.copy();
      myrect.bottom = _top_left.top + fm.getHeight() + E_PADDING;
      myrect.left = myrect.left + 1;
      myrect.top = myrect.top + 1;
      myrect.right = myrect.right - 1;
      canvas.fillRect(myrect);
      myrect.bottom = _top_left.bottom;
      myrect.top = myrect.bottom - AbstractElement.E_PADDING;
      myrect.left = myrect.left + 1;
      myrect.top = myrect.top + 1;
      canvas.fillRect(myrect);
//  draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         final Rect someRect = _top_left.copy();
         someRect.left += 2;
         someRect.top += 2;
         someRect.right = someRect.left + 4;
         someRect.bottom -= 1;
         canvas.fillRect(someRect);
      }
//  draw code
      canvas.setColor(Color.BLACK);
      writeOutVariables(canvas, _top_left.left + E_PADDING / 2, _top_left.top + E_PADDING / 2 + fm.getHeight(), "finally");
//  draw children
      if(!isEmpty()) {
         myrect = _top_left.copy();
         myrect.left = myrect.left + AbstractElement.E_PADDING - 1;
         myrect.top = _top_left.top + fm.getHeight() + E_PADDING - 1;
         myrect.bottom = myrect.bottom - E_PADDING + 1;
         this.getFinallySubqueue().draw(_canvas, myrect);
      }
   }

   @Override()
   public Java3Code getFullText() {
      return this.getFinallySubqueue().getFullText();
   }

   @Override()
   public boolean isEmpty() {
      return this.getFinallySubqueue().getSize() == 0;
   }

   @Override()
   public StringList parseVarNames() {
      return this.getFinallySubqueue().parseVarNames();
   }

   @Override()
   public Rect prepareDraw(Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      if(isEmpty()) {
         this.rect.right = _canvas.stringWidth("finally") + E_PADDING;
         this.rect.bottom = E_PADDING + fm.getHeight();
      }
      else {
         this.rect.right = E_PADDING;
         this.rect.right = E_PADDING;
         if(this.rect.right < _canvas.stringWidth("finally") + E_PADDING) {
            this.rect.right = _canvas.stringWidth("finally") + E_PADDING;
         }
         this.rect.bottom = E_PADDING + fm.getHeight();
         this.r = this.getFinallySubqueue().prepareDraw(_canvas);
         this.rect.right = Math.max(this.rect.right, this.r.right + E_PADDING);
         this.rect.bottom += this.r.bottom + E_PADDING;
      }
      return this.rect;
   }

   @Override()
   public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
      final AbstractElement sel = this.getFinallySubqueue().selectElementByCoord(_x, _y, update);
      if(sel != null) {
         if(update) {
            this.selected = false;
         }
         selMe = sel;
      }
      return selMe;
   }

   @Override()
   public String toString(String indent) {
      String tree = super.toString(indent);
      tree += this.getFinallySubqueue().toString(indent + "   ");
      return tree;
   }

   @Override()
   public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
      int x = super.wordReplace(old, by, doTxt, doComm);
      x += this.getFinallySubqueue().wordReplace(old, by, doTxt, doComm);
      return x;
   }

}
