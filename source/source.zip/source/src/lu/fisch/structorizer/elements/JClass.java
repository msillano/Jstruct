//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION

   package lu.fisch.structorizer.elements;
   import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.util.Vector;

import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.ErrorMessages;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
Class block can be used to define Classes, Interfaces and Enum plus all global Fields.<br>
A class declaration specifies a new named reference type.
 There are two kinds of class declarations: normal class declarations and enum
 declarations. <br>
 An interface declaration introduces a new reference type whose members
 are classes, interfaces, constants, and abstract methods. This type has no
 implementation, but otherwise unrelated classes can implement it by providing
 implementations for its abstract methods.<br>
 <table width="800" border="1"> <tr>
  <td><img src="../../../../resources/help008.gif" width="200"  alt="" border="0"></td>
  <td>  <i>ClassDeclaration: <br />
    &nbsp;&nbsp;&nbsp;&nbsp;   NormalClassDeclaration<br />
    &nbsp;&nbsp;&nbsp;&nbsp;   EnumDeclaration<br />
    NormalClassDeclaration: <br />
    &nbsp;&nbsp;&nbsp;&nbsp; [ClassModifiers]</i><code> class </code><i>Identifier [TypeParameters] [Super] [Interfaces]<br>
    EnumDeclaration: <br />
    &nbsp;&nbsp;&nbsp;&nbsp; [ClassModifiers]</i><code> enum </code><i>Identifier [Interfaces]<br><br>
  InterfaceDeclaration:<br>
  &nbsp;&nbsp;&nbsp;&nbsp; NormalInterfaceDeclaration<br>
  &nbsp;&nbsp;&nbsp;&nbsp; AnnotationTypeDeclaration<br>
NormalInterfaceDeclaration:<br>
&nbsp;&nbsp;&nbsp;&nbsp; [InterfaceModifiers]</i><code> interface </code><i>  Identifier [TypeParameters] [ExtendsInterfaces]
AnnotationTypeDeclaration:<br>
[InterfaceModifiers] </i><code> @ interface </code><i>Identifier <br><br>

FieldDeclaration:<br>
&nbsp;&nbsp;&nbsp;&nbsp; [FieldModifiers] Type VariableDeclarators
  </i></td> </tr>
</table ><br>
<dt><span class="strong">Look and feel:</span></dt>
<dd>In menu the Class icon is <img src="../../../../resources/021_function.png" border="1" width="16" height="16" alt=""></dd>
<dd>A Class block can be in <a href="help_gui_it.html#full">expanded or reduced</a> mode.</dd><br><br>
<dt><span class="strong">Class syntax:</span></dt>
<dd>The code in an Class block must be:<pre>
&nbsp;&nbsp;&nbsp;&nbsp;&lt;ClassDeclaration>|&lt;InterfaceDeclaration>;
&nbsp;&nbsp;&nbsp;&nbsp;[&lt;FieldDeclaration>;]*</pre><ul type="disc">
 <li>Comments are also allowed in the code section: they are exported in Java code whitout changes.</li>
 </ul></dd>

<dt><span class="strong">Enum syntax:</span></dt>
<dd>The Class block allows <b>enum</b> definition.<pre>
&nbsp;&nbsp;&nbsp;&nbsp;[&lt;modifiers>] enum &lt;name>
&nbsp;&nbsp;&nbsp;&nbsp; [&lt;value>[(&lt;parameter>)],]*
&nbsp;&nbsp;&nbsp;&nbsp; &lt;value>[(&lt;parameter>)];
&nbsp;&nbsp;&nbsp;&nbsp;[&lt;FieldDeclaration>;]* </pre><ul type="disc">
 <li>Comments are also allowed in the code section: they are exported in Java code whitout changes.</li>
 </ul></dd>

<dt><span class="strong">Comment section:</span></dt>
<dd> The comment is Exported as Javadoc comment for the class/interface/enum.</dd>
<dd>JStruct can add infos to this comment.</dd>
 <br><br>

<dt><span class="strong">Analyze:</span></dt><i><ul>
<li>WARNING: the Class name is not capitalized.
<li>ERROR: a public Class must be in a file having same name.
<li>ERROR: the Class name is not a valid Java identifier.
<li>ERROR: Class name equal to an existing variable or parameter name.
<li>ERROR: not a valid Java identifier.
</ul></i>
 *
 * <BR>Source build by JStruct.<BR>
 *
 * @version 1.02.01  build 8  (2015.04.09-15:11:07) Updated to java 1.8
 * @version <dd> 1.01.01  build 22  (2012.03.14-16:58:17) JStruct-aware version
 * @version <dd> 1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
   public class JClass
   extends RootElement {

      /* class global variables */
      private int myheight = 0;
      private int mywidth = 0;
      private Rect mybox = null;


/**
 * Default constructor
 */
       public JClass() {
         super();
      }


/**
 * The constructor for a Method
 * @param root JMethod to add.
 */
       public JClass(JMethod root) {
         super();
         setCode("NewClass");
         addElement(root);
      }


/**
 * The constructor for String code
 * @param _strings String used as code
 */
       public JClass(String _strings) {
         super(_strings);
      }


/**
 * The constructor for StringList code
 * @param _strings StringList used as code
 */
       public JClass(StringList _strings) {
         super(_strings);
      }

       @Override()
       public void addElement(AbstractElement _ele) {
         super.addElement(_ele);
         _ele.setColor(getColor());
      }

       @Override()
       public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
         final Vector<DetectedError> errClass = super.analyze(_errors);
// special for Classes:
         final String name = getRootName();
// Menu.error07_1.text=«%» non è un valido nome in Java!
         if(!Java3Code.testIdentifier(name)) {
            final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error07_1, name), this);
            addError(errClass, e, 7);
         }
// Menu.error06.text=Il nome della Classe «%» deve essere con iniziale in maiuscolo!
         if(!Character.isUpperCase(name.charAt(0))) {
            final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_1, name), this);
            addError(errClass, e, 6);
         }
// Menu.error12.text=Una Classe pubblica deve avere lo stesso nome «%» del file!
         final RootElement root = getProgram();
         if(getParent() == root) {
            if(getDeclaration().contains("public")) {
               if(!name.equals(getCompilationUnit().getDefaultFileName())) {
                  final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error12, getCompilationUnit().getDefaultFileName()), this);
                  addError(errClass, e, 12);
               }
            }
         }
// Menu.error09.text=Una Classe («%») non può avere lo stesso nome di una variabile o di un parametero!
         for(int i = 0; i < this.variables.count(); i++) {
            if(this.variables.get(i).equals(name)) {
               final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_4, this.variables.get(i)), this);
               addError(errClass, e, 6);
            }
         }
// Menu.error07_3.text=«%» non è un nome valido per una variabile!
         final StringList vars = parseGlobalNames(globalType.VARONLY);
         for(int i = 0; i < vars.count(); i++) {
            if(!Java3Code.testIdentifier(vars.get(i))) {
               final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error07_3, vars.get(i)), this);
               addError(errClass, e, 7);
            }
         }
         return errClass;
      }

       @Override()
       public AbstractElement copy() {
         final JClass ele = new JClass(getCode().copy());
         ele.setComment(getComment().copy());
         ele.setColor(getColor());
         ele.setClosed(isClosed());
         ele.setChildQueue(getChildQueue().copy());
         ele.getChildQueue().setParent(ele);
         return ele;
      }


       @Override()
       public String getRootName() {
    	 Java3Code dec = new Java3Code(getDeclaration());
         final String[] parts = dec.getTokens();
            for(int i = 0; i < parts.length; i++) {
               if(parts[i].equals("class")) {
                  setJName(parts[i + 1]);
                  return getJName();
               }
               if(parts[i].equals("enum")) {
                   setJName(parts[i + 1]);
                   return getJName();
                }
               if(parts[i].equals("interface")) {
                   setJName(parts[i + 1]);
                   return getJName();
                }
               if(parts[i].equals("extends")) {
                  setJName(parts[i - 1]);
                  return getJName();
               }
               if(parts[i].equals("implements")) {
                  setJName(parts[i - 1]);
                  return getJName();
               }
            }
         if (parts.length > 0) {
            setJName(parts[parts.length - 1]);
            return getJName();
         }
         setJName("ERROR");
         return getJName();
      }


       @Override()
       public void draw(Canvas _canvas, Rect _top_left) {
         final Rect myrect = _top_left.copy();
         int classLines = 0;
         this.rect = _top_left.copy();
         Rect subrect;
         Color drawColor = getColor();
         if(this.selected == true) {
            if(this.waited == true) {
               drawColor = AbstractElement.E_WAITCOLOR;
            }
            else {
               drawColor = AbstractElement.E_DRAWCOLOR;
            }
         }
         final Canvas canvas = _canvas;
// small class rectangle
         if(!isClosed() || getParentElement() instanceof CompilationUnit) {
            myrect.right = myrect.left + this.mywidth;
            myrect.bottom = myrect.top + this.myheight;
         }
// draw background
         canvas.setBackground(drawColor);
         canvas.setColor(drawColor);
         canvas.fillRoundRect(myrect);
         canvas.setColor(Color.BLACK);
         canvas.drawRoundRect(myrect);
         this.mybox = myrect.copy();
// draw comment bar
         if(isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
            canvas.setBackground(E_COMMENTCOLOR);
            canvas.setColor(E_COMMENTCOLOR);
            subrect = myrect.copy();
            subrect.left += 2;
            subrect.top += 8;
            subrect.right = subrect.left + 4;
            subrect.bottom -= 8;
            canvas.fillRect(subrect);
         }
// draw class name
         final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
         final Font titleFont = new Font(AbstractElement.font.getName(), Font.BOLD, AbstractElement.font.getSize());
         canvas.setFont(titleFont);
         canvas.setColor(Color.BLACK);
// draw code
         String t;
         do {
            t = getCode().get(classLines).trim();
            t = Java3Code.lineTrimSColon(t);
            if(classLines > 0) {
               t = "  " + t;
            }
            writeOutVariables(canvas, myrect.left + E_PADDING / 2, myrect.top + (1 + classLines) * fm.getHeight() + E_PADDING / 2, t);
            classLines++;
         }
         while(!getCode().get(classLines - 1).contains(";") && classLines < getCode().count());
         if(!isClosed()) {
            canvas.setFont(AbstractElement.font);
            while(classLines < getCode().count()) {
               writeOutVariables(canvas, myrect.left + E_PADDING / 2, myrect.top + (1 + classLines) * fm.getHeight() + E_PADDING / 2, " " + this.code.get(classLines));
               classLines++;
            }
         }
         myrect.left = _top_left.left + E_PADDING / 2;
         myrect.right -= E_PADDING / 2;
         myrect.top = _top_left.top + 3 * (E_PADDING / 2) + classLines * fm.getHeight();
         myrect.bottom = myrect.top;
// draws close children
         if(getChildQueue().isEmpty()) {
            subrect = getChildQueue().prepareDraw(_canvas);
            myrect.bottom += subrect.bottom;
            getChildQueue().draw(_canvas, myrect);
         }
         else {
            for(int i = 0; i < getChildQueue().getSize(); i++) {
               final AbstractElement root = getChildQueue().getElement(i);
               if(root.getRoot().isClosed()) {
                  subrect = getChildQueue().getElement(i).prepareDraw(_canvas);
                  myrect.bottom = myrect.top + subrect.bottom;
                  getChildQueue().getElement(i).draw(_canvas, myrect);
                  myrect.top += subrect.bottom + 1;
               }
            }
// draw box around
            canvas.setColor(Color.BLACK);
            canvas.drawRect(myrect);
         }
// draw thick line
         myrect.top = this.rect.top + fm.getHeight() * classLines + 3 * (E_PADDING / 2) - 1;
         canvas.drawRect(myrect);
// draw open children
         myrect.left = this.rect.left + this.mywidth;
         myrect.top = this.rect.top;
         for(int i = 0; i < getChildQueue().getSize(); i++) {
            final AbstractElement root = getChildQueue().getElement(i);
            if(!root.getRoot().isClosed()) {
               subrect = getChildQueue().getElement(i).prepareDraw(_canvas);
               myrect.right = myrect.left + subrect.right;
               myrect.bottom = myrect.top + subrect.bottom;
               getChildQueue().getElement(i).draw(_canvas, myrect);
               myrect.left = myrect.right + 1;
            }
         }
         this.rect = this.mybox.copy();
      }

       @Override()
       public String getName() {
         return "Class";
      }


       @Override()
       public StringList parseGlobalNames(globalType kind) {
         final StringList gVars = super.parseGlobalNames(kind);
         for(int i = 0; i < getChildQueue().getSize(); i++) {
            if(getElement(i) instanceof RootElement) {
               gVars.add(((RootElement) getElement(i)).parseGlobalNames(kind));
            }
         }
         if(kind.equals(globalType.CLASSONLY) || kind.equals(globalType.ALLGLOBALS)) {
            gVars.add(getRootName());
         }
         if(isRoot() && kind.equals(globalType.ALLGLOBALS)) {
            this.globalNames = gVars;
         }
         return gVars;
      }

       @Override()
       public Rect prepareDraw(Canvas _canvas) {
         if(getParent() instanceof CompilationUnit) {
            setClosed(false);
         }
         Rect subrect = new Rect();
         final Rect myrect = new Rect();
         myrect.top = 0;
         myrect.left = 0;
         final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
         final Font titleFont = new Font(AbstractElement.font.getName(), Font.BOLD, AbstractElement.font.getSize());
         _canvas.setFont(titleFont);
// top
         myrect.right = 2 * E_PADDING;
         int startVars = 0;
         do {
            final int w = _canvas.stringWidth(this.code.get(startVars));
            if(myrect.right < w + E_PADDING) {
               myrect.right = w + E_PADDING;
            }
            startVars++;
         }
         while(!getCode().get(startVars - 1).contains(";") && startVars < getCode().count());
         if(!isClosed()) {
            while(startVars < getCode().count()) {
               final int w = _canvas.stringWidth(this.code.get(startVars++));
               if(myrect.right < w + 2 * E_PADDING) {
                  myrect.right = w + 2 * E_PADDING;
               }
            }
         }
         myrect.bottom = 3 * (E_PADDING / 2) + startVars * fm.getHeight();
// children
         if(getChildQueue().isEmpty()) {
            subrect = getChildQueue().prepareDraw(_canvas);
            myrect.bottom += subrect.bottom;
            myrect.right = Math.max(myrect.right, subrect.right + 2 * E_PADDING);
         }
         else {
            for(int m = 0; m < getChildQueue().getSize(); m++) {
               final AbstractElement root = getChildQueue().getElement(m);
               if(root.getRoot().isClosed()) {
                  subrect = root.prepareDraw(_canvas);
                  myrect.bottom += subrect.bottom + 1;
                  myrect.right = Math.max(myrect.right, subrect.right + 2 * E_PADDING);
               }
            }
         }
         myrect.bottom += E_PADDING;
// this class size
         this.mywidth = myrect.right - myrect.left;
         this.myheight = myrect.bottom - myrect.top;
// this class + all Open children
         for(int m = 0; m < getChildQueue().getSize(); m++) {
            final AbstractElement root = getChildQueue().getElement(m);
            if(!root.getRoot().isClosed()) {
               subrect = root.prepareDraw(_canvas);
               myrect.right = myrect.right + subrect.right + 1;
               if(subrect.bottom > myrect.bottom) {
                  myrect.bottom = subrect.bottom;
               }
            }
         }
// total rect size
         setWidth(myrect.right - myrect.left);
         setHeight(myrect.bottom - myrect.top);
         _canvas.setFont(AbstractElement.font);
         return myrect;
      }

}
