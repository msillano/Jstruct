//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-15 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//
   package lu.fisch.structorizer.elements;

   import lu.fisch.structorizer.elements.JMethod;
/**
 * class for errors, used by all Element.analyze().
 * Stores the error message and a reference to the bogus element.
 *
 * <BR><BR>Source build by JStruct.<BR>
 *
 * @version 1.02.01  build 5  (2015.03.27-17:22:30) Updated to java 1.8
 * @version <br>1.01.01  build 20  (2012.03.10-17:53:38) JStruct-aware version
 * @version <BR>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
   public class DetectedError {

      /* class global variables */
      private String error = null;
      private AbstractElement abstractElement = null;


/**
 * The constructor
 * @param _error String
 * @param _ele AbstractElement
 */
       public DetectedError(String _error, AbstractElement _ele) {
         this.error = _error;
         this.abstractElement = _ele;
      }


/**
 * getter for the bogus element.
 * @return AbstractElement
 */
       public AbstractElement getElement() {
         return this.abstractElement;
      }

// getter for the formatted error description.

       @Override()
       public String toString() {
         if(this.abstractElement != null) {
            this.error = this.error.replaceAll("«", "�");
            this.error = this.error.replaceAll("»", "�");
            if (this.abstractElement.getClass().getSimpleName().equals("JMethod"))
               return this.abstractElement.getName() + " �" + ((JMethod)this.abstractElement).getRootName() + "�: " + this.error;
            else
               return this.abstractElement.getName() + " �" + this.abstractElement.getCode().get(0) + "�: " + this.error;
         }
         return "No error?";
      }

}
