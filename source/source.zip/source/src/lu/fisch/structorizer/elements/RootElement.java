//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\RootElement.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
package lu.fisch.structorizer.elements;

import java.util.Stack;
import java.util.Vector;

import javax.swing.JLabel;

import lu.fisch.structorizer.io.Ini;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * RootElements (JMethod, JClass and CompilationUnit) differs from standard Elements.
 * All RootElements have a "children" Subqueue.
 * <br />RootElement responsibilities: <ul>
 * <li> Editing  "children" Subqueue: see
 * {@link #moveUp(AbstractElement) moveUp},
 * {@link #moveDown(AbstractElement) moveDown},
 * {@link #addAfter(AbstractElement, AbstractElement) addAfter},
 * {@link #addBefore(AbstractElement, AbstractElement) addBefore},
 * {@link #removeElement(AbstractElement) removeElement}.
 * <li> Edit Undo and Redo functionality: see
 * {@link #clearUndo() clearUndo},
 * {@link #clearRedo() clearRedo},
 * {@link #addUndo() addUndo},
 * {@link #canUndo() canUndo},
 * {@link #canRedo() canRedo},
 * {@link #redo() redo},
 * {@link #undo() undo}.
 * <li> Any  RootElements manages a list of Variables and Globals to fit requests of analize and highlight functions;
 * see {@link #getGlobalNames() getGlobalNames},
 * {@link #parseVarNames() parseVarNames}.
 * <li> Error list management and formatting:
 * see {@link #addError(Vector, DetectedError, int) addError},
 * {@link #getErrors() getErrors}.
 * <li> INI file read/update for some options: see
 * {@link #loadFromINI()},
 * {@link #saveToINI()}.
 * </ul><br>
 *
 *
 * Source build by JStruct.<br />
 *
 * @version 1.01.01  build 21  (2012.03.14-15:33:14) JStruct-aware version
 * @version <br />1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public abstract class RootElement extends AbstractElement {

	/**
	* This enum defines style for globals variables
	*/
	enum globalType {

		/* enum global variables */
		CLASSONLY, METHODONLY, VARONLY, ALLGLOBALS

	}

	/**
	*======================================= ERRORS
	* The method addError
	* @param _errors Vector<DetectedError>
	* @param error DetectedError
	* @param errorNo int
	*/
	public static void addError(Vector<DetectedError> _errors,
			DetectedError error, int errorNo) {
		switch (errorNo) {
		case 1:
			if (check1) {
				_errors.add(error);
			}
			break;
		case 2:
			if (check2) {
				_errors.add(error);
			}
			break;
		case 3:
			if (check3) {
				_errors.add(error);
			}
			break;
		case 4:
			if (check4) {
				_errors.add(error);
			}
			break;
		case 5:
			if (check5) {
				_errors.add(error);
			}
			break;
		case 6:
			if (check6) {
				_errors.add(error);
			}
			break;
		case 7:
			if (check7) {
				_errors.add(error);
			}
			break;
		case 8:
			if (check8) {
				_errors.add(error);
			}
			break;
		case 9:
			if (check9) {
				_errors.add(error);
			}
			break;
		case 10:
			if (check10) {
				_errors.add(error);
			}
			break;
		case 11:
			if (check11) {
				_errors.add(error);
			}
			break;
		case 12:
			if (check12) {
				_errors.add(error);
			}
			break;
		case 13:
			if (check13) {
				_errors.add(error);
			}
			break;
		default:
			_errors.add(error);
		}
	}

	/**
	* The method errorMsg
	* @param _label JLabel
	* @param _rep String
	* @return String
	*/
	public static String errorMsg(JLabel _label, String _rep) {
		String res = _label.getText();
		res = res.replaceAll("%", _rep);
		return res;
	}

	/**
	* The method loadFromINI
	*/
	public static void loadFromINI() {
		final Ini ini = Ini.getInstance();
		ini.load();
		check1 = ini.getProperty("check1", "1").equals("1");
		check2 = ini.getProperty("check2", "1").equals("1");
		check3 = ini.getProperty("check3", "1").equals("1");
		check4 = ini.getProperty("check4", "1").equals("1");
		check5 = ini.getProperty("check5", "1").equals("1");
		check6 = ini.getProperty("check6", "1").equals("1");
		check7 = ini.getProperty("check7", "1").equals("1");
		check8 = ini.getProperty("check8", "1").equals("1");
		check9 = ini.getProperty("check9", "1").equals("1");
		check10 = ini.getProperty("check10", "1").equals("1");
		check11 = ini.getProperty("check11", "1").equals("1");
		check12 = ini.getProperty("check12", "1").equals("1");
		check13 = ini.getProperty("check13", "1").equals("1");
	}

	/**
	* The method moveDown moves an AbstractElement in a Subqueue.
	* @param ele AbstractElement
	* @return boolean
	*/
	public static boolean moveDown(AbstractElement ele) {
		boolean res = false;
		AbstractElement _ele = ele;
		if (_ele != null && !(_ele instanceof Subqueue)) {
			if (_ele instanceof Finally || _ele instanceof Catch) {
				_ele = _ele.getParent();
			}
			final Subqueue myList = _ele.getMySubqueue();
			final int i = myList.getIndexOf(_ele);
			if (i >= 0 && i + 1 < myList.getSize()) {
				myList.removeElement(i);
				myList.insertElement(_ele, i + 1);
				_ele.getRoot().changed = true;
				_ele.setSelected(true);
				res = true;
			}
		}
		return res;
	}

	/**
	* The method moveUp moves an AbstractElement in a Subqueue.
	* @param ele AbstractElement
	* @return boolean
	*/
	public static boolean moveUp(AbstractElement ele) {
		boolean res = false;
		AbstractElement _ele = ele;
		if (_ele != null && !(_ele instanceof Subqueue)) {
			if (_ele instanceof Finally || _ele instanceof Catch) {
				_ele = _ele.getParent();
			}
			final Subqueue myList = _ele.getMySubqueue();
			final int i = myList.getIndexOf(_ele);
			if (i - 1 >= 0) {
				myList.removeElement(i);
				myList.insertElement(_ele, i - 1);
				_ele.getRoot().changed = true;
				_ele.setSelected(true);
				res = true;
			}
		}
		return res;
	}

	/**
	* The method saveToINI
	*/
	public static void saveToINI() {
		final Ini ini = Ini.getInstance();
		ini.load();
		ini.setProperty("check1", (check1 ? "1" : "0"));
		ini.setProperty("check2", (check2 ? "1" : "0"));
		ini.setProperty("check3", (check3 ? "1" : "0"));
		ini.setProperty("check4", (check4 ? "1" : "0"));
		ini.setProperty("check5", (check5 ? "1" : "0"));
		ini.setProperty("check6", (check6 ? "1" : "0"));
		ini.setProperty("check7", (check7 ? "1" : "0"));
		ini.setProperty("check8", (check8 ? "1" : "0"));
		ini.setProperty("check9", (check9 ? "1" : "0"));
		ini.setProperty("check10", (check10 ? "1" : "0"));
		ini.setProperty("check11", (check11 ? "1" : "0"));
		ini.setProperty("check12", (check12 ? "1" : "0"));
		ini.setProperty("check13", (check13 ? "1" : "0"));
	}

	/**
	* The method setCheck1
	* @param check1 boolean
	*/
	public static void setCheck1(boolean check1) {
		RootElement.check1 = check1;
	}

	/**
	* The method setCheck10
	* @param check10 boolean
	*/
	public static void setCheck10(boolean check10) {
		RootElement.check10 = check10;
	}

	/**
	* The method setCheck11
	* @param check11 boolean
	*/
	public static void setCheck11(boolean check11) {
		RootElement.check11 = check11;
	}

	/**
	* The method setCheck12
	* @param check12 boolean
	*/
	public static void setCheck12(boolean check12) {
		RootElement.check12 = check12;
	}

	/**
	* The method setCheck13
	* @param check13 boolean
	*/
	public static void setCheck13(boolean check13) {
		RootElement.check13 = check13;
	}

	/**
	* The method setCheck2
	* @param check2 boolean
	*/
	public static void setCheck2(boolean check2) {
		RootElement.check2 = check2;
	}

	/**
	* The method setCheck3
	* @param check3 boolean
	*/
	public static void setCheck3(boolean check3) {
		RootElement.check3 = check3;
	}

	/**
	* The method setCheck4
	* @param check4 boolean
	*/
	public static void setCheck4(boolean check4) {
		RootElement.check4 = check4;
	}

	/**
	* The method setCheck5
	* @param check5 boolean
	*/
	public static void setCheck5(boolean check5) {
		RootElement.check5 = check5;
	}

	/**
	* The method setCheck6
	* @param check6 boolean
	*/
	public static void setCheck6(boolean check6) {
		RootElement.check6 = check6;
	}

	/**
	* The method setCheck7
	* @param check7 boolean
	*/
	public static void setCheck7(boolean check7) {
		RootElement.check7 = check7;
	}

	/**
	* The method setCheck8
	* @param check8 boolean
	*/
	public static void setCheck8(boolean check8) {
		RootElement.check8 = check8;
	}

	/**
	* The method setCheck9
	* @param check9 boolean
	*/
	public static void setCheck9(boolean check9) {
		RootElement.check9 = check9;
	}

	/* class global variables */
	private int height = 0;
	private int width = 0;
	private boolean changed = false;
	private boolean closed = false;

	String JName;

	Subqueue childSubqueue;

	Stack<AbstractElement> undoList = new Stack<AbstractElement>();

	Stack<AbstractElement> redoList = new Stack<AbstractElement>();

	StringList globalNames = new StringList();

	StringList variables = new StringList();

	private Vector<DetectedError> errors = new Vector<DetectedError>();

	/** enables error 1 analyze   */
	public static volatile boolean check1 = false;

	/** enables error 2 analyze   */
	public static volatile boolean check2 = false;

	/** enables error 3 analyze   */
	public static volatile boolean check3 = false;

	/** enables error 4 analyze   */
	public static volatile boolean check4 = false;

	/** enables error 5 analyze   */
	public static volatile boolean check5 = false;

	/** enables error 6 analyze   */
	public static volatile boolean check6 = false;

	/** enables error 7 analyze   */
	public static volatile boolean check7 = false;

	/** enables error 8 analyze   */
	public static volatile boolean check8 = false;

	/** enables error 9 analyze   */
	public static volatile boolean check9 = false;

	/** enables error 10 analyze   */
	public static volatile boolean check10 = false;

	/** enables error 11 analyze   */
	public static volatile boolean check11 = false;

	/** enables error 12 analyze   */
	public static volatile boolean check12 = false;

	/** enables error 13 analyze   */
	public static volatile boolean check13 = false;

	/**
	 * ====================================================================
	 */
	public RootElement() {
		super();
		this.childSubqueue = new Subqueue();
		this.childSubqueue.setParent(this);
	}

	/**
	 * The constructor RootElement
	 * @param _strings String
	 */
	public RootElement(String _strings) {
		super(_strings);
		this.childSubqueue = new Subqueue();
		this.childSubqueue.setParent(this);
	}

	/**
	 * The constructor RootElement
	 * @param _strings StringList
	 */
	public RootElement(StringList _strings) {
		super(_strings);
		this.childSubqueue = new Subqueue();
		this.childSubqueue.setParent(this);
	}

	/**
	* The method addAfter adds _new after  _ele in a Subqueue.
	* @param _ele AbstractElement
	* @param _new AbstractElement
	*/
	public void addAfter(AbstractElement _ele, AbstractElement _new) {
		if (_ele != null && _new != null) {
			Subqueue myList;
			int pos = -1;
			if (_ele instanceof Finally && _ele.isEmpty()) {
				// special case for finally if it is closed
				myList = ((Finally) _ele).getFinallySubqueue();
			} else {
				if (_ele instanceof CompilationUnit) {
					myList = ((RootElement) _ele).childSubqueue;
					pos = myList.getIndexOf(_ele);
				} else {
					if (_ele instanceof Subqueue) {
						myList = (Subqueue) _ele;
					} else {
						if (_ele.getParent() instanceof Subqueue) {
							myList = (Subqueue) _ele.getParent();
							pos = myList.getIndexOf(_ele);
						} else {
							if (_ele.getParent().getParent() instanceof Subqueue) {
								myList = (Subqueue) _ele.getParent()
										.getParent();
								pos = myList.getIndexOf(_ele.getParent());
							} else {
								return;
							}
						}
					}
				}
			}
			// now adds
			if (pos >= 0) {
				myList.insertElement(_new, pos + 1);
			} else {
				myList.addElement(_new);
			}
			_new.setParent(myList);
			_ele.selected = false;
			_new.selected = true;
			if (_new instanceof JMethod) {
				if (myList.getParent() instanceof JClass) {
					((JMethod) _new).setClosed(true);
				}
			}
			if (_new instanceof JClass) {
				((JClass) _new).setClosed(true);
			}
			this.changed = true;
		}
	}

	/**
	 * The method addBefore adds _new before  _ele in a Subqueue.
	 * @param _ele AbstractElement
	 * @param _new AbstractElement
	 */
	public void addBefore(AbstractElement _ele, AbstractElement _new) {
		Subqueue myList;
		int pos = -1;
		if (_ele instanceof Finally && _ele.isEmpty()) {
// special case for finally if it is closed
			myList = ((Finally) _ele).getFinallySubqueue();
		} else {
			if (_ele instanceof Subqueue) {
				myList = (Subqueue) _ele;
			} else {
				if (_ele.getParent() instanceof Subqueue) {
					myList = (Subqueue) _ele.getParent();
					pos = myList.getIndexOf(_ele);
				} else {
					if (_ele.getParent().getParent() instanceof Subqueue) {
						myList = (Subqueue) _ele.getParent().getParent();
						pos = myList.getIndexOf(_ele.getParent());
					} else {
						return;
					}
				}
			}
		}
// now adds
		if (pos >= 0) {
			myList.insertElement(_new, pos);
		} else {
			myList.addElement(_new);
		}
		_new.setParent(myList);
		_ele.selected = false;
		_new.selected = true;
		this.changed = true;
	}

	/**
	 * adds an AbstractElement to the childSubqueue
	 * @param _ele AbstractElement
	 */
	public void addElement(AbstractElement _ele) {
		this.childSubqueue.addElement(_ele);
	}

	/**
	 * using only top root element
	 */
	public void addUndo() {
		getRoot().undoList.add(getRoot().childSubqueue.copy());
		clearRedo();
	}

	/**
	 * condition, open not allowed if parent is closed, and not first root
	 * @return boolean
	 */
	public boolean allowsClose() {
		if (isClosed()
				&& getParentElement() != null
				&& ((RootElement) getParentElement()).isClosed()
				&& getParentElement().getParentElement() != null
				&& !(getParentElement().getParentElement() instanceof CompilationUnit)) {
			return false;
		}
		return true;
	}

	@Override()
	public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
		final Vector<DetectedError> errs = this.childSubqueue.analyze(_errors);
		return errs;
	}

	/**
	 *  returns true if redo is allowed.
	 * @return boolean
	 */
	public boolean canRedo() {
		return getRoot().redoList.size() > 0;
	}

	/**
	 *  returns true if undo is allowed.
	 * @return boolean
	 */
	public boolean canUndo() {
		return getRoot().undoList.size() > 0;
	}

	/**
	 * true if _child is child of _parent
	 * @param _child
	 * @param _parent
	 * @return boolean
	 */
	public boolean checkChild(AbstractElement _child, AbstractElement _parent) {
		AbstractElement tmp = _child;
		boolean res = false;
		if (tmp != null) {
			while (tmp.getParent() != null && res == false) {
				if (tmp.getParent() == _parent) {
					res = true;
				}
				tmp = tmp.getParent();
			}
		}
		return res;
	}

	/**
	 * The method clearRedo
	 */
	public void clearRedo() {
		getRoot().redoList = new Stack<AbstractElement>();
	}

	/**
	 * The method clearUndo
	 */
	public void clearUndo() {
		getRoot().undoList = new Stack<AbstractElement>();
	}

	/**
	 * getter for the childSubqueue
	 * @return the childSubqueue
	 */
	public Subqueue getChildQueue() {
		return this.childSubqueue;
	}

	/**
	 * returns declaration code line only.
	 * @return String
	 */
	public String getDeclaration() {
		Java3Code lines = new Java3Code(this.code);
		lines.killComments();
		String declaration = "";
		for (String dec:lines){
			dec = dec.trim();
			if (dec.length()>0){
				if (dec.charAt(0) == '@'){
					declaration += dec + "\n";
				} else if (dec.endsWith(";")){
					declaration += " " + dec;
					return Java3Code.lineTrimSColon(declaration);
				} else
					declaration += " " + dec;
			}
		}
		declaration = Java3Code.lineTrimSColon(declaration);
		return declaration;
	}

	/**
	 * getter for childSubqueue Element
	 * @return an AbstractElement
	 * @param _index int
	 */
	public AbstractElement getElement(int _index) {
		return this.childSubqueue.getElement(_index);
	}

	/**
	 * getter for errors Vector
	 * @return the errors
	 */
	public Vector<DetectedError> getErrors() {
		return this.errors;
	}

	@Override()
	public Java3Code getFullText() {
		final Java3Code text1 = super.getFullText();
		text1.add(this.childSubqueue.getFullText());
		return text1;
	}

	@Override()
	public StringList getGlobalNames() {
		if (getParent().getParent() != null
				&& getParent().getParent() instanceof CompilationUnit) {
			return this.globalNames;
		}
		return super.getGlobalNames();
	}

	/**
	* getter for height
	* @return the height
	*/
	public int getHeight() {
		return this.height;
	}

	/**
	 * The method getIndexOf returns the position index of an AbstractElement
	 * in this.childSubqueue
	 * @param _ele AbstractElement
	 * @return int
	 */
	public int getIndexOf(AbstractElement _ele) {
		return this.childSubqueue.getChildren().indexOf(_ele);
	}

	/**
	    * getter for JName
	    * @return the JName
	    */

	public String getJName() {
		if (this.JName == null)
			getRootName();
		return this.JName;
	}

	/**
	* getter for top CompilationUnit
	* @return RootElement
	*/
	public RootElement getProgram() {
		AbstractElement x;
		x = this;
		while (!(x instanceof CompilationUnit)) {
			x = x.getParent();
		}
		return (RootElement) x;
	}

	@Override()
	public RootElement getRoot() {
		if (this instanceof CompilationUnit) {
			return this;
		}
		if (isRoot()) {
			return this;
		}
		return getParent().getRoot();
	}

// return global code declarations lines array, Class/Method declaration stripped.

	/**
	* The method getRootName returns the nome of root Element (Method or Class).
	* @return String
	*/
	public abstract String getRootName();

	/**
	* getter for the childSubqueue Elements size
	* @return the number of children Elements
	*/
	public int getSize() {
		return this.childSubqueue.getSize();
	}

	/**
	 * getter for width
	 * @return the width
	 */
	public int getWidth() {
		return this.width;
	}

	/**
	 * getter for changed attribute
	 * @return the changed
	 */
	public boolean isChanged() {
		return this.changed;
	}

	/**
	 * getter for closed attribute
	 * @return boolean
	 */
	public boolean isClosed() {
		return this.closed;
	}

	@Override()
	public boolean isEmpty() {
		return this.childSubqueue.isEmpty();
	}

	/**
	* The method isRoot
	* @return boolean
	*/
	public boolean isRoot() {
		return true;
	}

	/**
	 * get globals vars names plus this name
	 * @param kind globalType
	 * @return StringList
	 */
	public StringList parseGlobalNames(globalType kind) {
//                             modifiers type name initializer ;
		final StringList names = new StringList();
		if (kind.equals(globalType.VARONLY)	|| kind.equals(globalType.ALLGLOBALS)) {
			final Java3Code gLines = new Java3Code(getGLines());
			gLines.onlyCode().spaceTokenize(false);
//test: System.out.println("globalLines:"+lines.getCommaText());
			for (String line: gLines) {
				if (line == null) {
					continue;
				}
				final String[] parts = line.trim().split(" ");
				switch (parts.length) {
				case 0:
					break;
				case 1:
					if ( parts[0].length()> 0 && Character.isJavaIdentifierStart(parts[0].charAt(0))) {
						names.add(parts[0]);
					}
					break;
				default:
					Java3Code.lineParts2Vars(parts, names, true);
				}
			} // end for

		}
//debug   System.out.println("globalVar " + this.JName + ": "   + names.getCommaText());
		return names;
	}

	@Override()
	public StringList parseVarNames() {
		Java3Code theCode = getFullText();
		this.variables = theCode.parseVarNames();
// extra vars not in code
		this.variables.addIfNew(this.childSubqueue.parseVarNames());
		return this.variables;
	}

	/**
	 * The method redo: undoes the undo effect
	 */
	public void redo() {
		final RootElement root = getRoot();
		if (root.redoList.size() > 0) {
			root.changed = true;
			root.undoList.add(root.childSubqueue.copy());
			root.childSubqueue = (Subqueue) root.redoList.pop();
			root.childSubqueue.setParent(root);
		}
	}

	/**
	 * removes an AbstractElement from the childSubqueue
	 * @param _ele AbstractElement
	 */
	public void removeElement(AbstractElement _ele) {
		if (_ele != null && !(_ele instanceof Subqueue)) {
			_ele.getMySubqueue().removeElement(_ele);
			_ele.getRoot().changed = true;
		}
	}

	/**
	 * removes an AbstractElement from the childSubqueue
	 * @param i int
	 */
	public void removeElement(int i) {
		this.childSubqueue.removeElement(getElement(i));
	}

	@Override()
	public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
		final AbstractElement selMe = super
				.selectElementByCoord(_x, _y, update);
		AbstractElement selCh = null;
		if (!isClosed()) {
			selCh = this.childSubqueue.selectElementByCoord(_x, _y, update);
		} else {
			this.childSubqueue.selectElementByCoord(-1, -1, update);
		}
		if (selCh != null) {
			if (update) {
				this.selected = false;
			}
			return selCh;
		}
		return selMe;
	}

	/**
	 * @param changed the changed to set
	 */
	public void setChangedNow(boolean changed) {
		this.changed = changed;
	}

	/**
	 * @param sQueue the childSubqueue to set
	 */
	public void setChildQueue(Subqueue sQueue) {
		this.childSubqueue = sQueue;
	}

	/**
	 * The method setClosed closes this and all root child.
	 * @param isClosed boolean
	 */
	public void setClosed(boolean isClosed) {
		if (allowsClose()) {
			this.closed = isClosed;
			if (isClosed) {
				for (int i = 0; i < getSize(); i++) {
					if (getElement(i) instanceof RootElement) {
						((RootElement) getElement(i)).setClosed(true);
					}
				}
			}
		}
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(Vector<DetectedError> errors) {
		this.errors = errors;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * @param jName the jName to set
	 */
	public void setJName(String jName) {
		this.JName = jName;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	@Override()
	public String toString(String indent) {
		String tree = indent + this.getClass().getSimpleName() + "\n";
		tree += this.childSubqueue.toString(indent + "   ");
		tree += indent + "+++ ends " + this.getClass().getSimpleName() + "\n";
		return tree;
	}

	/**
	 * The method undo undoes last change
	 */
	public void undo() {
		final RootElement root = getRoot();
		if (root.undoList.size() > 0) {
			root.changed = true;
			root.redoList.add(root.childSubqueue.copy());
			root.childSubqueue = (Subqueue) root.undoList.pop();
			root.childSubqueue.setParent(root);
		}
	}

	@Override()
	public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
//debug     System.out.println("repace txt:"+ doTxt + " comments" + doComm);
		int x = this.childSubqueue.wordReplace(old, by, doTxt, doComm);
		x += super.wordReplace(old, by, doTxt, doComm);
		return x;
	}

	private StringList getGLines() {
	    Java3Code jcode = new Java3Code(this.code).killComments();
	    final StringList lines = jcode.getStringList();
		while (lines.get(0).trim().charAt(0) == '@') {
			lines.delete(0);
		}
		lines.delete(0);
		return lines;
	}

}
