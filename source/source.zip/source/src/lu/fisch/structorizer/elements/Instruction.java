//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\Instruction.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.ErrorMessages;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Instruction block, for <code>expression</code> statements.
 * Certain kinds of expressions may be used as statements by following them with semicolons.
 *
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-sequence.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-sequence.png" width="200" alt="" border="0"></td>
 *
 *<td>  <i>ExpressionStatement:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;StatementExpression </i><code>;</code><i><br>
 *StatementExpression:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp    Assignment<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   PreIncrementExpression<br>
 *&nbsp;&nbsp;&nbsp;&nbsp    PreDecrementExpression<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   PostIncrementExpression<br>
 *&nbsp;&nbsp;&nbsp;&nbsp    PostDecrementExpression<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   MethodInvocation<br>
 *&nbsp;&nbsp;&nbsp;&nbsp    ClassInstanceCreationExpression<br>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd>The Instruction block is a white sequence block.<br/>
 *<dd>In menu the Instruction icon is <img src="../../../../resources/024_color_white.png" border="1" width="16" height="16" alt=""><BR><BR>
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an Instruction block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;&lt;Expression>[; &lt;Expression>] [;] </pre>
 *Comments are allowed in Instruction code.    <BR><BR>
 *<dt><span class="strong">Input:</span></dt>
 *<dd>The user defined "Input" keyword (default: "read") is special:<ul>
 * <li><code> 'read x'</code>(x is a String) is replaced by standard input read code.
 * <li><code> 'x = read("Please input a value")'</code> is replaced by a pop-up code.
 * <li> The conversion "read" &lt;=> code is reversible
 * <li>The "Input" keyword can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.
 *</ul></dd>
 *<dt><span class="strong">Output:</span></dt>
 *<dd>The user defined "Output" keyword (default: "write") is special:<ul>
 * <li><code> 'write x'</code>(x is a String) is replaced by standard output writeln() code.
 * <li><code> 'write("Result is " + t)'</code> is replaced by a pop-up code.
 * <li> The conversion "write" &lt;=> code is reversible
 * <li>The "Output" keyword can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.
 *</ul></dd>
 *
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.01  build 9  (2015.04.09-15:18:29) Updated to java 1.8
 * @version <dd> 1.01.01  build 28  (2012.03.13-15:15:20) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Instruction
extends AbstractElement {

/**
 * The default constructor
 */
   public Instruction() {
      super();
   }

/**
 * The constructor from String code
 * @param _strings String
 */
   public Instruction(String _strings) {
      super(_strings);
      setCode(_strings);
   }

/**
 * The constructor for StringList code
 * @param _strings StringList
 */
   public Instruction(StringList _strings) {
      super(_strings);
      setCode(_strings);
   }

   @Override()
   public Vector <DetectedError> analyze(Vector <DetectedError> errors) {
      final StringList vars = parseVarNames();
//      Menu.error07_3.text=«%» non è un nome valido per una variabile!
      for(int i = 0; i < vars.count(); i++) {
         if(!Java3Code.testIdentifier(vars.get(i))) {
            final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error07_3, vars.get(i)), this);
            RootElement.addError(errors, e, 7);
         }
      }
//      Menu.error10_1.text=
      int sclon = 0;
      for(int i = 0; i < this.code.count(); i++) {
         if(this.code.get(i).contains(";")) {
            sclon++;
         }
      }
      if(sclon + 1 < this.code.count()) {
         final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error10_1, ""), this);
         RootElement.addError(errors, e, 10);
      }
      return errors;
   }

   @Override()
   public AbstractElement copy() {
      final Instruction ele = new Instruction(getCode().copy());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      return ele;
   }

   @Override()
   public void draw(Canvas _canvas, Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      if(this.selected == true) {
         drawColor = AbstractElement.E_DRAWCOLOR;
      }
      this.rect = _top_left.copy();
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
      myrect = _top_left.copy();
      canvas.fillRect(myrect);
// draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         myrect.left += 2;
         myrect.top += 2;
         myrect.right = myrect.left + 4;
         myrect.bottom -= 1;
         canvas.fillRect(myrect);
      }
      for(int i = 0; i < this.code.count(); i++) {
         final String text1 = this.code.get(i);
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, _top_left.left + AbstractElement.E_PADDING / 2, _top_left.top + AbstractElement.E_PADDING / 2 + (i + 1) * fm.getHeight(), text1);
      }
      canvas.setColor(Color.BLACK);
      canvas.drawRect(_top_left);
   }

   @Override()
   public String getName() {
      return "Sequence";
   }

   @Override()
   public StringList parseVarNames() {
      Java3Code theCode = getFullText();
      return theCode.parseVarNames();
   }

   @Override()
   public Rect prepareDraw(Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      this.rect.right = 0;
      this.rect.bottom = 0;
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      this.rect.right = E_PADDING;
      for(int i = 0; i < this.code.count(); i++) {
         if(this.rect.right < _canvas.stringWidth(this.code.get(i)) + 1 * AbstractElement.E_PADDING) {
            this.rect.right = _canvas.stringWidth(this.code.get(i)) + 1 * AbstractElement.E_PADDING;
         }
      }
      this.rect.bottom = E_PADDING + this.code.count() * fm.getHeight();
      return this.rect;
   }

}
