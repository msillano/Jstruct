//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\JMethod.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
   package lu.fisch.structorizer.elements;
   import java.awt.Color;
   import java.awt.Font;
   import java.awt.FontMetrics;
   import java.util.Vector;
   import lu.fisch.graphics.Canvas;
   import lu.fisch.graphics.Rect;
   import lu.fisch.utils.ErrorMessages;
   import lu.fisch.utils.Java3Code;
   import lu.fisch.utils.StringList;

/**
 * JMethod block, for <code>Method, Static initializer</code> statements. <BR>
 * A method declares executable code that can be invoked, passing a fixed number of values as arguments.
 * A static initializer declared in a class is executed when the class is initialized.
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-Alternative.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-alternative.png" width="200" alt="" border="0"></td>
 *  <td>  <i>IfThenStatement: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;    </i><code>if (</code><i> Expression </i><code>)</code><i> Statement <BR><br>
 *    IfThenElseStatement: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> Statement <BR><br>
 *   IfThenElseStatementNoShortIf: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> StatementNoShortIf  <BR>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd>The labels  "YES", "NOT" and the default code value ("&lt;condition>") can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.<br/>
 *<dd>The optional pre-keyword and post-keyword (default "if" and "?") can be changed in menu  options/parser <img src="../../../../resources/004_Make.png" border="1" width="16" height="16" alt="">.
 *<dd>In menu the Alternative icon is <img src="../../../../resources/060_conv_if.png" border="1" width="16" height="16" alt=""><BR><BR>
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an Alternative block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;pre-keyword>] &lt;condition>|(&lt;condition>) [&lt;post-keyword>]</pre>
 *Comments are not allowed in Alternative code.    <BR>
 *<hr>
 *<dt><span class="strong">enum</span></dt>
 *<dd>The Class block allows <b>enum</b> definition.<ul>
 *<li> The code in an Alternative block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;modifiers>] enum &lt;name>
 *&nbsp;&nbsp;&nbsp;&nbsp; [&lt;value>[(&lt;parameter>)],]*
 *&nbsp;&nbsp;&nbsp;&nbsp; &lt;value>[(&lt;parameter>)];
 *&nbsp;&nbsp;&nbsp;&nbsp;[[&lt;moreVariables>;]*] </pre>
 *<li> Methods can be added. </ul>
 *
 *</dd>
 *<dt><span class="strong">Analyze:</span></dt><i><ul>
 *<li>ERROR: the Class name is not a valid Java identifier.
 *<li>WARNING: the Class name is not capitalized.
 *<li>ERROR: a public Class must be in a file having same name.
 *<li>ERROR: Class name equal to an existing variable or parameter name.
 *<li>ERROR: not a valid Java identifier.
 *</ul></i>
 *
 * <BR>Source build by JStruct.<BR>
 *
 * @version 1.01.01  build 23  (2012.03.14-17:39:59) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
   public class JMethod
   extends RootElement {

	   /**
	    * Default constructor
	    */
       public JMethod() {
         super("void newMethod();");
      }

       /**
        * The constructor for String code
        * @param _strings String used as code
        */
       public JMethod(String _strings) {
         super(_strings);
      }


       /**
        * The constructor for StringList code
        * @param _strings StringList used as code
        */
       public JMethod(StringList _strings) {
         super(_strings);
      }

//       @Override()
       public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
         final Vector<DetectedError> errMethod = super.analyze(_errors);
         final String name = getRootName();
//debug System.out.println("JMethod name: "+ name) ;
         char start;
//       Menu.error05.text=Warning: L'identificatore «%» dovrebbe essere con iniziale in minuscolo.
         if(this.variables != null) {
            for(int i = 0; i < this.variables.count(); i++) {
               start = this.variables.get(i).charAt(0);
               if(Character.isUpperCase(start)) {
                  final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error05, this.variables.get(i)), this);
                  addError(errMethod, e, 5);
               }
               else {
                  if(!Java3Code.testIdentifier(this.variables.get(i))) {
                     final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_3, this.variables.get(i)), this);
                     addError(errMethod, e, 5);
                  }
               }
            }
         }
         start = name.charAt(0);
// Menu.error06.text=L'identificatore �%� deve essere con iniziale in minuscolo!
         if(!name.equals(getParent().getRoot().getRootName())) {
            if(Character.isUpperCase(start)) {
               final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error05, name), this);
               addError(errMethod, e, 6);
            }
         }
// Menu.error06_2.text=Error: Il nome del Metodo «%»  � duplicato.
         final String signature = getSignature();
         final StringList mNames = getParent().getRoot().parseGlobalNames(globalType.METHODONLY);
         if(mNames.getCount(signature) > 1) {
            final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_2, name), this);
            addError(errMethod, e, 6);
         }
// Menu.error06_3.text=Error: Il nome «%» non è valido in Java.
         if(!Java3Code.testIdentifier(name)) {
            final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_3, name), this);
            addError(errMethod, e, 6);
         }
// Menu.error06_4.text=Un Metodo («%») non può avere lo stesso nome di una variabile o di un parametero!
         for(int i = 0; i < this.variables.count(); i++) {
            if(this.variables.get(i).equals(name)) {
               final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error06_4, this.variables.get(i)), this);
               addError(errMethod, e, 6);
            }
         }
//  Menu.error07_2.text=�%� non � un nome valido per un parametro!
         final StringList params = getParametersNames();
         for(int i = 0; i < params.count(); i++) {
            if(!Java3Code.testIdentifier(params.get(i))) {
               final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error07_2, params.get(i)), this);
               addError(errMethod, e, 7);
            }
         }
//  Menu.error13_1.text=Questo method non ritorna alcun valore!
         if(!getRootName().equals(getParent().getRoot().getRootName()) && !getRootName().equals("main") && !getRootName().equals("static")) {
            if(!getDeclaration().contains("void") && !getDeclaration().contains("abstract")) {
               Java3Code jcode = getFullText();
               jcode.spaceTokenize(false).replace(" return ;", "");
               if(!jcode.contains("return") && !jcode.contains("System.exit")) {
                  final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error13_1, name), this);
                  addError(errMethod, e, 13);
               }
            }
         }
//  Menu.error13_2.text=Questo method non deve ritornare alcun valore!
         if(!getRootName().equals(getParent().getRoot().getRootName())) {
            if(getDeclaration().contains("void")) {
                Java3Code jcode = getFullText();
                jcode.spaceTokenize(false).replace(" return ;", "");
                if(jcode.contains("return")) {
                     final DetectedError e = new DetectedError(errorMsg(ErrorMessages.error13_2, name), this);
                     addError(errMethod, e, 13);
                  }
               }
         }
         return errMethod;
      }

       @Override()
       public AbstractElement copy() {
         final JMethod ele = new JMethod(getCode().copy());
         ele.setComment(getComment().copy());
         ele.setColor(getColor());
         ele.setClosed(isClosed());
         ele.setChildQueue(getChildQueue().copy());
         ele.getChildQueue().setParent(ele);
         return ele;
      }

       @Override()
       public void draw(Canvas _canvas, Rect _top_left) {
         final Rect myrect;
         if(this.code.count() == 0) {
            this.code.add("???");
         }
         else {
            if(this.code.get(0).trim().equals("")) {
               this.code.delete(0);
               this.code.insert("???", 0);
            }
         }
         Color drawColor = getColor();
         if(this.selected == true) {
            if(this.waited == true) {
               drawColor = AbstractElement.E_WAITCOLOR;
            }
            else {
               drawColor = AbstractElement.E_DRAWCOLOR;
            }
         }
         this.rect = _top_left.copy();
         myrect = _top_left.copy();
         final Canvas canvas = _canvas;
// erase background
         canvas.setBackground(drawColor);
         canvas.setColor(drawColor);
         canvas.fillRect(myrect);
// draw comment lateral mark
         if(isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
            canvas.setBackground(E_COMMENTCOLOR);
            canvas.setColor(E_COMMENTCOLOR);
            myrect.left += 2;
            myrect.top += 2;
            myrect.right = myrect.left + 4;
            myrect.bottom -= 2;
            canvas.fillRect(myrect);
         }
         final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
         final Font titleFont = new Font(AbstractElement.font.getName(), Font.BOLD, AbstractElement.font.getSize());
         canvas.setFont(titleFont);
// draw code
         int index = 0;
         String t = this.code.get(index++).trim();
         while(t.length() > 0 && t.charAt(0) == '@') {
            canvas.setFont(AbstractElement.font);
            canvas.setColor(Color.BLACK);
            writeOutVariables(canvas, this.rect.left + E_PADDING / 2, this.rect.top + index * fm.getHeight() + E_PADDING / 2, t);
            t = this.code.get(index++).trim();
         }
         canvas.setFont(titleFont);
         t = Java3Code.lineTrimSColon(t);
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, this.rect.left + E_PADDING / 2, this.rect.top + index * fm.getHeight() + E_PADDING / 2, t);
         canvas.setFont(AbstractElement.font);
         for(; index < this.code.count(); index++) {
            writeOutVariables(canvas, this.rect.left + E_PADDING / 2, this.rect.top + (1 + index) * fm.getHeight() + E_PADDING / 2, "    " + this.code.get(index));
         }
         if(!isClosed()) {
            this.rect.top = _top_left.top + fm.getHeight() * this.code.count() + E_PADDING;
            this.rect.left = _top_left.left;
            getChildQueue().draw(_canvas, this.rect);
         }
// draw box around
         canvas.setColor(Color.BLACK);
         canvas.drawRect(_top_left);
// draw thick line
         if(!isClosed()) {
            this.rect.top = _top_left.top + fm.getHeight() * this.code.count() + E_PADDING - 1;
            this.rect.left = _top_left.left;
            canvas.drawRect(this.rect);
         }
         this.rect = _top_left.copy();
      }

       @Override()
       public String getName() {
         return "Method";
      }


/**
 * The method getParametersNames
 * @return StringList
 */
       public StringList getParametersNames() {
    	 Java3Code dec = new Java3Code(getDeclaration());
         dec.onlyCode().spaceTokenize(false);
         final StringList params = dec.getParamNames();
         if(getRootName().equals("main")) {
            params.addIfNew("args");
         }
         return params;
      }


/**
 * The method getParametersTypes
 * @return StringList
 */
       public StringList getParametersTypes() {
      	 Java3Code dec = new Java3Code(getDeclaration());
		dec.killComments().spaceTokenize(false);
         final StringList params = dec.getParamTypes();
         if(getRootName().equals("main")) {
            params.addIfNew("String[]");
         }
         return params;
      }


/**
 * The method getReturnType
 * @return String
 */
       public String getReturnType() {
           Java3Code decl = new Java3Code(getDeclaration());
           decl.onlyCode().spaceTokenize(false);
         return decl.getMethodType();
      }


       @Override()
       public String getRootName() {
         Java3Code decl = new Java3Code(getDeclaration());
         String rName = decl.getMethodName();
// debug  System.out.println("Method name >"+rName+"<");
         if (rName != null)
                setJName(rName);
         return this.JName;
      }

       private String getSignature() {
         return getRootName() + "_" + getParametersTypes().getLongString().replace(" ", "_");
      }

       @Override()
       public StringList parseGlobalNames(globalType kind) {
         final StringList gVars = super.parseGlobalNames(kind);
         if(kind.equals(globalType.METHODONLY) || kind.equals(globalType.ALLGLOBALS)) {
            gVars.add(getSignature());
         }
         if(isRoot() && kind.equals(globalType.ALLGLOBALS)) {
            this.globalNames = gVars;
         }
         return gVars;
      }

       @Override()
       public StringList parseVarNames() {
         final StringList vars = super.parseVarNames();
         vars.addIfNew(getParametersNames());
         return vars;
      }

       @Override()
       public Rect prepareDraw(Canvas _canvas) {
         Rect subrect = new Rect();
         final Rect myrect = new Rect();
         myrect.top = 0;
         myrect.left = 0;
         final Font titleFont = new Font(AbstractElement.font.getName(), Font.BOLD, AbstractElement.font.getSize());
         _canvas.setFont(titleFont);
         final FontMetrics fm = _canvas.getFontMetrics(titleFont);
//         myrect.right = 2 * E_PADDING;
         myrect.right = E_PADDING;
         for(int i = 0; i < this.code.count(); i++) {
            final int w = _canvas.stringWidth(this.code.get(i));
            myrect.right = Math.max(myrect.right, w + E_PADDING);
         }
         myrect.bottom = E_PADDING + this.code.count() * fm.getHeight();
         _canvas.setFont(AbstractElement.font);
         if(!isClosed()) {
            subrect = getChildQueue().prepareDraw(_canvas);
            myrect.right = Math.max(myrect.right, subrect.right);
            myrect.bottom += subrect.bottom;
         }
         setWidth(myrect.right - myrect.left);
         setHeight(myrect.bottom - myrect.top);
         return myrect;
      }

}
