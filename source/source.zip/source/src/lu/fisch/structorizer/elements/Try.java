//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\Try.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Try block, for <code>try-catch-finally</code> statement. <BR>
 * A try statement executes a block. If a value is thrown and the try statement has
 * one or more catch clauses that can catch it, then control will be transferred to the
 * first such catch clause.
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-try-catch.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-case.png" width="200" alt="" border="0"></td>
 *  <td>  <i>Catches: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;CatchClause<br>
 *    &nbsp;&nbsp;&nbsp;&nbsp;Catches CatchClause<BR><br>
 *    CatchClause:<BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>catch (</code><i>  CatchFormalParameter </i><code>)</code><i> Block<BR><br>
 *    CatchFormalParameter:<BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp; [VariableModifiers] CatchType VariableDeclaratorId<BR><br>
 *    CatchType: <BR>
 *    &nbsp;&nbsp;&nbsp;&nbsp;ClassType<br>
 *    &nbsp;&nbsp;&nbsp;&nbsp;ClassType | CatchType<BR>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd> Designed like the Switch block, this block exists only inside a try block.
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in a Catch block must be a list:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;catch
 *&nbsp;&nbsp;&nbsp;&nbsp;[VariableModifiers] &lt;CatchType> &lt;VariableDeclaratorId>
 *&nbsp;&nbsp;&nbsp;&nbsp;...
 *&nbsp;&nbsp;&nbsp;&nbsp;[%]
 *</pre><br>
 *Comments are not allowed in Catch code.    <BR>
 *
 * <BR>Source build by JStruct.<BR>
 *
 * @version 1.01.01  build 24  (2012.03.14-19:28:14) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Try extends AbstractElement {

	/* class global variables */
	private Subqueue trySubqueue = new Subqueue();
    private Rect t = new Rect();
    private Rect r = new Rect();
	private Rect rc = new Rect();
	private Rect rf = new Rect();
	private Catch area_catch;
	private Finally area_finally;

	/**
	 * The default constructor
	 */
	public Try() {
		super();
		this.trySubqueue.setParent(this);
		setCode("try");
		setCatch(new Catch("catch\nException e\ndefault"));
		setFinally(new Finally("finally"));
	}

	/**
	 * The constructor from String code
	 * @param _strings String used as code
	 */
	public Try(String _strings) {
		super(_strings);
		this.trySubqueue.setParent(this);
//      this.setColor( E_TRYCOLOR);
		setCode(_strings);
		setCatch(new Catch("catch\nException e\ndefault"));
		setFinally(new Finally("finally"));
	}

	/**
	 * The constructor for StringList code
	 * @param _strings StringList used as code
	 */
	public Try(StringList _strings) {
		super(_strings);
		this.trySubqueue.setParent(this);
		setCode(_strings);
		setCatch(new Catch("catch\nException e\ndefault"));
		setFinally(new Finally("finally"));
	}

	@Override()
	public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
		Vector<DetectedError> errTry = this.trySubqueue.analyze(_errors);
		errTry = getCatch().analyze(errTry);
		return getFinally().analyze(errTry);
	}

	@Override()
	public AbstractElement copy() {
		final Try ele = new Try(getCode().copy());
		ele.setComment(getComment().copy());
		ele.setColor(getColor());
		ele.trySubqueue = this.trySubqueue.copy();
		ele.trySubqueue.setParent(ele);
		ele.setCatch((Catch) getCatch().copy());
		ele.setFinally((Finally) getFinally().copy());
		return ele;
	}

	@Override()
	public void draw(Canvas _canvas, Rect _top_left) {
		final Rect dr = _top_left.copy();
		final Rect drc = _top_left.copy();
        drc.top = dr.bottom - this.rc.bottom - this.rf.bottom ;
        drc.bottom = drc.top + this.rc.bottom;
		drc.left = dr.left + AbstractElement.E_PADDING - 1;
		final Rect drf = _top_left.copy();
		drf.top = drc.bottom;
		drf.left = drc.left;
//		drf.bottom = dr.bottom ;
// now draw group
		this_draw(_canvas, dr);
		this.area_catch.draw(_canvas, drc);
		this.area_finally.draw(_canvas, drf);
	}


    /**
     * setter for resources
     * @return area_catch
     */
    public void setResorce( String resource) {
        this.setCode("try  ("+resource+")");
    }

	/**
	 * getter for catch block
	 * @return area_catch
	 */
	public Catch getCatch() {
		return this.area_catch;
	}

	/**
	 * getter for Finally block
	 * @return area_finally
	 */
	public Finally getFinally() {
		return this.area_finally;
	}

	@Override()
	public Java3Code getFullText() {
	   final Java3Code text1 = super.getFullText();
       text1.add(this.trySubqueue.getFullText());
       if (!getCatch().isEmpty()) {
            text1.add(getCatch().getFullText());
        }
  		if (!getFinally().isEmpty()) {
			text1.add(getFinally().getFullText());
		}
		return text1;
	}

	@Override()
	public String getName() {
		return "Try-catch-finally block";
	}

	/**
	 * @return the trySubqueue
	 */
	public Subqueue getTrySubqueue() {
		return this.trySubqueue;
	}

	@Override()
	public boolean isEmpty() {
		return this.trySubqueue.isEmpty();
	}

	@Override()
	public StringList parseVarNames() {
		final StringList vars = this.trySubqueue.parseVarNames();
		vars.addIfNew(getCatch().parseVarNames());
		if (!getFinally().isEmpty()) {
			vars.addIfNew(getFinally().parseVarNames());
		}
		return vars;
	}

	@Override()
	public Rect prepareDraw(Canvas _canvas) {
		this.t.top = 0;
		this.t.left = 0;
		final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
		this.t.right = E_PADDING;
        for(int i = 0; i < this.code.count(); i++) {
             if(this.t.right < _canvas.stringWidth(this.code.get(i)) + 1 * AbstractElement.E_PADDING) {
                this.t.right = _canvas.stringWidth(this.code.get(i)) + 1 * AbstractElement.E_PADDING;
             }
          }
        this.t.bottom = E_PADDING + this.code.count() * fm.getHeight();
        this.rect = this.t.copy();

		this.r = this.trySubqueue.prepareDraw(_canvas);
		this.rect.right = Math.max(this.rect.right, this.r.right + E_PADDING);
		this.rect.bottom += this.r.bottom;
// forced children
		this.rc = this.area_catch.prepareDraw(_canvas);
        this.rect.right = Math.max(this.rect.right, this.rc.right+ E_PADDING);
		this.rect.bottom += this.rc.bottom;
		this.rf = this.area_finally.prepareDraw(_canvas);
        this.rect.right = Math.max(this.rect.right, this.rf.right+ E_PADDING);
		this.rect.bottom += this.rf.bottom;
 //       this.rect.bottom +=  E_PADDING;
		return this.rect;
	}

	@Override()
	public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
		AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
		final AbstractElement sel = this.trySubqueue.selectElementByCoord(_x,
				_y, update);
		final AbstractElement selc = this.area_catch.selectElementByCoord(_x,
				_y, update);
		final AbstractElement self = this.area_finally.selectElementByCoord(_x,
				_y, update);
		if (sel != null) {
			if (update) {
				this.selected = false;
			}
			selMe = sel;
		}
		if (selc != null) {
			if (update) {
				this.selected = false;
			}
			selMe = selc;
		}
		if (self != null) {
			if (update) {
				this.selected = false;
			}
			selMe = self;
		}
		return selMe;
	}

	/**
	 * setter for catch block
	 * @param  _catch block
	 */
	public void setCatch(Catch _catch) {
		this.area_catch = _catch;
		_catch.setParent(this);
	}

	@Override()
	public void setColor(Color _color) {
		super.setColor(_color);
		getFinally().setColor(_color);
		getCatch().setColor(_color);
	}

	/**
	 * setter for area_finally block
	 * @param _finally block
	 */
	public void setFinally(Finally _finally) {
		this.area_finally = _finally;
		_finally.setParent(this);
	}

	@Override()
	public void setSelected(boolean _sel) {
		this.selected = _sel;
	}

	@Override()
	public String toString(String indent) {
		String res = super.toString(indent);
		res += this.trySubqueue.toString(indent + "   ");
		res += getCatch().toString(indent);
		if (!getFinally().isEmpty()) {
			res += getFinally().toString(indent);
		}
		return res;
	}

	@Override()
	public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
		int x = super.wordReplace(old, by, doTxt, doComm);
		x += this.trySubqueue.wordReplace(old, by, doTxt, doComm);
		x += getCatch().wordReplace(old, by, doTxt, doComm);
		if (!getFinally().isEmpty()) {
			x += getFinally().wordReplace(old, by, doTxt, doComm);
		}
		return x;
	}

	private void this_draw(Canvas _canvas, Rect _top_left) {
		Rect myrect = new Rect();
		Color drawColor = getColor();
		final FontMetrics fm = _canvas.getFontMetrics(font);
		if (this.selected == true) {
			drawColor = AbstractElement.E_DRAWCOLOR;
		}
		final Canvas canvas = _canvas;
		canvas.setBackground(drawColor);
		canvas.setColor(drawColor);
// draw background
		myrect = _top_left.copy();
		canvas.fillRect(myrect);
// draw shape
		this.rect = _top_left.copy();
		canvas.setColor(Color.BLACK);
		canvas.drawRect(_top_left);
		myrect = _top_left.copy();


//		myrect.bottom = _top_left.top + fm.getHeight() + E_PADDING;
        myrect.bottom = _top_left.top + this.t.bottom;
        canvas.drawRect(myrect);
		myrect.bottom = _top_left.bottom;
		myrect.top = myrect.bottom ;
		canvas.drawRect(myrect);
		myrect = _top_left.copy();
		myrect.right = myrect.left + E_PADDING;
		canvas.drawRect(myrect);
// fill shape
		canvas.setColor(drawColor);
		myrect.left = myrect.left + 1;
		myrect.top = myrect.top + 1;
		myrect.right = myrect.right - 1;
		canvas.fillRect(myrect);
		myrect = _top_left.copy();
//		myrect.bottom = _top_left.top + fm.getHeight() + E_PADDING;
        myrect.bottom = _top_left.top + this.t.bottom;
        myrect.left = myrect.left + 1;
		myrect.top = myrect.top + 1;
		myrect.right = myrect.right - 1;
		canvas.fillRect(myrect);
		myrect.bottom = _top_left.bottom;
		myrect.top = myrect.bottom ;
		myrect.left = myrect.left + 1;
		myrect.top = myrect.top + 1;
		canvas.fillRect(myrect);
// draw comment
		if (AbstractElement.isE_SHOWCOMMENTS() == true
				&& !this.comment.getText().trim().equals("")) {
			canvas.setBackground(E_COMMENTCOLOR);
			canvas.setColor(E_COMMENTCOLOR);
			final Rect someRect = _top_left.copy();
			someRect.left += 2;
			someRect.top += 2;
			someRect.right = someRect.left + 4;
			someRect.bottom -= 1;
			canvas.fillRect(someRect);
		}
// draw code
//		canvas.setColor(Color.BLACK);
//		writeOutVariables(canvas, _top_left.left + (E_PADDING / 2),
//				_top_left.top + (E_PADDING / 2) + fm.getHeight(), "try");

     for(int i = 0; i < this.code.count(); i++) {
         final String text1 = this.code.get(i);
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, _top_left.left + AbstractElement.E_PADDING / 2,
           _top_left.top + AbstractElement.E_PADDING / 2 + (i + 1) * fm.getHeight(), text1);
      }


// draw children
		myrect = _top_left.copy();
		myrect.left += ( AbstractElement.E_PADDING - 1);
//		myrect.top = _top_left.top + fm.getHeight() + E_PADDING - 1;
        myrect.top  += this.t.bottom ;
        myrect.bottom = myrect.bottom - this.rc.bottom - this.rf.bottom ;
		this.trySubqueue.draw(_canvas, myrect);
	}

}
