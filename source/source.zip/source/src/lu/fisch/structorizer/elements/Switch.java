//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\Switch.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
   package lu.fisch.structorizer.elements;
   import java.util.Vector;
   import java.awt.Color;
   import java.awt.FontMetrics;
   import lu.fisch.graphics.*;
   import lu.fisch.utils.*;

   /**
    * Switch block, for <code>Switch-case</code> statement. <BR>
    * The switch statement transfers control to one of several statements depending on
    * the value of an expression
    *<table border="1"> <tr>
    *  <td><img src="../../../../resources/JS-Alternative.png" width="200" height="179" alt="" border="0"></td>
    *  <td ><img src="../../../../resources/DNS-case.png" width="200" height="51" alt="" border="0"></td>
    *  <td>  <i>IfThenStatement: <BR>
    *    &nbsp;&nbsp;&nbsp;&nbsp;    </i><code>if (</code><i> Expression </i><code>)</code><i> Statement <BR><br>
    *    IfThenElseStatement: <BR>
    *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> Statement <BR><br>
    *   IfThenElseStatementNoShortIf: <BR>
    *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> StatementNoShortIf  <BR>
    *</i></td> </tr>
    *<table >
    *<dt><span class="strong">Look and feel:</span></dt>
    *<dd>The labels  "YES", "NOT" and the default code value ("&lt;condition>") can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.<br/>
    *<dd>The optional pre-keyword and post-keyword (default "if" and "?") can be changed in menu  options/parser <img src="../../../../resources/004_Make.png" border="1" width="16" height="16" alt="">.
    *<dd>In menu the Alternative icon is <img src="../../../../resources/060_conv_if.png" border="1" width="16" height="16" alt=""><BR><BR>
    *
    *<dt><span class="strong">Syntax:</span></dt>
    *<dd>The code in an Alternative block must be:<pre>
    *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;pre-keyword>] &lt;condition>|(&lt;condition>) [&lt;post-keyword>]</pre>
    *<dd>Comments are not allowed in Alternative code.    </dd><BR><BR>
    *
    *<dt><span class="strong">Analyze:</span></dt><i><ul><li>WARNING: empty True-block.
    *<li>WARNING: assignment in condition (maybe '=' instead of '==' ?)
    *</ul></i>
    *
    * <BR>Source build by JStruct.<BR>
    *
    * @version 1.01.01  build 24  (2012.03.14-19:07:55) JStruct-aware version
    * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
    * @author Marco Sillano <marco.sillano@gmail.com>
    */
   public class Switch
   extends AbstractElement {

      /* class global variables */
      private Vector<Subqueue> switchSubqueues = new Vector<Subqueue>();
      private int fullWidth = 0;
      private int maxHeight = 0;


      /**
       * The default constructor
       */
       public Switch() {
         super();
       }


      /**
       * The constructor from String
       * @param _strings String used as code
       */
       public Switch(String _strings) {
         super(_strings);
         setCode(_strings);
       }


      /**
       * The constructor for StringList code
       * @param _strings StringList used as code
       */
       public Switch(StringList _strings) {
         super(_strings);
         setCode(_strings);
       }

       @Override()
       public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
         Vector<DetectedError> errCase = _errors;
         for(final Subqueue acase : this.switchSubqueues) {
            errCase = acase.analyze(errCase);
         }
         return errCase;
       }

       @Override()
       public AbstractElement copy() {
         final AbstractElement ele = new Switch(getCode().getText());
         ele.setComment(getComment().copy());
         ele.setColor(getColor());
         ((Switch) ele).switchSubqueues.clear();
         for(int i = 0; i < this.switchSubqueues.size(); i++) {
            final Subqueue ss = this.switchSubqueues.get(i).copy();
            ss.setParent(ele);
            ((Switch) ele).switchSubqueues.add(ss);
         }
         return ele;
       }

       @Override()
       public void draw(Canvas _canvas, Rect _top_left) {
         Rect myrect = new Rect();
         Color drawColor = getColor();
         final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
         if(this.selected == true) {
            if(this.waited == true) {
               drawColor = AbstractElement.E_WAITCOLOR;
            }
            else {
               drawColor = AbstractElement.E_DRAWCOLOR;
            }
         }
         final Canvas canvas = _canvas;
         canvas.setBackground(drawColor);
         canvas.setColor(drawColor);
         this.rect = _top_left.copy();
// fill shape
         canvas.setColor(drawColor);
         myrect = _top_left.copy();
         myrect.left += 1;
         myrect.top += 1;
         myrect.bottom -= 1;
         myrect.bottom = _top_left.top + 2 * fm.getHeight() + 2 * E_PADDING;
// myrect.right-=1;
         canvas.fillRect(myrect);
// draw shape
         myrect = _top_left.copy();
         myrect.bottom = _top_left.top + 2 * fm.getHeight() + 2 * E_PADDING;
         final int y = myrect.top + E_PADDING;
         final int a = myrect.left + ((myrect.right - myrect.left) / 2);
         final int b = myrect.top;
         final int c = myrect.left + this.fullWidth - 1;
         final int d = myrect.bottom - 1;
         final int x = (((y - b) * (c - a) + a * (d - b)) / (d - b));
// draw comment
         if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
            canvas.setBackground(E_COMMENTCOLOR);
            canvas.setColor(E_COMMENTCOLOR);
            final Rect someRect = myrect.copy();
            someRect.left += 2;
            someRect.top += 2;
            someRect.right = someRect.left + 4;
            someRect.bottom -= 2;
            canvas.fillRect(someRect);
         }
// draw lines
         canvas.setColor(Color.BLACK);
         int lineWidth = 0;
// if the last line is '%', do not draw an else part
         int count = this.code.count() - 2;
         Rect rtt = null;
         for(int i = 0; i < count; i++) {
            rtt = this.switchSubqueues.get(i).prepareDraw(_canvas);
            lineWidth = lineWidth + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2));
         }
         if(this.code.get(this.code.count() - 1).equals("%")) {
            lineWidth = _top_left.right;
         }
         final int ax = myrect.left;
         final int ay = myrect.top;
         int bx = myrect.left + lineWidth;
         final int by = myrect.bottom - 1 - fm.getHeight() - (E_PADDING / 2);
         if(this.code.get(this.code.count() - 1).equals("%")) {
            bx = myrect.right;
         }
         canvas.moveTo(ax, ay);
         canvas.lineTo(bx, by);
         if(!this.code.get(this.code.count() - 1).equals("%")) {
            canvas.lineTo(bx, myrect.bottom - 1);
            canvas.lineTo(bx, by);
            canvas.lineTo(myrect.right, myrect.top);
         }
         final String varcase = this.code.get(0);
         canvas.setColor(Color.BLACK);
         if(this.code.get(this.code.count() - 1).equals("%")) {
            writeOutVariables(canvas, x - (_canvas.stringWidth(varcase) / this.code.count()), myrect.top + (E_PADDING / 3) + fm.getHeight(), varcase);
         }
         else {
            writeOutVariables(canvas, x - (_canvas.stringWidth(varcase)), myrect.top + (E_PADDING / 3) + fm.getHeight(), varcase);
         }
// draw children
         myrect = _top_left.copy();
         myrect.top = _top_left.top + fm.getHeight() * 2 + 2 * E_PADDING - 1;
         if(this.switchSubqueues.size() != 0) {
// if the last line is '%', do not draw an else part
            count = this.switchSubqueues.size() - 1;
            if(this.code.get(this.code.count() - 1).equals("%")) {
               count -= 1;
            }
            for(int i = 0; i <= count; i++) {
               rtt = this.switchSubqueues.get(i).prepareDraw(_canvas);
               if(i == count) {
                  myrect.right = _top_left.right;
               }
               else {
                  myrect.right = myrect.left + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2)) + 1;
               }
// draw child
               this.switchSubqueues.get(i).draw(_canvas, myrect);
// draw code
               writeOutVariables(canvas, myrect.right + ((myrect.left - myrect.right) / 2) - (_canvas.stringWidth(this.code.get(i + 1)) / 2), myrect.top - (E_PADDING / 4), this.code.get(i + 1));
// draw bottom up line
               if(i != this.switchSubqueues.size() - 2 && i != count) {
                  canvas.moveTo(myrect.right - 1, myrect.top);
                  final int mx = myrect.right - 1;
                  final int sx = mx;
                  final int sy = ((sx * (by - ay) - ax * by + ay * bx) / (bx - ax));
                  canvas.lineTo(sx, sy + 1);
               }
               myrect.left = myrect.right - 1;
            }
         }
         canvas.setColor(Color.BLACK);
         canvas.drawRect(_top_left);
       }

       @Override()
       public Java3Code getFullText() {
         final Java3Code text1 = new Java3Code("").spaceTokenize(false);
         for(final Subqueue acase : this.switchSubqueues) {
            text1.add(acase.getFullText());
         }
         return text1;
       }

       @Override()
       public String getName() {
         return "Switch-case Selection";
       }


      /**
       * @return the switchSubqueues
       */
       public Vector < Subqueue > getSwitchSubqueues() {
         return this.switchSubqueues;
       }

       @Override()
       public boolean isEmpty() {
         return this.switchSubqueues.isEmpty();
       }

       @Override()
       public StringList parseVarNames() {
         final StringList vars = new StringList();
         for(final Subqueue acase : this.switchSubqueues) {
            vars.addIfNew(acase.parseVarNames());
         }
         return vars;
       }

       @Override()
       public Rect prepareDraw(Canvas _canvas) {
         this.rect.top = 0;
         this.rect.left = 0;
         final FontMetrics fm = _canvas.getFontMetrics(font);
         this.rect.right = E_PADDING;
         for(int i = 0; i < this.code.count(); i++) {
            if(this.rect.right < _canvas.stringWidth(this.code.get(i)) + E_PADDING) {
               this.rect.right = _canvas.stringWidth(this.code.get(i)) + E_PADDING;
            }
         }
         this.rect.bottom = 2 * E_PADDING + 2 * fm.getHeight();
         int count = 0;
         Rect rtt = null;
         this.fullWidth = 0;
         this.maxHeight = 0;
         if(this.switchSubqueues.size() != 0) {
            count = this.code.count() - 1;
            if(this.code.get(count).equals("%")) {
               count -= 1;
            }
            for(int i = 0; i < count; i++) {
               rtt = this.switchSubqueues.get(i).prepareDraw(_canvas);
               this.fullWidth = this.fullWidth + Math.max(rtt.right, _canvas.stringWidth(this.code.get(i + 1)) + (E_PADDING / 2));
               if(this.maxHeight < rtt.bottom) {
                  this.maxHeight = rtt.bottom;
               }
            }
         }
         this.rect.right = Math.max(this.rect.right, this.fullWidth);
         this.rect.bottom = this.rect.bottom + this.maxHeight;
         return this.rect;
       }

       @Override()
       public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
         AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
         AbstractElement selCh = null;
         for(int i = 0; i < this.switchSubqueues.size(); i++) {
            final AbstractElement pre = this.switchSubqueues.get(i).selectElementByCoord(_x, _y, update);
            if(pre != null) {
               selCh = pre;
            }
         }
         if(selCh != null) {
            if(update) {
               this.selected = false;
            }
            selMe = selCh;
         }
         return selMe;
       }

       @Override()
       public void setCode(String _text) {
         Subqueue s = null;
         this.code.setText(_text);
         if(this.switchSubqueues == null) {
            this.switchSubqueues = new Vector < Subqueue > ();
         }
         if(this.code.count() > 1) {
            while(this.code.count() - 1 > this.switchSubqueues.size()) {
               s = new Subqueue();
               s.setParent(this);
               this.switchSubqueues.add(s);
            }
            while(this.code.count() - 1 < this.switchSubqueues.size()) {
               this.switchSubqueues.removeElementAt(this.switchSubqueues.size() - 1);
            }
         }
       }

       @Override()
       public void setCode(StringList _textList) {
         Subqueue s = null;
         this.code = _textList;
         if(this.switchSubqueues == null) {
            this.switchSubqueues = new Vector < Subqueue > ();
         }
         if(this.code.count() > 1) {
            while(this.code.count() - 1 > this.switchSubqueues.size()) {
               s = new Subqueue();
               s.setParent(this);
               this.switchSubqueues.add(s);
            }
            while(this.code.count() - 1 < this.switchSubqueues.size()) {
               this.switchSubqueues.removeElementAt(this.switchSubqueues.size() - 1);
            }
         }
       }

       @Override()
       public void setSelected(boolean _sel) {
         this.selected = _sel;
       }

       @Override()
       public String toString(String indent) {
         String res = super.toString(indent);
         for(final Subqueue acase : this.switchSubqueues) {
            res += indent + "case:\n" + acase.toString(indent + "   ");
         }
         return res;
       }

       @Override()
       public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
         int x = super.wordReplace(old, by, doTxt, doComm);
         for(int i = 0; i < this.switchSubqueues.size(); i++) {
            x += this.switchSubqueues.get(i).wordReplace(old, by, doTxt, doComm);
         }
         return x;
       }

   }
