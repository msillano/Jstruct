//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\AbstractElement.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.Font;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.structorizer.io.Ini;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Base class for all Elements used to build the NSD java tree.
 * <br />Any Element uses two main <CODE>StringList</CODE>:<ul>
 * <li> the <CODE>code</CODE> list that contains code or code fragments<br>
 * <li> the <CODE>comment</CODE> list that contains comments (javadoc and not javadoc).</ul>
 * The AbstractElement defines some static stuff and the common implementation for few methods.
 * AbstractElement responsibilities: <ul>
 * <li> VisitMethod, to get code (unformatted, String constant stripped: see {@link #getFullText()})
 * <li> VisitMethod, to get all Variable names(see {@link #parseVarNames()})
 * <li> VisitMethod, to get errors (see {@link #analyze(Vector)})
 * <li> VisitMethod, for block selection using mouse (see {@link #selectElementByCoord(int, int, boolean)})
 * <li> VisitMethod, to draw the NSD tree (see {@link #prepareDraw(Canvas)}, {@link #draw(Canvas, Rect)})
 * <li> INI file read/update for some options (see {@link #loadFromINI()}, {@link #saveToINI()} )
 * </ul>
 * <br />Source build by JStruct [charset UTF-8].<br />
 *
 * @version 1.02.01  build 22  (2015.03.27-17:22:30) Updated to java 1.8
 * @version <br>1.01.01  build 83  (2012.03.12-20:59:31) JStruct-aware version
 * @version <br>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public abstract class AbstractElement {

   /* class global variables */
   // main version number
   public static final String E_VERSION = "1.02.01";
   // constants for blocks
   static final String E_CHANGELOG = "";
   static final int E_PADDING = 20;
   static final int E_INDENT = 2;
   static Color E_NULLCOLOR = Color.LIGHT_GRAY;
   static Color E_DRAWCOLOR = Color.YELLOW;
   static Color E_WAITCOLOR = new Color(255, 255, 210);
   static Color E_COMMENTCOLOR = Color.LIGHT_GRAY;
   static Color E_TRYCOLOR = Color.LIGHT_GRAY;
   // blocks color n.0
   public static volatile Color color0 = Color.decode("0xFFFFFF");
   // blocks color n.1
   public static volatile Color color1 = Color.decode("0xFF8080");
   // blocks color n.2
   public static volatile Color color2 = Color.decode("0xFFFF80");
   // blocks color n.3
   public static volatile Color color3 = Color.decode("0x80FF80");
   // blocks color n.4
   public static volatile Color color4 = Color.decode("0x80FFFF");
   // blocks color n.5
   public static volatile Color color5 = Color.decode("0x0080FF");
   // blocks color n.6
   public static volatile Color color6 = Color.decode("0xFF80C0");
   // blocks color n.7
   public static volatile Color color7 = Color.decode("0xC0C0C0");
   // blocks color n.8
   public static volatile Color color8 = Color.decode("0xFF8000");
   // blocks color n.9
   public static volatile Color color9 = Color.decode("0x8080FF");
   // blocks defaults  (user defined in INI file)
   public static String preAlt = "<cond>";
   // blocks defaults  (user defined in INI file)
   public static String preAltT = "YES";
   // blocks defaults  (user defined in INI file)
   public static String preAltF = "NOT";
   // blocks defaults  (user defined in INI file)
   public static String preCase = "<var>\n<val_1>\n<val_2>\ndefalt";
   // blocks defaults  (user defined in INI file)
   public static String preFor = "for (int i=0; i<?; i++)";
   // blocks defaults  (user defined in INI file)
   public static String preWhile = "while (<cond>)";
   // blocks defaults  (user defined in INI file)
   public static String preRepeat = "while (<cond>)";
   // blocks defaults  (user defined in INI file)
   public static String preTry = "try";
   // font defaults  (user defined in INI file)
   static Font font = new Font("Courier new", Font.PLAIN, 12);
   // default formatting options(in INI file)
   // export Java option: if true adds javadoc comment to public methods
   public static boolean ADDJAVADOCPUBLIC = true;
   // export Java option: if true adds extra comments to top class
   public static boolean ADDJAVADOCEXTRA = true;
   // export Java option: if true adds link to NSD image  to top class
   public static boolean ADDJAVADOCIMAGE = true;
   // export Java option: if true add/updates version in top class
   public static boolean SETSOURCEVERSION = true;
   // export Java option: if true adds '//' comments before the code
   public static boolean PROGRAMDOCONTOP = true;
   // global status Fields
   private static boolean E_VARHIGHLIGHT = false;
   private static boolean E_SHOWCOMMENTS = false;
   private static boolean E_ANALYSER = false;
   // block fields
   protected boolean selected = false;
   protected boolean waited = false;
   protected Color color = Color.WHITE;
   protected Rect rect = new Rect();
   // the block code
   protected StringList code = new StringList();
   // the block comment
   protected StringList comment = new StringList();
   // the block parent
   protected AbstractElement parent = null;

/**
 * The method prepareDraw recursively calculates the element size.
 * @param _canvas Canvas
 * @return Rect including this (and all children).
 */
   public abstract Rect prepareDraw(Canvas _canvas);

/**
 * This method draws an element (and children) on canvas.
 * @param _canvas Canvas
 * @param _top_left Rect, start point
 */
   public abstract void draw(Canvas _canvas, Rect _top_left);

/**
 * The deep copy method (recursive)
 * @return AbstractElement
 */
   public abstract AbstractElement copy();

/**
 * Default constructor
 */
   public AbstractElement() {
      super();
   }

/**
 * The constructor for String code
 * @param _strings String used as code
 */
   public AbstractElement(String _strings) {
      super();
      setCode(_strings);
   }

/**
 * The constructor for StringList code
 * @param _strings StringList used as code
 */
   public AbstractElement(StringList _strings) {
      super();
      setCode(_strings);
   }

/**
 * The setter for E_ANALYSER
 * @param e_ANALYSER boolean, true to set ON the code analyze function
 */
   public static void setE_ANALYSER(boolean e_ANALYSER) {
      E_ANALYSER = e_ANALYSER;
   }

/**
 * The getter for E_ANALYSER
 * @return true if the analyze function is ON
 */
   public static boolean isE_ANALYSER() {
      return E_ANALYSER;
   }

/**
 * The setter for E_NULLCOLOR
 * @param e_NULLCOLOR Color
 */
   public static void setE_NULLCOLOR(Color e_NULLCOLOR) {
      E_NULLCOLOR = e_NULLCOLOR;
   }

/**
 * The setter for E_DRAWCOLOR
 * @param e_DRAWCOLOR Color
 */
   public static void setE_DRAWCOLOR(Color e_DRAWCOLOR) {
      E_DRAWCOLOR = e_DRAWCOLOR;
   }

/**
 * The getter for E_DRAWCOLOR
 * @param e_DRAWCOLOR Color
 * @return Color
 */
   public static Color getE_DRAWCOLOR() {
      return E_DRAWCOLOR;
   }

/**
 * The setter for E_VARHIGHLIGHT
 * @param e_VARHIGHLIGHT boolean, true to set ON the syntax highlight option
 */
   public static void setE_VARHIGHLIGHT(boolean e_VARHIGHLIGHT) {
      E_VARHIGHLIGHT = e_VARHIGHLIGHT;
   }

/**
 * The getter method isE_VARHIGHLIGHT
 * @return boolean true if the syntax highlight option is ON
 */
   public static boolean isE_VARHIGHLIGHT() {
      return E_VARHIGHLIGHT;
   }

/**
 * The setter for E_SHOWCOMMENTS
 * @param e_SHOWCOMMENTS boolean, true for comments pop-up ON
 */
   public static void setE_SHOWCOMMENTS(boolean e_SHOWCOMMENTS) {
      E_SHOWCOMMENTS = e_SHOWCOMMENTS;
   }

/**
 * The getter method isE_SHOWCOMMENTS
 * @return boolean true if the  comments pop-up option is ON
 */
   public static boolean isE_SHOWCOMMENTS() {
      return E_SHOWCOMMENTS;
   }

/**
 * The method setText replaces the code StringList content.
 * Splits lines using '\n'
 * @param _text String
 */
   public void setCode(String _text) {
      this.code.setText(_text);
   }

/**
 * The setter for the code StringList.
 * @param _text StringList
 */
   public void setCode(StringList _text) {
      this.code = _text;
   }

/**
 * The getter for  the code StringList.
 * @return StringList
 */
   public StringList getCode() {
      return this.code;
   }

/**
 * The method setComment replaces the comment StringList content.
 * Splits lines using '\n'
 * @param _comment String
 */
   public void setComment(String _comment) {
      this.comment.setText(_comment);
   }

/**
 * The setter for the comment StringList.
 * @param _comment StringList
 */
   public void setComment(StringList _comment) {
      this.comment = _comment;
   }

/**
 * The getter for  the comment StringList.
 * @return StringList
 */
   public StringList getComment() {
      return this.comment;
   }

/**
 * Test: the block as any comment?
 * @return boolean true if this block has comment.
 */
   public boolean isCommented() {
      return this.comment.count() > 0 && !this.comment.getLongString().trim().equals("");
   }

/**
 *The block is user selected?
 * @return boolean true if this block is user selected.
 */
   public boolean isSelected() {
      return this.selected;
   }

/**
 * The setter for <CODE>selected</CODE> flag.
 * @param _sel boolean
 */
   public void setSelected(boolean _sel) {
      this.selected = _sel;
   }

/**
 * The getter for <CODE>color</CODE>, as Color
 * @return Color
 */
   public Color getColor() {
      return this.color;
   }

/**
 * The getter for <CODE>color</CODE>, as HEX string.
 * @return String
 */
   public String getHexColor() {
      return getHexColor(this.color);
   }

/**
 * The setter for <CODE>color</CODE>, as Color
 * @param _color Color
 */
   public void setColor(Color _color) {
      this.color = _color;
   }

/**
 * The method getName returns an English user friendly name for this block.
 * @return String
 */
   public String getName() {
// default: the class name
      return this.getClass().getSimpleName();
   }

/**
 * The method wordReplace replaces <CODE>old</CODE> word by <CODE>by</CODE> word in this block.
 * @param old String
 * @param by String
 * @param doTxt boolean if true replaces in code
 * @param doComm boolean if true replaces in comment
 * @return int number of replacements
 */
   public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
      int x = 0;
      if(doTxt) {
         x += this.code.codeReplace(old, by);
      }
      if(doComm) {
         x += this.comment.codeReplace(old, by);
      }
      return x;
   }

/**
 * The method getRoot gets the root (<CODE>JClass</CODE> or <CODE>JMethod</CODE>) of this block. Recursive.
 * @return RootElement
 */
   public RootElement getRoot() {
// default: calls patent getRoot()
      return this.parent.getRoot();
   }

/**
 * The setter for <CODE>parent</CODE>
 * @param parent
 */
   public void setParent(AbstractElement parent) {
      this.parent = parent;
   }

/**
 * The getter for <CODE>parent</CODE>
 * @return the parent
 */
   public AbstractElement getParent() {
      return this.parent;
   }

/**
 * The getter for the ancestor block, skips all <CODE>Subqueue</CODE>
 * @return AbstractElement
 */
   public AbstractElement getParentElement() {
      AbstractElement ex = getMySubqueue();
      if(ex != null) {
         while(ex instanceof Subqueue) {
            ex = ex.parent;
         }
      }
      return ex;
   }

/**
 * The getter for the top root block.
 * @see lu.fisch.structorizer.elements.CompilationUnit#CompilationUnit() CompilationUnit
 * @return CompilationUnit
 */
   public CompilationUnit getCompilationUnit() {
      return this.parent.getCompilationUnit();
   }

/**
 * The method getSubqueue gets the first <CODE>Subqueue</CODE> where this block is included.
 * @return Subqueue
 */
   public Subqueue getMySubqueue() {
      AbstractElement ex = this;
      try {
         while(!(ex instanceof Subqueue)) {
            ex = ex.parent;
         }
      }
      catch (final NullPointerException e) {
         return null;
      }
      return(Subqueue) ex;
   }

/**
 *Visit method selectElementByCoord tests if mouse coordinates are inside this.
 * selectElementByCoord(-1, -1, true) unselects all Elements.
 * @param _x int mouse x coord.
 * @param _y int mouse y coord.
 * @param update boolean, if true sets <CODE>select</CODE> to false if mouse not inside.
 * @return AbstractElement
 */
   public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      final boolean inside = this.rect.left < _x && _x < this.rect.right && this.rect.top < _y && _y < this.rect.bottom;
      if(inside) {
         return this;
      }
      if(update) {
         this.selected = false;
      }
      return null;
   }

/**
 * The method produces a simple textual tree.
 * @param indent String
 * @return String
 */
   public String toString(String indent) {
      return indent + this.getClass().getSimpleName() + "\n";
   }

/**
 * Test for children elements of this.
 * <br> Only for Elements with SubQueue
 * @return boolean
 */
   public boolean isEmpty() {
// default, no SubQueue, so false.
      return true;
   }

/**
 * The method getRect clones the <CODE>rect</CODE> field.
 * The <CODE>rect</CODE> includes this block and all children
 * @see lu.fisch.graphics.Rect#Rect() Rect
 * @return Rect
 */
   public Rect getRect() {
      return new Rect(this.rect.left, this.rect.top, this.rect.right, this.rect.bottom);
   }

/**
 * The getter for actual font.
 * @return Font
 */
   public static Font getFont() {
      return font;
   }

/**
 * The setter for actual font.
 * @param _font Font
 */
   public static void setFont(Font _font) {
      font = _font;
   }

/**
 * The method isGlobal returns true if the name (variable or method) is global
 * @param name
 * @return boolean
 */
   boolean isGlobal(String name) {
      for(int i = 0; i < getRoot().getGlobalNames().count(); i++) {
         if(getRoot().getGlobalNames().get(i).equals(name)) {
            return true;
         }
         if(getRoot().getGlobalNames().get(i).startsWith(name + "_")) {
            return true;
         }
      }
      return false;
   }

/**
 * The method writeOutVariables writes one line in normal or in syntax highlight mode.
 * <br /> Defines the highlight mode colors and styles.
 * @param _canvas Canvas
 * @param _x int start position
 * @param _y String start position
 * @param _text
 * @see  lu.fisch.graphics.Canvas#writeOut(int, int, String)
 */
   public void writeOutVariables(Canvas _canvas, int _x, int _y, String _text) {
      if(!isE_VARHIGHLIGHT()) {
         _canvas.writeOut(_x, _y, _text);
         return;
      }
      int x = _x;
// defines bold font
      final Font boldFont = new Font(AbstractElement.font.getName(), Font.BOLD, AbstractElement.font.getSize());
      final Font italicFont = new Font(AbstractElement.font.getName(), Font.ITALIC, AbstractElement.font.getSize());
// backup the original font
      final Font backupFont = _canvas.getFont();
// Atomizes   input string
      Java3Code line = new Java3Code(_text).colorMap(getRoot().variables, getRoot().getGlobalNames());
      char oldVal = line.getMap().charAt(0);
      int start = 0;
      for(int i = 0; i <= line.getCode().length(); i++) {
         if(i == line.getCode().length() || line.getMap().charAt(i) != oldVal) {
            switch (oldVal) {
               case Java3Code.MFCHAR:
                  _canvas.setColor(Color.BLACK);
// set style for String constants
                  _canvas.setFont(italicFont);
                  break;
               case Java3Code.MFSTRING:
                  _canvas.setColor(Color.BLACK);
// set style for String constants
                  _canvas.setFont(italicFont);
                  break;
               case Java3Code.MFCOMM:
// set color for comments
                  _canvas.setColor(Color.GRAY);
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.MFCBLOCK:
// set color for comments
                  _canvas.setColor(Color.GRAY);
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.MFCODE:
// reset color
                  _canvas.setColor(Color.BLACK);
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.EVJAVA:
// set color for java keywords
                  _canvas.setColor(Color.decode("0x007700"));
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.EVOP:
// set color for operations
                  _canvas.setColor(Color.RED);
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.EVVAR:
// set color for variables
                  _canvas.setColor(Color.BLUE);
                  _canvas.setFont(backupFont);
                  break;
               case Java3Code.EVGLOBAL:
// set color for global
                  _canvas.setColor(Color.DARK_GRAY);
                  _canvas.setFont(boldFont);
                  break;
            }
            _canvas.writeOut(x, _y, line.getCode().substring(start, i));
            x += _canvas.stringWidth(line.getCode().substring(start, i));
            if(i < line.getCode().length()) {
               oldVal = line.getMap().charAt(i);
            }
            start = i;
         }
// reset color
         _canvas.setColor(Color.BLACK);
         _canvas.setFont(backupFont);
      }
   }

/**
 * Reads a comment line starting "@JStructOptions".
 *
 * This line can conatain the options:<ul>
 *      <li>ADDJAVADOCEXTRA: adds Javadoc comments to all classes/methods
 *      <li>ADDJAVADOCPUBLIC: adds  Javadoc comments only for public members
 *      <li>ADDJAVADOCIMAGE: adds NSD image reference to first Javadoc
 *      <li>SETSOURCEVERSION: processes version and auto build number
 *      <li>PROGRAMDOCONTOP: inline comments before the code line (default: on rigth) </ul>
 * @param comment
 */
   public static void updateOptions(StringList comment) {
      String options = "@JStructOptions";
      int pos = comment.getHeadPosition(options);
      if(pos >= 0) {
// decodes options
         options = comment.get(pos);
         ADDJAVADOCEXTRA = options.contains("ADDJAVADOCEXTRA");
         ADDJAVADOCIMAGE = options.contains("ADDJAVADOCIMAGE");
         ADDJAVADOCPUBLIC = options.contains("ADDJAVADOCPUBLIC");
         PROGRAMDOCONTOP = options.contains("PROGRAMDOCONTOP");
         SETSOURCEVERSION = options.contains("SETSOURCEVERSION");
      }
      else {
// 24/03/2015: if   @JStructOptions missed uses none
//// builds options by actual status
//options = "@JStructOptions: ";
//options += ADDJAVADOCEXTRA ? "ADDJAVADOCEXTRA, " : "";
//options += ADDJAVADOCIMAGE ? "ADDJAVADOCIMAGE, " : "";
//options += ADDJAVADOCPUBLIC ? "ADDJAVADOCPUBLIC, " : "";
//options += PROGRAMDOCONTOP ? "PROGRAMDOCONTOP, " : "";
//options += SETSOURCEVERSION ? "SETSOURCEVERSION, " : "";
//if (options.endsWith(", "))
//options = options.substring(0, options.length() - 2);
//comment.add(options);
         ADDJAVADOCEXTRA = false;
         ADDJAVADOCIMAGE = false;
         ADDJAVADOCPUBLIC = false;
         PROGRAMDOCONTOP = false;
         SETSOURCEVERSION = false;
      }
   }

/**
 * The method loadFromINI updates some fields from INI file.
 * @see lu.fisch.structorizer.io.Ini#getInstance() Ini
 */
   public static void loadFromINI() {
      final Ini ini = Ini.getInstance();
      ini.load();
// elements
      preAltT = ini.getProperty("IfTrue", "YES");
      preAltF = ini.getProperty("IfFalse", "NOT");
      preAlt = ini.getProperty("If", "<cond>");
      final StringList sl = new StringList();
      sl.setCommaText(ini.getProperty("Switch", "\"<var>\",\"<case_1>\",\"<case_2>\",\"default\""));
      preCase = sl.getText();
      preFor = ini.getProperty("For", "for (int i = 0; i < ?; i++");
      preWhile = ini.getProperty("While", "while (<cond>)");
      preRepeat = ini.getProperty("Repeat", "while (<cond>)");
// font
      setFont(new Font(ini.getProperty("Name", "Dialog"), Font.PLAIN, Integer.valueOf(ini.getProperty("Size", "12")).intValue()));
// colors
      color0 = Color.decode("0x" + ini.getProperty("color0", "FFFFFF"));
      color1 = Color.decode("0x" + ini.getProperty("color1", "FF8080"));
      color2 = Color.decode("0x" + ini.getProperty("color2", "FFFF80"));
      color3 = Color.decode("0x" + ini.getProperty("color3", "80FF80"));
      color4 = Color.decode("0x" + ini.getProperty("color4", "80FFFF"));
      color5 = Color.decode("0x" + ini.getProperty("color5", "0080FF"));
      color6 = Color.decode("0x" + ini.getProperty("color6", "FF80C0"));
      color7 = Color.decode("0x" + ini.getProperty("color7", "C0C0C0"));
      color8 = Color.decode("0x" + ini.getProperty("color8", "FF8000"));
      color9 = Color.decode("0x" + ini.getProperty("color9", "8080FF"));
// more (not used)
      ADDJAVADOCPUBLIC = ini.getProperty("ADDJAVADOCPUBLIC", "1").equals("1");
      ADDJAVADOCEXTRA = ini.getProperty("ADDJAVADOCEXTRA", "1").equals("1");
      ADDJAVADOCIMAGE = ini.getProperty("ADDJAVADOCIMAGE", "1").equals("1");
      SETSOURCEVERSION = ini.getProperty("SETSOURCEVERSION", "1").equals("1");
      PROGRAMDOCONTOP = ini.getProperty("PROGRAMDOCONTOP", "1").equals("1");
   }

/**
 * The method saveToINI  saves some fields to INI file.
 * @see lu.fisch.structorizer.io.Ini#getInstance() Ini
 */
   public static void saveToINI() {
      final Ini ini = Ini.getInstance();
// elements
      ini.setProperty("IfTrue", preAltT);
      ini.setProperty("IfFalse", preAltF);
      ini.setProperty("If", preAlt);
      final StringList sl = new StringList();
      sl.setText(preCase);
      ini.setProperty("Switch", sl.getCommaText());
      ini.setProperty("For", preFor);
      ini.setProperty("While", preWhile);
      ini.setProperty("Repeat", preRepeat);
// font
      ini.setProperty("Name", getFont().getFamily());
      ini.setProperty("Size", Integer.toString(getFont().getSize()));
// colors
      ini.setProperty("color0", getHexColor(color0));
      ini.setProperty("color1", getHexColor(color1));
      ini.setProperty("color2", getHexColor(color2));
      ini.setProperty("color3", getHexColor(color3));
      ini.setProperty("color4", getHexColor(color4));
      ini.setProperty("color5", getHexColor(color5));
      ini.setProperty("color6", getHexColor(color6));
      ini.setProperty("color7", getHexColor(color7));
      ini.setProperty("color8", getHexColor(color8));
      ini.setProperty("color9", getHexColor(color9));
// more
      ini.setProperty("ADDJAVADOCPUBLIC", ADDJAVADOCPUBLIC ? "1" : "0");
      ini.setProperty("ADDJAVADOCEXTRA", ADDJAVADOCEXTRA ? "1" : "0");
      ini.setProperty("ADDJAVADOCIMAGE", ADDJAVADOCIMAGE ? "1" : "0");
      ini.setProperty("SETSOURCEVERSION", SETSOURCEVERSION ? "1" : "0");
      ini.setProperty("PROGRAMDOCONTOP", PROGRAMDOCONTOP ? "1" : "0");
   }

/**
 * visits all Elements and checks the code to detect errors.
 * @param errors Vector<DetectedError> in error list
 * @return Vector<DetectedError> out error list
 */
   public Vector < DetectedError > analyze(Vector < DetectedError > errors) {
//default: nothing
      return errors;
   }

/**
 * visits all Elements and gets clean code (no comments)
 * @return Java3Code pure code
 */
   public Java3Code getFullText() {
      return(new Java3Code(this.code)).killComments();
   }

/**
 * gets from the nearest RootElement a list of global names.
 * @return StringList
 */
   StringList getGlobalNames() {
      return this.parent.getGlobalNames();
   }

/**
 * visits all Elements and gets a list of variable names.
 * @return StringList
 */
   public StringList parseVarNames() {
      return null;
   }

/**
 * The method getHexColor converts a Color to HEX string.
 * @param _color Color
 * @return String
 */
   public static String getHexColor(Color _color) {
      final String rgb = Integer.toHexString(_color.getRGB());
      return rgb.substring(2, rgb.length());
   }

}
