//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\For.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Block, for <code>for</code> statement.
 *
 * The basic <code>for</code> statement executes some initialization code,
 * then executes an Expression, a Statement, and some update
 * code repeatedly until the value of the Expression is false.<br>
 * The enhanced <code>for</code> statement has the form:<br>
 *   for ( &lt;FormalParameter> : &lt;Expression> ) &lt;Statement>
 *
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-for.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-for.png" width="200" alt="" border="0"></td>
 *
 *<td>  <i>BasicForStatement:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;</i><code>for (</code><i> [ForInit] </i><code>;</code><i> [Expression] </i><code>;</code><i> [ForUpdate] </i><code>)</code><i> Statement<br>
 *ForStatementNoShortIf:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;</i><code>for (</code><i> [ForInit] </i><code>;</code><i> [Expression] </i><code>;</code><i> [ForUpdate] </i><code>)</code><i> StatementNoShortIf<br>
 *ForInit:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp    StatementExpressionList<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   LocalVariableDeclaration<br>
 *ForUpdate:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   StatementExpressionList<br>
 *StatementExpressionList:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   StatementExpression<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   StatementExpressionList </i><code>,</code><i> StatementExpression<br><br>
 *EnhancedForStatement:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;   </i><code>for (</code><i> FormalParameter </i><code>:</code><i> Expression </i><code>)</code><i> Statement<br>
 *FormalParameter:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;    VariableModifiersopt Type VariableDeclaratorId<br>
 *VariableDeclaratorId:<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;    Identifier<br>
 *&nbsp;&nbsp;&nbsp;&nbsp;    VariableDeclaratorId </i><code>[]</code><i><br>
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd>The default code value ("<code>for (int i = 0; i < ???; i++)</code>") can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.<br/>
 *<dd>The optional pre-keyword and post-keyword (default "for" and "") can be changed in menu  options/parser <img src="../../../../resources/004_Make.png" border="1" width="16" height="16" alt="">.
 *<dd>In menu the For icon is <img src="../../../../resources/062_conv_while.png" border="1" width="16" height="16" alt=""><BR><BR>
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an <code>for</code> block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;pre-keyword>] [(]&lt;ForInit>;&lt;Expression>;&lt;ForUpdate>| &lt;FormalParameter>:&lt;Expression> [)] [&lt;post-keyword>]</pre>
 *Comments are not allowed in <code>for</code> code.    <BR><BR>
 *
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.01  build 8  (2015.04.09-15:11:07) Updated to java 1.8
 * @version <dd> 1.01.01  build 27  (2012.03.13-15:08:03) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class For
extends AbstractElement {

   /* class global variables */
   private Subqueue forSubqueue = new Subqueue();
   private Rect r = new Rect();

/**
 * The default constructor
 */
   public For() {
      super();
      this.forSubqueue.setParent(this);
   }

/**
 * The constructor from String code
 * @param _strings String
 */
   public For(String _strings) {
      super(_strings);
      this.forSubqueue.setParent(this);
      setCode(_strings);
   }

/**
 * The constructor for StringList code
 * @param _strings StringList
 */
   public For(StringList _strings) {
      super(_strings);
      this.forSubqueue.setParent(this);
      setCode(_strings);
   }

   @Override()
   public Vector <DetectedError> analyze(Vector <DetectedError> _errors) {
      return this.forSubqueue.analyze(_errors);
   }

   @Override()
   public AbstractElement copy() {
      final AbstractElement ele = new For(getCode().copy());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      ((For) ele).forSubqueue = this.forSubqueue.copy();
      ((For) ele).forSubqueue.setParent(ele);
      return ele;
   }

   @Override()
   public void draw(Canvas _canvas, Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      if(this.selected == true) {
         drawColor = E_DRAWCOLOR;
      }
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
      this.rect = _top_left.copy();
      myrect = _top_left.copy();
//   draw shape
      canvas.setColor(Color.BLACK);
      myrect.bottom = _top_left.top + fm.getHeight() * this.code.count() + E_PADDING;
      canvas.drawRect(myrect);
      myrect = _top_left.copy();
      myrect.right = myrect.left + E_PADDING;
      canvas.drawRect(myrect);
//   fill shape
      canvas.setColor(drawColor);
      myrect.left = myrect.left + 1;
      myrect.top = myrect.top + 1;
      canvas.fillRect(myrect);
      myrect = _top_left.copy();
      myrect.bottom = _top_left.top + fm.getHeight() * this.code.count() + E_PADDING;
      myrect.left = myrect.left + 1;
      myrect.top = myrect.top + 1;
      canvas.fillRect(myrect);
//   draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         final Rect someRect = _top_left.copy();
         someRect.left += 2;
         someRect.top += 2;
         someRect.right = someRect.left + 4;
         someRect.bottom -= 1;
         canvas.fillRect(someRect);
      }
      myrect = _top_left.copy();
//   draw code
      for(int i = 0; i < this.code.count(); i++) {
         final String text1 = this.code.get(i);
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, _top_left.left + E_PADDING / 2, _top_left.top + E_PADDING / 2 + (i + 1) * fm.getHeight(), text1);
      }
//   draw children
      myrect = _top_left.copy();
      myrect.left = myrect.left + AbstractElement.E_PADDING - 1;
      myrect.top = _top_left.top + fm.getHeight() * this.code.count() + E_PADDING - 1;
      this.forSubqueue.draw(_canvas, myrect);
   }

/**
 * getter for FOR Subqueue
 * @return the forSubqueue
 */
   public Subqueue getForSubqueue() {
      return this.forSubqueue;
   }

   @Override()
   public Java3Code getFullText() {
      final Java3Code text1 = super.getFullText();
      text1.add(this.forSubqueue.getFullText());
      return text1;
   }

   @Override()
   public String getName() {
      return "For Iteration";
   }

   @Override()
   public boolean isEmpty() {
      return this.forSubqueue.isEmpty();
   }

   @Override()
   public StringList parseVarNames() {
      final StringList vars = this.forSubqueue.parseVarNames();
      vars.addIfNew(getLoopVariable());
      return vars;
   }

   @Override()
   public Rect prepareDraw(Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      this.rect.right = E_PADDING;
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      for(int i = 0; i < this.code.count(); i++) {
         this.rect.right = Math.max(this.rect.right, _canvas.stringWidth(this.code.get(i)) + E_PADDING);
      }
      this.rect.bottom = E_PADDING + this.code.count() * fm.getHeight();
      this.r = this.forSubqueue.prepareDraw(_canvas);
      this.rect.right = Math.max(this.rect.right, this.r.right + E_PADDING);
      this.rect.bottom += this.r.bottom;
      return this.rect;
   }

   @Override()
   public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
      final AbstractElement sel = this.forSubqueue.selectElementByCoord(_x, _y, update);
      if(sel != null) {
         if(update) {
            this.selected = false;
         }
         selMe = sel;
      }
      return selMe;
   }

   @Override()
   public void setSelected(boolean _sel) {
      this.selected = _sel;
   }

   @Override()
   public String toString(String indent) {
      final String res = super.toString(indent);
      return res + this.forSubqueue.toString(indent + "   ");
   }

   @Override()
   public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
      int x = super.wordReplace(old, by, doTxt, doComm);
      x += this.forSubqueue.wordReplace(old, by, doTxt, doComm);
      return x;
   }

/**
 * parses the code to get the loop variable name
 */
   private String getLoopVariable() {
      Java3Code lines = new Java3Code(getCode()).killComments();
      final String[] parts = lines.getTokens();
      for(int k = 0; k < parts.length; k++) {
         if(parts[k].equals("=") && Character.isJavaIdentifierStart(parts[k - 1].charAt(0))) {
            return parts[k - 1];
         }
         if(parts[k].equals(":") && Character.isJavaIdentifierStart(parts[k - 1].charAt(0))) {
            return parts[k - 1];
         }
         if(parts[k].equals("++") && Character.isJavaIdentifierStart(parts[k - 1].charAt(0))) {
            return parts[k - 1];
         }
         if(parts[k].equals("--") && Character.isJavaIdentifierStart(parts[k - 1].charAt(0))) {
            return parts[k - 1];
         }
      }
      return "i";
   }

}
