//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\Alternative.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.ErrorMessages;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Alternative block, for <code>if-then-else</code> statement. <br />
 * The if statement allows conditional execution of a statement or a conditional
 *  choice of two statements, executing one or the other but not both.
 *<table width="800" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-Alternative.png" width="200"  alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-alternative.png" width="200" alt="" border="0"></td>
 *  <td>  <i>IfThenStatement: <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp;    </i><code>if (</code><i> Expression </i><code>)</code><i> Statement <br /><br>
 *    IfThenElseStatement: <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> Statement <br /><br>
 *   IfThenElseStatementNoShortIf: <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>if (</code><i> Expression </i><code>)</code><i> StatementNoShortIf </i><code>else</code><i> StatementNoShortIf  <br />
 *</i></td> </tr>
 *<table >
 *<dt><span class="strong">Look and feel:</span></dt>
 *<dd>The labels  "YES", "NOT" and the default code value ("&lt;condition>") can be changed in menu options/structures <img src="../../../../resources/040_notnice.png" border="1" width="16" height="16" alt="">.<br/>
 *<dd>The optional pre-keyword and post-keyword (default "if" and "?") can be changed in menu  options/parser <img src="../../../../resources/004_Make.png" border="1" width="16" height="16" alt="">.
 *<dd>In menu the Alternative icon is <img src="../../../../resources/060_conv_if.png" border="1" width="16" height="16" alt=""><br /><br />
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an Alternative block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;pre-keyword>] &lt;condition>|(&lt;condition>) [&lt;post-keyword>]</pre>
 *Comments are not allowed in Alternative code.    <br /><br />
 *
 *<dt><span class="strong">Analyze:</span></dt><i><ul><li>WARNING: empty True-block.
 *<li>WARNING: assignment in condition (maybe '=' instead of '==' ?)
 *</ul></i>
 *
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.00  build 13  (2015.04.09-11:45:54) update to java 1.8
 * @version <dd>1.01.01  build 21  (2012.03.09-23:04:43) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Alternative
extends AbstractElement {

   /* class global variables */
   private Subqueue falseSubqueue = new Subqueue();
   private Subqueue trueSubqueue = new Subqueue();
   private Rect rTrue = new Rect();
   private Rect rFalse = new Rect();

/**
 * The default constructor
 */
   public Alternative() {
      super();
      this.falseSubqueue.setParent(this);
      this.trueSubqueue.setParent(this);
   }

/**
 * The constructor from String
 * @param _strings String used as code
 */
   public Alternative(final String _strings) {
      super(_strings);
      this.falseSubqueue.setParent(this);
      this.trueSubqueue.setParent(this);
      setCode(_strings);
   }

/**
 * The constructor for StringList code
 * @param _strings StringList used as code
 */
   public Alternative(final StringList _strings) {
      super(_strings);
      this.falseSubqueue.setParent(this);
      this.trueSubqueue.setParent(this);
      setCode(_strings);
   }

/**
 * getter for TRUE Subqueue
 * @return the trueSubqueue
 */
   public Subqueue getTrueSubqueue() {
      return this.trueSubqueue;
   }

/**
 * getter for FALSE Subqueue
 * @return the falseSubqueue
 */
   public Subqueue getFalseSubqueue() {
      return this.falseSubqueue;
   }

   @Override()
   public String getName() {
      return "IF Selection";
   }

   @Override()
   public Rect prepareDraw(final Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      this.rect.right = E_PADDING;
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      this.rect.right = 2 * E_PADDING;
      for(int i = 0; i < this.code.count(); i++) {
         if(this.rect.right < _canvas.stringWidth(this.code.get(i)) + 4 * E_PADDING) {
            this.rect.right = _canvas.stringWidth(this.code.get(i)) + 4 * E_PADDING;
         }
      }
      this.rect.bottom = 2 * E_PADDING + this.code.count() * fm.getHeight();
//   size of subqueues
      this.rFalse = this.falseSubqueue.prepareDraw(_canvas);
      this.rTrue = this.trueSubqueue.prepareDraw(_canvas);
      this.rect.right = Math.max(this.rect.right, this.rTrue.right + this.rFalse.right);
      this.rect.bottom += Math.max(this.rTrue.bottom, this.rFalse.bottom);
      return this.rect;
   }

   @Override()
   public void draw(final Canvas _canvas, final Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      int a;
      int b;
      int c;
      int d;
      int x;
      int y;
      int wmax;
      if(this.selected) {
         if(this.waited) {
            drawColor = AbstractElement.E_WAITCOLOR;
         }
         else {
            drawColor = AbstractElement.E_DRAWCOLOR;
         }
      }
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
      myrect = _top_left.copy();
      myrect.bottom -= 1;
      canvas.fillRect(myrect);
      this.rect = _top_left.copy();
      myrect.bottom = _top_left.top + this.code.count() * fm.getHeight() + 2 * E_PADDING;
      y = myrect.top + E_PADDING;
      a = myrect.left + (myrect.right - myrect.left) / 2;
      b = myrect.top;
      c = myrect.left + this.rTrue.right - 1;
      d = myrect.bottom - 1;
      x = ((y - b) * (c - a) + a * (d - b)) / (d - b);
      wmax = 0;
      for(int i = 0; i < this.code.count(); i++) {
         if(wmax < _canvas.stringWidth(this.code.get(i))) {
            wmax = _canvas.stringWidth(this.code.get(i));
         }
      }
//   draw code
      for(int i = 0; i < this.code.count(); i++) {
         final String text1 = this.code.get(i);
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, x - _canvas.stringWidth(text1) / 2, _top_left.top + E_PADDING / 3 + (i + 1) * fm.getHeight(), text1);
      }
//   draw symbols
      canvas.writeOut(myrect.left + E_PADDING / 2, myrect.bottom - E_PADDING / 2, preAltT);
      canvas.writeOut(myrect.right - E_PADDING / 2 - _canvas.stringWidth(preAltF), myrect.bottom - E_PADDING / 2, preAltF);
//   draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         final Rect someRect = myrect.copy();
         someRect.left += 2;
         someRect.top += 2;
         someRect.right = someRect.left + 4;
         someRect.bottom -= 2;
         canvas.fillRect(someRect);
      }
//   draw triangle
      canvas.setColor(Color.BLACK);
      canvas.moveTo(myrect.left, myrect.top);
      canvas.lineTo(myrect.left + this.rTrue.right - 1, myrect.bottom - 1);
      canvas.lineTo(myrect.right, myrect.top);
//   draw children
      myrect = _top_left.copy();
      myrect.top = _top_left.top + fm.getHeight() * this.code.count() + 2 * E_PADDING - 1;
      myrect.right = myrect.left + this.rTrue.right - 1;
      this.trueSubqueue.draw(_canvas, myrect);
      myrect.left = myrect.right;
      myrect.right = _top_left.right;
      this.falseSubqueue.draw(_canvas, myrect);
      myrect = _top_left.copy();
      canvas.setColor(Color.BLACK);
      canvas.drawRect(myrect);
   }

   @Override()
   public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      AbstractElement selMe = super.selectElementByCoord(_x, _y, update);
      final AbstractElement selT = this.trueSubqueue.selectElementByCoord(_x, _y, update);
      final AbstractElement selF = this.falseSubqueue.selectElementByCoord(_x, _y, update);
      if(selT != null) {
         if(update) {
            this.selected = false;
         }
         selMe = selT;
      }
      if(selF != null) {
         if(update) {
            this.selected = false;
         }
         selMe = selF;
      }
      return selMe;
   }

   @Override()
   public void setSelected(boolean _sel) {
      this.selected = _sel;
   }

   @Override()
   public boolean isEmpty() {
      return this.trueSubqueue.isEmpty() && this.falseSubqueue.isEmpty();
   }

   @Override()
   public AbstractElement copy() {
      final AbstractElement ele = new Alternative(getCode().copy());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      ((Alternative) ele).trueSubqueue = this.trueSubqueue.copy();
      ((Alternative) ele).falseSubqueue = this.falseSubqueue.copy();
      ((Alternative) ele).trueSubqueue.setParent(ele);
      ((Alternative) ele).falseSubqueue.setParent(ele);
      return ele;
   }

   @Override()
   public Java3Code getFullText() {
      final Java3Code text1 = super.getFullText();
      text1.add(this.trueSubqueue.getFullText());
      if(this.falseSubqueue.getSize() > 0) {
         text1.add(this.falseSubqueue.getFullText());
      }
      return text1;
   }

   @Override()
   public StringList parseVarNames() {
      final StringList vars = this.trueSubqueue.parseVarNames();
      if(this.falseSubqueue.getSize() > 0) {
         vars.add(this.falseSubqueue.parseVarNames());
      }
      return vars;
   }

   @Override()
   public String toString(String indent) {
      String res = super.toString(indent);
      res += this.trueSubqueue.toString(indent + "   ");
      if(this.falseSubqueue.getSize() > 0) {
         res += indent + "else:\n";
         res += this.falseSubqueue.toString(indent + "   ");
      }
      return res;
   }

   @Override()
   public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
      int x = this.trueSubqueue.wordReplace(old, by, doTxt, doComm);
      x += this.falseSubqueue.wordReplace(old, by, doTxt, doComm);
      x += super.wordReplace(old, by, doTxt, doComm);
      return x;
   }

   @Override()
   public Vector < DetectedError > analyze(Vector < DetectedError > _errors) {
      Vector < DetectedError > errIf = this.trueSubqueue.analyze(_errors);
      errIf = this.falseSubqueue.analyze(errIf);
//   CHECK: if with empty T-block(#4)
      if(this.trueSubqueue.isEmpty()) {
         final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error04, ""), this);
         RootElement.addError(errIf, e, 4);
      }
//   CHECK: assignment in condition(#8)
      Java3Code condition = new Java3Code(this.code);
      if(condition.codeReduce(true).contains(" = ")) {
         final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error08, ""), this);
         RootElement.addError(errIf, e, 8);
      }
//   debug         for(String x:condition)     System.out.println(">>"+x);
      return errIf;
   }

}
