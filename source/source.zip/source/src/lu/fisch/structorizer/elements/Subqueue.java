//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: H:\winPenPack\Documents\javaStruct\source\src\lu\fisch\structorizer\elements\Subqueue.java
//@JStruct: 1.01 JavaParser: 1.0
//@parser: javac 1.6.0_24
//
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Subqueue is an ancillary Class, used to process a block of Elements like a single Element.
 * <BR><BR>
 * Source build by JStruct.<BR>
 *
 * @version 1.01.01  build 24  (2012.03.14-18:41:17) JStruct-aware version
 * @version <BR>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Subqueue extends AbstractElement {

	/* class global variables */
	private final Vector<AbstractElement> children = new Vector<AbstractElement>();

	/**
	 * The default constructor
	 */
	public Subqueue() {
		super("");
	}

	/**
	 * The constructor for StringList code
	 * @param _strings StringList used as code
	 */
	public Subqueue(StringList _strings) {
		super(_strings);
	}

	/**
	 * The method addElement
	 * @param _element AbstractElement
	 */
	public void addElement(AbstractElement _element) {
		this.children.add(_element);
		_element.setParent(this);
	}

	@Override()
	public Vector<DetectedError> analyze(Vector<DetectedError> _errors) {
		Vector<DetectedError> errSubq = super.analyze(_errors);
		for (final AbstractElement ele : this.children) {
			errSubq = ele.analyze(errSubq);
		}
		return errSubq;
	}

	@Override()
	public Subqueue copy() {
		final Subqueue queue = new Subqueue();
		queue.setColor(getColor());
		for (final AbstractElement ele : this.children) {
			queue.addElement(ele.copy());
		}
		return queue;
	}

	@Override()
	public void draw(Canvas _canvas, Rect _top_left) {
		Rect myrect;
		Rect subrect;
		Color drawColor = getColor();
		final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
		final Canvas canvas = _canvas;
		if (this.selected == true) {
			drawColor = AbstractElement.E_DRAWCOLOR;
		}
		this.rect = _top_left.copy();
		myrect = _top_left.copy();
		myrect.bottom = myrect.top;
		if (!isEmpty()) {
// draw children
			for (int i = 0; i < this.children.size(); i++) {
				subrect = this.children.get(i).prepareDraw(_canvas);
				myrect.bottom += subrect.bottom;
				if (i == this.children.size() - 1) {
					myrect.bottom = _top_left.bottom;
				}
				this.children.get(i).draw(_canvas, myrect);
//myrect.bottom-=1;
				myrect.top += subrect.bottom;
			}
		} else {
// draw nothing
			drawColor = AbstractElement.E_NULLCOLOR;
			if (this.selected == true) {
				if (this.waited == true) {
					drawColor = AbstractElement.E_WAITCOLOR;
				} else {
					drawColor = AbstractElement.E_DRAWCOLOR;
				}
			}
			canvas.setColor(drawColor);
			myrect = _top_left.copy();
			canvas.fillRect(myrect);
			canvas.setColor(Color.BLACK);
			canvas.writeOut(myrect.left + (myrect.right - myrect.left) / 2
					- _canvas.stringWidth("\u2205") / 2, myrect.top
					+ (myrect.bottom - myrect.top) / 2 + fm.getHeight() / 2,
					"\u2205");
			canvas.drawRect(myrect);
		}
	}

	/**
	 * @return the children
	 */
	public Vector<AbstractElement> getChildren() {
		return this.children;
	}

	/**
	 * The method getElement
	 * @param _index int
	 * @return AbstractElement
	 */
	public AbstractElement getElement(int _index) {
		return this.children.get(_index);
	}

	@Override()
	public Java3Code getFullText() {
		final Java3Code ctext = super.getFullText();
		for (final AbstractElement ele : this.children) {
			ctext.add(ele.getFullText());
		}
		return ctext;
	}

	/**
	 * The method getIndexOf
	 * @param _ele AbstractElement
	 * @return int
	 */
	public int getIndexOf(AbstractElement _ele) {
		return this.children.indexOf(_ele);
	}

	@Override()
	public String getName() {
		return "Sequence";
	}

	/**
	 * The method getSize
	 * @return int
	 */
	public int getSize() {
		return this.children.size();
	}

	/**
	 * The method insertElement
	 * @param _element AbstractElement
	 * @param _index int
	 */
	public void insertElement(AbstractElement _element, int _index) {
		this.children.insertElementAt(_element, _index);
	}

	@Override()
	public boolean isEmpty() {
		return this.children.isEmpty();
	}

	@Override()
	public StringList parseVarNames() {
		final StringList vars = new StringList();
		for (final AbstractElement ele : this.children) {
			final StringList y = ele.parseVarNames();
			if (y != null) {
				vars.addIfNew(y);
			}
		}
		return vars;
	}

	@Override()
	public Rect prepareDraw(Canvas _canvas) {
		Rect subrect = new Rect();
		this.rect.top = 0;
		this.rect.left = 0;
		this.rect.right = 0;
		this.rect.bottom = 0;
		if (!isEmpty()) {
			for (final AbstractElement ele : this.children) {
				subrect = ele.prepareDraw(_canvas);
				this.rect.right = Math.max(this.rect.right,	subrect.right);
				this.rect.bottom += subrect.bottom;
			}
		} else {
			this.rect.right = 2 * AbstractElement.E_PADDING;
			final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
			this.rect.bottom = fm.getHeight() + E_PADDING;
		}
		return this.rect;
	}

	/**
	 * The method removeElement
	 * @param _element AbstractElement
	 */
	public void removeElement(AbstractElement _element) {
		this.children.removeElement(_element);
	}

	/**
	 * The method removeElement
	 * @param _index int
	 */
	public void removeElement(int _index) {
		this.children.removeElement(this.children.get(_index));
	}

	@Override()
	public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
		final AbstractElement selMe = super
				.selectElementByCoord(_x, _y, update);
		AbstractElement res = null;
		for (final AbstractElement ele : this.children) {
			final AbstractElement selCh = ele.selectElementByCoord(_x, _y,
					update);
			if (selCh != null) {
				if (update) {
					this.selected = false;
				}
				res = selCh;
			}
		}
		if (res != null) {
			return res;
		}
		return selMe;
	}

	@Override()
	public String toString(String indent) {
		String tree = super.toString(indent);
		for (final AbstractElement ele : this.children) {
			tree += ele.toString(indent + "   ");
		}
		tree += indent + "   ----- ends\n";
		return tree;
	}

	@Override()
	public int wordReplace(String old, String by, boolean doTxt, boolean doComm) {
		int x = super.wordReplace(old, by, doTxt, doComm);
		for (final AbstractElement ele : this.children) {
			x += ele.wordReplace(old, by, doTxt, doComm);
		}
		return x;
	}

	@Override()
	StringList getGlobalNames() {
		return getParent().getGlobalNames();
	}

}
