//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012-2015 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\CompilationUnit.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.StringList;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * The root element for compilation units (source files) and package declarations.
 *
 * <br>This code section contains package and import declarations.<br>
 * This comment section contains the first comment block (not javadoc) usually license stuff.<br>
 * More CompilationUnit responsibilities: <ul>
 * <li> Entry point for Analyze (see {@link #analyze()})
 * <li> Entry point for code parsing (see {@link #parseGlobalNames(globalType)} and see {@link #parseVarNames()})
 * <li> Entry point for block selection (see {@link #selectElementByCoord(int, int, boolean)})
 * <li> Entry point for draw the NSD tree (see {@link #progDraw(Graphics)})
 * <li> File name management for read, write, import, export user commands.
 * </ul><br />
 * <dt><span class="strong">Look and feel:</span></dt>
 * <dd>The CompilationUnit is associated to window background: clicking it a pop-up allows editing.
 *</dd><br />
 *
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in an CompilationUnit block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[PackageDeclaration;] [ImportDeclarations;]*<</pre>
 *Comments are not allowed in code.
 *
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.00  build 16  (2015.04.09-14:58:30) update to java 1.8
 * @version <dd>  1.01.01  build 18  (2012.03.10-21:24:46) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class CompilationUnit
extends RootElement {

   /* class global variables */
   private String filename = "";

/**
 * The constructor CompilationUnit
 */
   public CompilationUnit() {
      super("");
      this.setCode(" // package and import");
   }

/**
 * The entry point for analyze traverse tree.
 * @return Vector<DetectedError>
 */
   public Vector <DetectedError> analyze() {
      this.setErrors(new Vector <DetectedError> ());
      for(int i = 0; i < getSize(); i++) {
         final RootElement root = getElement(i);
         this.setErrors(root.analyze(this.getErrors()));
      }
      return this.getErrors();
   }

   @Override()
   public boolean checkChild(AbstractElement _child, AbstractElement _parent) {
      return false;
   }

   @Override()
   public AbstractElement copy() {
      return null;
   }

   @Override()
   public void draw(Canvas _canvas, Rect _rect) {
      Rect subrect;
      final Rect newrect = _rect.copy();
      for(int i = 0; i < getSize(); i++) {
         final RootElement root = getElement(i);
         subrect = root.prepareDraw(_canvas);
         newrect.right = newrect.left + subrect.right;
         newrect.bottom = newrect.top + subrect.bottom;
         root.draw(_canvas, newrect);
         newrect.left += subrect.right + 1;
      }
   }

   @Override()
   public CompilationUnit getCompilationUnit() {
      return this;
   }

   @Override()
   public RootElement getElement(int _index) {
      return(RootElement) this.getChildQueue().getElement(_index);
   }

/**
 *  setter for filename. full path.
 * @param filename the filename to set
 */
   public void setFilename(String filename) {
      this.filename = filename;
   }

/**
 *  getter for filename, full path.
 * @return the filename
 */
   public String getFilename() {
      return this.filename;
   }

/**
 * The method getFile
 * @return File
 */
   public File getFile() {
      if(this.filename.equals("")) {
         return null;
      }
      return new File(this.filename);
   }

/**
 * The method getDefaultFileName returns always a file name.
 * @return String
 */
   public String getDefaultFileName() {
      String s;
      if(this.filename.equals("") || this.filename == null) {
         if(this.getJName() != null) {
            s = this.getJName();
         }
         else {
            if(!this.getChildQueue().isEmpty()) {
               s = getRootName();
            }
            else {
               return "newfile";
            }
         }
      }
      else {
         final File f = new File(this.filename);
         s = f.getName();
      }
      if(s.contains(".")) {
         s = s.substring(0, s.indexOf('.'));
      }
      if(s.indexOf('(') >= 0) {
         s = s.substring(0, s.indexOf('('));
      }
      return s;
   }

/**
 * The method getPath
 * @return String
 */
   public String getPath() {
      if(this.filename.equals("")) {
         if(this.getJName() != null) {
            try {
               return new URI(this.getJName()).getPath();
            }
            catch (final URISyntaxException e) {
//                  return new URL(this.getJName()).getPath();
//             catch (final MalformedURLException e) {
               return "";
            }
         }
         return "";
      }
      final File f = new File(this.filename);
      return f.getAbsolutePath();
   }

   @Override()
   public String getRootName() {
      for(int i = 0; i < getSize(); i++) {
         if(!getElement(i).getRootName().equals("")) {
            return getElement(i).getRootName();
         }
      }
      return "";
   }

   @Override()
   public StringList getGlobalNames() {
      return this.globalNames;
   }

   @Override()
   public String getName() {
      return "Program";
   }

   @Override()
   public StringList parseGlobalNames(globalType kind) {
      final StringList gVars = new StringList();
      for(int i = 0; i < this.getChildQueue().getSize(); i++) {
         gVars.addIfNew(getElement(i).parseGlobalNames(kind));
      }
      return gVars;
   }

   @Override()
   public Rect prepareDraw(Canvas _canvas) {
      Rect subrect = new Rect();
      this.rect.top = 0;
      this.rect.left = 0;
      this.rect.right = 0;
      this.rect.bottom = 0;
      for(int i = 0; i < getSize(); i++) {
         final AbstractElement root = getElement(i);
         subrect = root.prepareDraw(_canvas);
         this.rect.right += subrect.right + 1;
         this.rect.bottom = Math.max(this.rect.bottom, subrect.bottom);
      }
      this.rect.bottom++;
      this.setWidth(this.rect.right - this.rect.left);
      this.setHeight(this.rect.bottom - this.rect.top);
      return this.rect;
   }

/**
 * The method preRedraw gets globals and variables names.
 */
   public void preRedraw() {
      if(isE_VARHIGHLIGHT() || isE_ANALYSER()) {
         this.globalNames = parseGlobalNames(globalType.ALLGLOBALS);
         parseVarNames();
      }
   }

/**
 * The method progDraw entry point for draw NSD.
 * @param _g Graphics
 * @return Rect
 */
   public Rect progDraw(Graphics _g) {
      final Canvas canvas = new Canvas((Graphics2D) _g);
      canvas.setFont(AbstractElement.getFont());
      final Rect myrec = prepareDraw(canvas);
      draw(canvas, myrec);
      return myrec;
   }

   @Override()
   public AbstractElement selectElementByCoord(int _x, int _y, boolean update) {
      if(update) {
         this.selected = false;
      }
      AbstractElement found = null;
      for(int i = 0; i < getSize(); i++) {
         final RootElement root = getElement(i);
         final AbstractElement sel = root.selectElementByCoord(_x, _y, update);
         if(sel != null) {
            found = sel;
         }
      }
      if(found == null) {
         this.selected = true;
         return this;
      }
      return found;
   }

   @Override()
   public String toString(String indent) {
      String tree = indent + this.getClass().getSimpleName() + "\n";
      for(int i = 0; i < getSize(); i++) {
         final AbstractElement root = this.getChildQueue().getElement(i);
         tree += root.toString(indent + "   ");
      }
      return tree;
   }

}
