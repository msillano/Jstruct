//    JStruct: a Nassi-Schneiderman Diagrams (NSD) java editor
//    (C)2012 Marco Sillano
//    Based on Structurizer 3.20  (C)2009  Bob Fisch
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or any
//    later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\lu\fisch\structorizer\elements\Call.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//
// package and import
package lu.fisch.structorizer.elements;

import java.awt.Color;
import java.awt.FontMetrics;
import java.util.Vector;
import lu.fisch.graphics.Canvas;
import lu.fisch.graphics.Rect;
import lu.fisch.utils.BString;
import lu.fisch.utils.ErrorMessages;
import lu.fisch.utils.Java3Code;
import lu.fisch.utils.StringList;

/**
 * Call block, specialized for <code>Method Invocation</code> statements (optional). <br />
 * A method invocation expression is used to invoke a class or instance method. <br />
 * To be used as alternative to standard Instruction block, useful for evidence top-down design strategy.
 *<table width="600" border="1"> <tr>
 *  <td><img src="../../../../resources/JS-Call.png" width="200" alt="" border="0"></td>
 *  <td ><img src="../../../../resources/DNS-call.png" width="200"  alt="" border="0"></td>
 *  <td>
 *
 *  <i>MethodInvocation: <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; MethodName </i><code>(</code><i> [ArgumentList]</i><code>)</code><i>  <br /><br>
 *    &nbsp;&nbsp;&nbsp;&nbsp; Primary .[NonWildTypeArguments] Identifier </i><code>(</code><i> [ArgumentList]</i><code>)</code><i>  <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; </i><code>super.</code><i>[NonWildTypeArguments] Identifier </i><code>(</code><i> [ArgumentList]</i><code>)</code><i>  <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; ClassName</i><code>.super.</code><i> [NonWildTypeArguments] Identifier </i><code>(</code><i> [ArgumentList]</i><code>)</code><i>  <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; TypeName . [NonWildTypeArguments] Identifier </i><code>(</code><i> [ArgumentList]</i><code>)</code><i>  <br /><br>
 *    ArgumentList: <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; Expression <br />
 *    &nbsp;&nbsp;&nbsp;&nbsp; ArgumentList , Expression <br />
 *</i></td> </tr>
 *<table >
 *
 **<dt><span class="strong">Look and feel:</span></dt>
 *<dd>In menu the Call icon is <img src="../../../../resources/058_conv_call.png" border="1" width="16" height="16" alt=""><br /><br />
 *<dt><span class="strong">Syntax:</span></dt>
 *<dd>The code in a Call block must be:<pre>
 *&nbsp;&nbsp;&nbsp;&nbsp;[&lt;comment>]&lt;statement>[;&lt;statement>|&lt;comment>]* </pre>
 *Comments are allowed: in exported java code they are grouped as <i>end-of-line comments</i> (i.e. using '//') before or at the right of the code (see AbstractElemen.PROGRAMDOCONTOP).  <br /><br />
 *
 *<dt><span class="strong">Analyze:</span></dt><i><ul>
 *<li>WARNING: the called method do not exist.
 *<br>(In exported java code a stub is created for missed methods) </i>
 *</ul>
 * <br />Source build by JStruct [charset windows-1252].<br />
 *
 * @version 1.02.00  build 9  (2015.04.09-11:47:43) update to java 1.8
 * @version <dd> 1.01.01  build 22  (2012.03.10-13:19:24) JStruct-aware version
 * @version <dd>1.01.00  build 135  (2012.02.07-19:17:22)  base version
 * @author Marco Sillano <marco.sillano@gmail.com>
 */
public class Call
extends Instruction {

/**
 * The default constructor
 */
   public Call() {
      super();
   }

/**
 * The constructor from String code
 * @param _strings String used as code
 */
   public Call(String _strings) {
      super(_strings);
      setCode(_strings);
   }

/**
 * The constructor from StringList code
 * @param _strings StringList used as code
 */
   public Call(StringList _strings) {
      super(_strings);
      setCode(_strings);
   }

   @Override()
   public Rect prepareDraw(Canvas _canvas) {
      this.rect.top = 0;
      this.rect.left = 0;
      this.rect.right = 0;
      this.rect.bottom = 0;
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      this.rect.right = E_PADDING;
      for(int i = 0; i < this.code.count(); i++) {
         if(this.rect.right < _canvas.stringWidth(this.code.get(i)) + 4 * E_PADDING) {
            this.rect.right = _canvas.stringWidth(this.code.get(i)) + 4 * E_PADDING;
         }
      }
      this.rect.bottom = E_PADDING + this.code.count() * fm.getHeight();
      return this.rect;
   }

   @Override()
   public void draw(Canvas _canvas, Rect _top_left) {
      Rect myrect = new Rect();
      Color drawColor = getColor();
      final FontMetrics fm = _canvas.getFontMetrics(AbstractElement.font);
      if(this.selected == true) {
         drawColor = E_DRAWCOLOR;
      }
      this.rect = _top_left.copy();
      final Canvas canvas = _canvas;
      canvas.setBackground(drawColor);
      canvas.setColor(drawColor);
      myrect = _top_left.copy();
      canvas.fillRect(myrect);
// draw comment
      if(AbstractElement.isE_SHOWCOMMENTS() == true && !this.comment.getText().trim().equals("")) {
         canvas.setBackground(E_COMMENTCOLOR);
         canvas.setColor(E_COMMENTCOLOR);
         final Rect someRect = _top_left.copy();
         someRect.left += 2;
         someRect.top += 2;
         someRect.right = someRect.left + 4;
         someRect.bottom -= 1;
         canvas.fillRect(someRect);
      }
      for(int i = 0; i < this.code.count(); i++) {
         String text1 = this.code.get(i);
         text1 = BString.replace(text1, "<--", "<-");
         canvas.setColor(Color.BLACK);
         writeOutVariables(canvas, _top_left.left + E_PADDING, _top_left.top + E_PADDING / 2 + (i + 1) * fm.getHeight(), text1);
      }
      canvas.moveTo(_top_left.left + E_PADDING / 2, _top_left.top);
      canvas.lineTo(_top_left.left + E_PADDING / 2, _top_left.bottom);
      canvas.moveTo(_top_left.right - E_PADDING / 2, _top_left.top);
      canvas.lineTo(_top_left.right - E_PADDING / 2, _top_left.bottom);
      canvas.setColor(Color.BLACK);
      canvas.drawRect(_top_left);
   }

   @Override()
   public AbstractElement copy() {
      final AbstractElement ele = new Call(getCode().copy());
      ele.setComment(getComment().copy());
      ele.setColor(getColor());
      return ele;
   }

   @Override()
   public Vector < DetectedError > analyze(Vector < DetectedError > _errors) {
//      Menu.error11.text=Warning: il metodo «%» non esiste.
      Java3Code jcode = new Java3Code(this.code);
      jcode.onlyCode().spaceTokenize(false);
      for(String jline : jcode) {
         if(!jline.contains(".")) {
            final String mName = new Java3Code(jline).getMethodName();
            if(mName != null) {
               boolean found = false;
//debug            System.out.println("CallTest for" +mName +" in ["+getGlobalNames().getCommaText()+"]");
               for(int j = 0; j < getGlobalNames().count(); j++) {
                  if(getGlobalNames().get(j).startsWith(mName + "_")) {
                     found = true;
                  }
               }
               if(!found) {
                  final DetectedError e = new DetectedError(RootElement.errorMsg(ErrorMessages.error11, mName), this);
                  RootElement.addError(_errors, e, 11);
               }
            }
         }
      }
      return _errors;
   }

}
