/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package lu.fisch.graphics;

/******************************************************************************************************
 *
 *      Author:         Bob Fisch
 *
 *      Description:    Class to represent a drawing canvas.
 *						Aims to work like a "TCanvas" in Delphi
 *
 ******************************************************************************************************
 *
 *      Revision List
 *
 *      Author          Date			Description
 *      ------			----			-----------
 *      Bob Fisch       2007.12.10      First Issue
 *
 ******************************************************************************************************
 *
 *      Comment:	
 *
 ******************************************************************************************************/


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;


import lu.fisch.utils.*;

/**
*
*/
public class Canvas  {

	protected Graphics2D canvas = null;
	private int x;
	private int y;

	/**
	 * @param _canvas
	 */
	public Canvas(final Graphics2D _canvas)
	{
		this.canvas=_canvas;
		if(this.canvas!=null) this.canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	}

	/**
	 * @param _img
	 * @param _x
	 * @param _y
	 */
	public void draw(final Image _img, final int _x, final int _y)
	{
		this.canvas.drawImage(_img,_x,_y,null);
	}

	/**
	 * @param _font
	 * @return font
	 */
	public FontMetrics getFontMetrics(final Font _font)
	{
		return this.canvas.getFontMetrics(_font);
	}

	/**
	 * @param _string
	 * @return  new Double(bounds.getWidth()).intValue();
	 */
	public int stringWidth(final String _string)
	{
		final Rectangle2D bounds = this.canvas.getFont().getStringBounds(_string,this.canvas.getFontRenderContext());
		//return new Double(bounds.getWidth()).intValue();
		return (int) bounds.getWidth();
	}

	/**
	 * @param _string
	 * @return int
	 */
	public int stringHeight(final String _string)
	{
		final Rectangle2D bounds = this.canvas.getFont().getStringBounds(_string,this.canvas.getFontRenderContext());
		return (int) bounds.getHeight();
	}

	/**
	 * @return font
	 */
	public Font getFont()
	{
		return this.canvas.getFont();
	}

	/**
	 * @param _font
	 */
	public void setFont(final Font _font)
	{
		this.canvas.setFont(_font);
	}

	/**
	 * @param _color
	 */
	public void setColor(final Color _color)
	{
		this.canvas.setColor(_color);
	}

	/**
	 * @param _color
	 */
	public void setBackground(final Color _color)
	{
		this.canvas.setBackground(_color);
	}

	/**
	 * @param _rect
	 */
	public void drawRect(final Rect _rect)
	{
		this.canvas.drawRect(_rect.left, _rect.top, _rect.right-_rect.left, _rect.bottom-_rect.top);
	}

	/**
	 * @param _rect
	 */
	public void fillRect(final Rect _rect)
	{
		this.canvas.fillRect(_rect.left, _rect.top, _rect.right-_rect.left, _rect.bottom-_rect.top);
	}

	/**
	 * @param _rect
	 */
	public void drawRoundRect(final Rect _rect)
	{
		this.canvas.drawRoundRect(_rect.left, _rect.top, _rect.right-_rect.left, _rect.bottom-_rect.top,30,30);
	}

	/**
	 * @param _rect
	 */
	public void fillRoundRect(final Rect _rect)
	{
		final RoundRectangle2D xr = new RoundRectangle2D.Float(_rect.left, _rect.top,_rect.right-_rect.left,_rect.bottom-_rect.top, 30, 30);
		this.canvas.fill(xr);
	}



	/**
	 * @param _x
	 * @param _y
	 * @param _text
	 */
	public void writeOut(final int _x, final int _y, final String _text)
	{
//		String display = new String(_text);

		String display = BString.replace(_text, "<--","<-");
		display = BString.replace(display, "<-","\u2190");

		this.canvas.drawString(display, _x, _y);
	}

	/**
	 * @param _x
	 * @param _y
	 */
	public void translate (final int _x, final int _y) {
		this.canvas.translate(_x, _y);
	}

	/**
	 * @param _x
	 * @param _y
	 */
	public void moveTo(final int _x, final int _y)
	{
		this.x=_x;
		this.y=_y;
	}

	/**
	 * @param _x
	 * @param _y
	 */
	public void lineTo(final int _x, final int _y)
	{
		this.canvas.drawLine(this.x,this.y,_x,_y);
		moveTo(_x,_y);
	}

}
