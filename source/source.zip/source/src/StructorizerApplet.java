/*
    Structorizer
    A little tool which you can use to create Nassi-Schneiderman Diagrams (NSD)

    Copyright (C) 2009  Bob Fisch

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any
    later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.io.File;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

// import lu.fisch.structorizer.elements.Element;
import lu.fisch.structorizer.elements.AbstractElement;
import lu.fisch.structorizer.elements.RootElement;
import lu.fisch.structorizer.gui.Diagram;
import lu.fisch.structorizer.gui.Editor;
import lu.fisch.structorizer.gui.Menu;
import lu.fisch.structorizer.gui.NSDController;
//Synchronize code with Mainform
import lu.fisch.structorizer.io.Ini;

public class StructorizerApplet extends JApplet implements NSDController {
	private static final long serialVersionUID = 100100L;
	private Diagram diagram = null;
	private Menu menu = null;
	private Editor editor = null;

	private String lang = "en.txt";
	private String laf = "";

	@Override
	public void init() {
		//Execute a job on the event-dispatching thread:
		//creating this applet's GUI.
		try {
			javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					createGUI();
				}
			});
		} catch (final Exception e) {
			System.err.println("createGUI didn't successfully complete");
		}
	}

	// setup the form
	public void createGUI() {
		/******************************
		 * Load values from INI
		 ******************************/
		Ini.getInstance();
		loadFromINI();
//		System.out.println("after IniRead");
		/******************************
		 * Setup the editor
		 ******************************/
		this.editor = new Editor(this);
//		System.out.println("after Editor");

		// get reference to the diagram
		this.diagram = this.editor.diagram;
		final Container container = getContentPane();
//		System.out.println("after Container-1");
		container.setLayout(new BorderLayout());
		container.add(this.editor, BorderLayout.CENTER);
//		System.out.println("after Container-2");

		/******************************
		 * Setup the menu
		 ******************************/
		this.menu = new Menu(this.diagram, this);
		setJMenuBar(this.menu);
//		System.out.println("after Menu");

		/******************************
		 * Load values from INI
		 ******************************/
		loadFromINI();
		setLang(this.lang);
		/******************************
		 * Update the buttons and menu
		 ******************************/
		doButtons();
//		System.out.println("after Buttons");

		this.editor.revalidate();
		repaint();
		this.editor.diagram.redraw();

	}

	@Override
	public void doButtons() {
		if (this.menu != null) {
			this.menu.doButtonsLocal();
		}

		if (this.editor != null) {
			this.editor.doButtonsLocal();
		}
	}

	@Override
	public void doButtonsLocal() { /* none todo for Applet */
	}

	@Override
	public void updateColors() {
		/* */
	}

	@Override
	public void setLang(String _langfile) {
		this.lang = _langfile;

		if (this.menu != null) {
			this.menu.setLangLocal(_langfile);
		}

		if (this.editor != null) {
			this.editor.setLangLocal(_langfile);
		}
	}

	@Override
	public void setLangLocal(String _langfile) {
		/* */
	}

	@Override
	public String getLang() {
		return this.lang;
	}


	@Override
	public String getOutCoding() {
		/* */
	}


	@Override
	public void setOutCoding(String outCoding) {
	/*	*/
	}


	@Override
	public void setLookAndFeel(String _laf) {
		this.laf = _laf;
		final UIManager.LookAndFeelInfo plafs[] = UIManager
		.getInstalledLookAndFeels();
		for (int j = 0; j < plafs.length; ++j) {
			if (_laf.equals(plafs[j].getName())) {
				try {
					UIManager.setLookAndFeel(plafs[j].getClassName());
					SwingUtilities.updateComponentTreeUI(this);
				} catch (final Exception e) {
					// show error
					JOptionPane.showOptionDialog(null, e.getMessage(),
							"Error ...", JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE, null, null, null);
				}
			}
		}
	}

	@Override
	public String getLookAndFeel() {
		return this.laf;
	}

	@Override
	public void savePreferences() {
		//System.out.println("Saving");
		saveToINI();
		Element.saveToINI();
		//           JMethod.saveToINI();
	}

	@Override
	public JFrame getFrame() {
		return null;
	}

	@Override
	public void pan(int x, int y) {
		// only for Editor
	}

	/******************************
	 * Load & save INI-file
	 ******************************/
	public void loadFromINI() {
		try {
			final Ini ini = Ini.getInstance();
			ini.load();
			// language
			this.lang = ini.getProperty("Lang", "en.txt");
			// look & feel
			this.laf = ini.getProperty("laf", "Mac OS X");
			setLookAndFeel(this.laf);

			if (this.diagram != null) {
				// current directory
				this.diagram.currentDirectory = new File(ini.getProperty(
						"currentDirectory",
						System.getProperty("file.separator")));
				// comments
				if (ini.getProperty("showComments", "0").equals("1")) // default = 0
				{
					this.diagram.setComments(true);
				}
				// comments
				if (ini.getProperty("varHightlight", "0").equals("1")) // default = 0
				{
					this.diagram.setHightlightVars(true);
				}
				// analyser
				if (ini.getProperty("analyser", "0").equals("1")) // default = 0
				{
					this.diagram.setAnalyser(true);
				}

			}

			// recent files
			try {
				if (this.diagram != null) {
					for (int i = 9; i >= 0; i--) {
						if (ini.keySet().contains("recent" + i)) {
							if (!ini.getProperty("recent" + i, "").trim()
									.equals("")) {
								this.diagram.addRecentFile(
										ini.getProperty("recent" + i, ""),
										false);
							}
						}
					}
				}
			} catch (final Exception e) {
				e.printStackTrace();
				System.err.println(e.getMessage());
			}
			// analyser
			RootElement.check1 = ini.getProperty("check1", "1").equals("1");
			RootElement.check2 = ini.getProperty("check2", "1").equals("1");
			RootElement.check3 = ini.getProperty("check3", "1").equals("1");
			RootElement.check4 = ini.getProperty("check4", "1").equals("1");
			RootElement.check5 = ini.getProperty("check5", "1").equals("1");
			RootElement.check6 = ini.getProperty("check6", "1").equals("1");
			RootElement.check7 = ini.getProperty("check7", "1").equals("1");
			RootElement.check8 = ini.getProperty("check8", "1").equals("1");
			RootElement.check9 = ini.getProperty("check9", "1").equals("1");
			RootElement.check10 = ini.getProperty("check10", "1").equals("1");
			RootElement.check11 = ini.getProperty("check11", "1").equals("1");
			RootElement.check12 = ini.getProperty("check12", "1").equals("1");
			RootElement.check13 = ini.getProperty("check13", "1").equals("1");

			doButtons();
		} catch (final Exception e) {
			e.printStackTrace();
			System.err.println(e);

			setPreferredSize(new Dimension(500, 500));
			setSize(500, 500);
			setLocation(new Point(0, 0));
			validate();
		}
	}

	public void saveToINI() {
		try {
			final Ini ini = Ini.getInstance();
			ini.load();

			// position
			ini.setProperty("Top", Integer.toString(getLocationOnScreen().x));
			ini.setProperty("Left", Integer.toString(getLocationOnScreen().y));
			ini.setProperty("Width", Integer.toString(getWidth()));
			ini.setProperty("Height", Integer.toString(getHeight()));

			// current directory
			if (this.diagram != null) {
				if (this.diagram.currentDirectory != null) {
					ini.setProperty("currentDirectory",
							this.diagram.currentDirectory.getAbsolutePath());
				}
			}
			// language
			ini.setProperty("Lang", this.lang);
			ini.setProperty("showComments",
					(Element.E_SHOWCOMMENTS ? "1" : "0"));
			ini.setProperty("varHightlight", (Element.E_VARHIGHLIGHT ? "1"
					: "0"));
			ini.setProperty("analyser", (Element.E_ANALYSER ? "1" : "0"));
			// look and feel
			if (this.laf != null) {
				ini.setProperty("laf", this.laf);
			}
			// recent files
			if (this.diagram != null) {
				if (this.diagram.recentFiles.size() != 0) {
					for (int i = 0; i < this.diagram.recentFiles.size(); i++) {
						//System.out.println(i);
						ini.setProperty("recent" + String.valueOf(i),
								(String) this.diagram.recentFiles.get(i));
					}
				}
			}
			ini.save();
		} catch (final Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
	}
}
