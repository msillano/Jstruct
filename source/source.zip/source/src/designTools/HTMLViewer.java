// <p>Title: Chip Design Tools</p>
// <p>Description: Chip design tools for the Java BreadBoard Simulator </p>
// <p>Copyright: Copyright 2005. Stephen Halstead</p>
// <p>Company: University of York</p>
// @author Stephen Halstead
// Web page browser suitable for displaying help files. Instantiating this class
// is similar to calling jBreadBoard.HTMLDialog.addHTMLDialog but that frame
// doesn't have any support for hyperlinks. This frame uses navigation via hyperlinks
// and uses a back button. Adapated from an example in Core Java 2: Additional Features
// by Horstmann and Cornell
//
// Modified for JStruct, by M. Sillano
//
//@JStructOptions: ADDJAVADOCPUBLIC, PROGRAMDOCONTOP, SETSOURCEVERSION
//@source: D:\User\Documents\progetti2015\javaStruct\source\src\designTools\HTMLViewer.java
//@JStruct: 1.02.01 Parser: javac 1.8.0_31
//
// package and import
package designTools;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;

/**
 * Web page browser for help
 * <br />Source build by JStruct [charset UTF-8].<br />
 * @version 1.02.00  build 2  (2015.03.27-20:38:06) to java 1.8
 * @version <br /> 1.01.01  build 1  (2012.03.12-20:59:31) JStruct-aware version
 * @author  Stephen Halstead
 */
public class HTMLViewer
extends JFrame {

   /* class global variables */
   private static final long serialVersionUID = 7985318582256245537L;
   JScrollPane scrollPane = new JScrollPane();
   JEditorPane htmlPane = new JEditorPane();
   JButton cmdClose = new JButton();
   JButton cmdBack = new JButton();
   // Hold visited pages so that back button can be implemented
   private final java.util.Stack<String> pageStack = new java.util.Stack<String>();
   GridBagLayout gridBagLayout1 = new GridBagLayout();

/**
 * Constructor
 * @param page Viewer Homepage
 * @param title Title for the frame
 */
   public HTMLViewer(URL page, String title) {
      try {
         jbInit();
         displayPage(page);
         setTitle(title);
      }
      catch (final Exception ex) {
         ex.printStackTrace();
      }
   }

   private void jbInit() throws Exception {
      getContentPane().setLayout(this.gridBagLayout1);
      this.htmlPane.addHyperlinkListener(new HTMLViewer_htmlPane_hyperlinkAdapter(this));
      this.htmlPane.setEditable(false);
      this.htmlPane.setContentType("text/html");
      this.cmdClose.setText("Close");
      this.cmdClose.addMouseListener(new HTMLViewer_cmdClose_mouseAdapter(this));
      this.cmdBack.setText("Back");
      this.cmdBack.addMouseListener(new HTMLViewer_cmdBack_mouseAdapter(this));
      this.setSize(new Dimension(628, 440));
      getContentPane().add(this.scrollPane, new GridBagConstraints(0, 0, 2, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(10, 8, 0, 11), 0, 353));
      getContentPane().add(this.cmdClose, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(11, 9, 17, 11), 14, 0));
      getContentPane().add(this.cmdBack, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(11, 441, 17, 0), 20, 0));
      this.scrollPane.getViewport().add(this.htmlPane, null);
//Center the window
      final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      final Dimension frameSize = getSize();
      if(frameSize.height > screenSize.height) {
         frameSize.height = screenSize.height;
      }
      if(frameSize.width > screenSize.width) {
         frameSize.width = screenSize.width;
      }
      setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
//dialog.show();
      setVisible(true);
   }

/**
 * Close this HTML Viewer
 * @param e MouseEvent
 */
   void cmdClose_mouseClicked(MouseEvent e) {
      dispose();
   }

/**
 * Displays an HTML page
 * @param page The page to display
 */
   public void displayPage(URL page) {
      try {
// Record page for back button
         this.pageStack.push(page.toString());
// Show page
         this.htmlPane.setPage(page);
      }
      catch (final IOException ex) {
         this.htmlPane.setText("Exception: " + ex);
      }
   }

/**
 * Respond to the user clicking on a hyperlink
 * @param e Hyperlink Event
 */
   void htmlPane_hyperlinkUpdate(HyperlinkEvent e) {
//test:   System.out.println("hyper event " + e);
      if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
         displayPage(e.getURL());
      }
   }

/**
 * Load the previous page if the user clicked the back button
 * @param e Mouse Event
 */
   void cmdBack_mouseClicked(MouseEvent e) {
// Stack includes current page
      if(this.pageStack.size() > 1) {
         try {
// Remove top item in page stack
            this.pageStack.pop();
// Display page
            final String pageString = this.pageStack.peek();
            this.htmlPane.setPage(pageString);
         }
         catch (final IOException ex) {
            this.htmlPane.setText("Exception: " + ex);
         }
      }
   }

}

class HTMLViewer_cmdClose_mouseAdapter
extends java.awt.event.MouseAdapter {

   /* class global variables */
   HTMLViewer adaptee;

   HTMLViewer_cmdClose_mouseAdapter(HTMLViewer adaptee) {
      this.adaptee = adaptee;
   }

   @Override()
   public void mouseClicked(MouseEvent e) {
      this.adaptee.cmdClose_mouseClicked(e);
   }

}

class HTMLViewer_htmlPane_hyperlinkAdapter
implements javax.swing.event.HyperlinkListener {

   /* class global variables */
   HTMLViewer adaptee;

   HTMLViewer_htmlPane_hyperlinkAdapter(HTMLViewer adaptee) {
      this.adaptee = adaptee;
   }

   @Override()
   public void hyperlinkUpdate(HyperlinkEvent e) {
      this.adaptee.htmlPane_hyperlinkUpdate(e);
   }

}

class HTMLViewer_cmdBack_mouseAdapter
extends java.awt.event.MouseAdapter {

   /* class global variables */
   HTMLViewer adaptee;

   HTMLViewer_cmdBack_mouseAdapter(HTMLViewer adaptee) {
      this.adaptee = adaptee;
   }

   @Override()
   public void mouseClicked(MouseEvent e) {
      this.adaptee.cmdBack_mouseClicked(e);
   }

}
