
Open FullUserTest.nds (in JStruct)
On Menu/Diagram set ON Show comments.
Navigate the Nassy-

Preconditions:
   JStruct installed ok
   ".nsd" files aqssociated with JStruct.bat