#!/bin/sh

# first changedir to the directory of this script
# resolve links - $0 may be a softlink
PRG="$0"

while [ -h "$PRG" ] ; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
    PRG="$link"
  else
    PRG=`dirname "$PRG"`/"$link"
  fi
done
 
cd `dirname "$PRG"`

# $1 (optional) can be a .nsd or a .java file
# to be updated to actual JDK: using JRE the import-java option is not avalable in JStruct
/<java path>/jdk1.8.0_31/java    -jar jstruct.jar  $1
